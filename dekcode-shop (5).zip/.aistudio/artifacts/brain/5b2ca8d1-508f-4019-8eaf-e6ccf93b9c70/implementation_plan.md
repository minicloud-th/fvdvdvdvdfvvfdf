# Integrate KODDYKUB Design System & 3D Tilted Grid Architecture

Adopt and implement the complete visual identity, layout architecture, and interactive components from the **KODDYKUB** design reference (`https://github.com/minicloud-th/sdfskfsdkldslfsf.git`), featuring the signature 3D tilted video grid hero, deep obsidian-purple color scheme, HUD typographic styling, interactive feature cards, and community showcase.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and design decisions have been extracted from the reference repository (`KODDYKUB.zip`) and are proposed for your approval:

- **Confirmed Decision 1 (Brand & Identity)**: Establish the site identity as **KODDYKUB**—a high-end digital marketplace for gamers and developers specializing in authentic game accounts, full-stack source code, and automation scripts.
- **Confirmed Decision 2 (Hero Architecture)**: Implement the **Tilted Grid Hero** with animated 3D perspective tiles, ambient floating media cards, and subtle orbit motion that responds smoothly across desktop and mobile devices.
- **Confirmed Decision 3 (Color System & Tokens)**:
  - Background: Deep Void (`--kk-bg: #090910`) and Panel Glass (`--kk-panel: #10101a` / `#151522`)
  - Accent Primary: Electric Amethyst (`--kk-purple: #a477ff`) with gradient brand mark (`#a477ff` $\to$ `#6746dc`)
  - Accent Secondary: Cyber Neon Cyan (`--kk-cyan: #65e7d0`) for HUD eyebrows and status telemetry
  - Line Grids: Subtle Hairline Borders (`--kk-line: #282838` / `rgb(255 255 255 / 9%)`)
- **Confirmed Decision 4 (Section Flow)**:
  1. Sticky Glass Topbar with KODDYKUB Monogram Mark & Navigation
  2. 3D Tilted Grid Hero with live media video cards and dual primary CTAs
  3. Interactive 8-Feature Grid ("The control that mere words cannot buy")
  4. Ownership & Value Assurance Section ("Stop renting from websites")
  5. Marketplace Catalog & Product Grid (Game IDs, Roblox, Valorant, Source Code)
  6. "Made with KODDYKUB" Community Showcase with video preview modal
  7. Multi-column Architectural Grid Footer with store directory

---

### 1. Overview & Core Concept

- **What It Does**: Upgrades the storefront into an immersive, futuristic digital commerce experience inspired by KODDYKUB / ArtCraft. Combines rich 3D tilted motion graphics with instant digital account purchases, source code downloads, and automated delivery.
- **Target Audience / Persona**: Gamers, programmers, server owners, and digital creators looking for verified game accounts and production-ready source code with instant checkout.
- **Key Value**: Distinctive aesthetic presence that stands apart from standard e-commerce templates, smooth hardware-accelerated animations, clear product filtering, and instant automated delivery 24/7.

---

### 2. User Experience & Visual Design

#### Layout Structure & Spatial System
```
┌────────────────────────────────────────────────────────────────────────┐
│  [K] KODDYKUB     หน้าแรก   ร้านค้า   ไอดีเกม   ซอร์สโค้ด   ติดต่อเรา    [เข้าสู่ระบบ] │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│                      KODDYKUB · สินค้าดิจิทัล                          │
│                                                                        │
│                     เลือกซื้อสินค้า & ซอร์สโค้ด                         │
│                                                                        │
│             [ ดูหมวดสินค้า ]           [ วิธีสั่งซื้อ ]                 │
│                                                                        │
│  [■■■ 3D Tilted Floating Media Grid (Smooth Ambient Motion) ■■■]       │
│                                                                        │
├────────────────────────────────────────────────────────────────────────┤
│  01. คุณสมบัติเด่น (8 Feature Cards with Deep Glass & Hover Glow)       │
├────────────────────────────────────────────────────────────────────────┤
│  02. กรรมสิทธิ์ถาวร 100% ("Stop renting from websites")               │
├────────────────────────────────────────────────────────────────────────┤
│  03. แคตตาล็อกสินค้า (Category Tabs + Instant Search + Product Cards)   │
├────────────────────────────────────────────────────────────────────────┤
│  04. ชุมชนและผลงาน ("Made with KODDYKUB" Video Showcase)              │
├────────────────────────────────────────────────────────────────────────┤
│  Architectural Grid Footer (Directories, Contact, Policies, Copyright) │
└────────────────────────────────────────────────────────────────────────┘
```

#### Typography & Design Tokens
- **Display Font**: Inter / Plus Jakarta Sans paired with Noto Sans Thai (`--kk-font`).
- **HUD Labels**: Monospace, `font-bold`, uppercase, tracking `0.19em` in Cyan (`#65e7d0`).
- **Buttons**:
  - Pill Action (`kk-button`): Amethyst gradient `#a477ff`, hover elevation `-2px` with purple glow shadow.
  - Ghost Action (`kk-button--ghost`): Translucent border `rgba(255,255,255,0.15)` with backdrop blur.
- **Card Styling**: 1px subtle boundary (`#282838`), rounded-xl geometry, dark slate container `#10101a`.

---

### 3. Technical Architecture & Component Hierarchy

```
App.tsx
├── HeaderNavbar (KODDYKUB Glass Topbar, Monogram Mark, Search Modal, Auth)
├── MobileDrawer (Slide-over Navigation for Touch Viewports)
├── Main Content View Controller
│   └── HomeView (New KODDYKUB Master Experience)
│       ├── TiltedGridHero (Interactive 3D Media Floating Grid with WebM/Canvas fallback)
│       ├── FeatureGridSection (8 Deep Interactive Feature Cards)
│       ├── OwnershipGuaranteeSection (Zero-subscription & Lifetime Guarantee)
│       ├── MarketplaceSection (Category Pills, Search Filter, ProductGrid)
│       │   └── ProductCard (Sleek Dark Obsidian Cards with Stock Status)
│       ├── CommunityShowcaseSection (3 Interactive Media Showcase Cards)
│       └── TelemetryStatsBar (Live Member Counts & Order Counters)
├── ProductDetailView / Cart / Purchase Modal (Smooth Checkout Flow)
├── SupportFloatingButton ("ติดต่อสอบถาม แจ้งปัญหา")
└── Footer (KODDYKUB Multi-Column Architectural Footer)
```

---

### 4. Step-by-Step Implementation Strategy

1. **Asset Pipeline & Tokens**:
   - Extract and copy required visual media assets (`artcraft-icon.svg`, WebM clips, video previews) from the extracted `/tmp/koddykub_src/public/assets/` into `public/assets/`.
   - Configure `--kk-*` CSS design variables in `src/index.css` alongside Tailwind utilities.

2. **Hero & 3D Tilted Grid Engine**:
   - Build `TiltedGridHero.tsx` using hardware-accelerated CSS transforms and responsive perspective tilt (`transform: perspective(1000px) rotateX(12deg) rotateY(-8deg) rotateZ(4deg)`).
   - Integrate animated media tiles with fallback video/image loop and `prefers-reduced-motion` compliance.

3. **Feature Cards & Value Proposition**:
   - Create `FeatureGridSection.tsx` with 8 curated capability modules matching the reference (Image to 3D, Precise Layer Control, Asset Mix, Character Posing, etc.).
   - Implement `OwnershipSection.tsx` highlighting 100% permanent ownership, zero recurring fees, and instant delivery.

4. **Catalog & Storefront Integration**:
   - Wire existing real products (Valorant accounts, Blox Fruits, Steam Bundles, E-Commerce Starter, Discord Bots) into the new KODDYKUB card design.
   - Maintain full search query filtering, category selection, and detail modal checkout.

5. **Community Showcase & Video Modal**:
   - Add the "Made with KODDYKUB" community section showcasing game/code highlights with interactive play previews.

6. **Refined Topbar & Architectural Footer**:
   - Upgrade `HeaderNavbar.tsx` to match the KODDYKUB sticky topbar with monogram logo.
   - Update `Footer.tsx` with the multi-column directory grid structure.

---

### 5. Verification & Testing Checklist

- [ ] Build & compilation verification (`npm run build` / `compile_applet`).
- [ ] TypeScript type checks with zero errors (`npm run lint`).
- [ ] Responsive viewport testing on Desktop (1440px), Tablet (768px), and Mobile (375px).
- [ ] 3D Tilted Grid performance check (60fps smooth hardware acceleration, no layout thrashing).
- [ ] Interactive checkout flow test (add to cart, view details, promptpay QR simulated order).
