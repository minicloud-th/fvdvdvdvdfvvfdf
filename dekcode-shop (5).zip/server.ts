import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import net from 'net';
import crypto from 'crypto';
import axios from 'axios';
import dotenv from 'dotenv';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { initializeApp as initFirebaseAdmin, getApps as getFirebaseApps } from 'firebase-admin/app';
import { getAuth as getFirebaseAuth } from 'firebase-admin/auth';
import { db, toPublicProduct, ServerProduct, ServerOrder } from './src/server/db';

dotenv.config();

const app = express();
const getPort = (): number => {
  const portArgIdx = process.argv.indexOf('--port');
  if (portArgIdx !== -1 && process.argv[portArgIdx + 1]) {
    const p = Number(process.argv[portArgIdx + 1]);
    if (!isNaN(p) && p > 0) return p;
  }
  if (process.env.APP_PORT) {
    const p = Number(process.env.APP_PORT);
    if (!isNaN(p) && p > 0) return p;
  }
  // Port 8080 is the external Cloud Run/Nginx entrypoint; internal Node server must listen on 3000
  if (process.env.PORT && process.env.PORT !== '8080') {
    const p = Number(process.env.PORT);
    if (!isNaN(p) && p > 0) return p;
  }
  return 3000;
};
const PORT = getPort();
const isProduction = process.env.NODE_ENV === 'production';

/**
 * Demo tokens ("auth-token-<id>") let a developer impersonate ANY user.
 * They are only honoured when NOT in production AND explicitly enabled.
 */
const ALLOW_DEMO_AUTH = !isProduction && process.env.ALLOW_DEMO_AUTH === 'true';

// -------------------------------------------------------------------------
// BOOT GUARD
// -------------------------------------------------------------------------
if (isProduction) {
  const supabaseUrl = (process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '').trim();
  const supabaseServiceKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
  const firebaseProjectId = (process.env.FIREBASE_PROJECT_ID || '').trim();

  const missingEnvs: string[] = [];
  if (!supabaseUrl) missingEnvs.push('VITE_SUPABASE_URL / SUPABASE_URL');
  if (!supabaseServiceKey) missingEnvs.push('SUPABASE_SERVICE_ROLE_KEY');
  if (!firebaseProjectId) missingEnvs.push('FIREBASE_PROJECT_ID');

  if (missingEnvs.length > 0) {
    console.error(`\n[CRITICAL BOOT GUARD] Missing required configuration: ${missingEnvs.join(', ')}\n`);
    throw new Error(`[Production Boot Guard] Missing critical environment variables: ${missingEnvs.join(', ')}`);
  }
} else {
  console.log('[Boot] Running in DEVELOPMENT mode with local database fallback.');
  if (ALLOW_DEMO_AUTH) console.warn('[Boot] ALLOW_DEMO_AUTH is ON — demo tokens are accepted. Never enable in production.');
}

// Firebase Admin: verifies ID token signatures server-side
if (!getFirebaseApps().length) {
  const firebaseProjectId = process.env.FIREBASE_PROJECT_ID || 'zenone-eaf64';
  try {
    initFirebaseAdmin({ projectId: firebaseProjectId });
    console.log(`[Firebase Admin] Initialized for project: ${firebaseProjectId}`);
  } catch (fbErr) {
    console.warn('[Firebase Admin] Init warning:', fbErr);
  }
}

// Correct client IP behind exactly one reverse proxy
app.set('trust proxy', 1);
app.disable('x-powered-by');

// -------------------------------------------------------------------------
// SECURITY HEADERS
// -------------------------------------------------------------------------
// AI Studio preview runs inside an iframe. Allow embedding in development or preview environments.
const frameAncestors = process.env.FRAME_ANCESTORS
  ? process.env.FRAME_ANCESTORS.split(/\s+/).filter(Boolean)
  : ["'self'", 'https://*.google.com', 'https://*.run.app', 'https://*.googleusercontent.com', 'https://aistudio.google.com', '*'];

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        scriptSrc: [
          "'self'",
          'https://apis.google.com',
          'https://challenges.cloudflare.com',
          // Vite dev server injects inline/eval helpers. Never allowed in production.
          ...(isProduction ? [] : ["'unsafe-inline'", "'unsafe-eval'"]),
        ],
        // SweetAlert2 and Framer Motion write inline styles at runtime
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
        imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
        mediaSrc: ["'self'", 'blob:', 'https:'],
        connectSrc: ["'self'", 'https:', ...(isProduction ? [] : ['ws:', 'wss:', 'http:'])],
        frameSrc: ["'self'", 'https://challenges.cloudflare.com', 'https://*.firebaseapp.com', 'https://accounts.google.com', 'https://*.google.com'],
        frameAncestors,
        objectSrc: ["'none'"],
        ...(isProduction ? { upgradeInsecureRequests: [] } : {}),
      },
    },
    crossOriginEmbedderPolicy: false,
    // Firebase popup sign-in needs window.opener access
    crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
    crossOriginResourcePolicy: false,
    frameguard: false, // superseded by CSP frame-ancestors
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    hsts: isProduction ? { maxAge: 31536000, includeSubDomains: true, preload: true } : false,
  }),
);

app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  next();
});

// Body parsers: small by default, larger only on image routes
app.use(express.json({ limit: '256kb' }));
app.use(express.urlencoded({ extended: false, limit: '256kb' }));
const largeJson = express.json({ limit: '12mb' });

// Uploaded assets (images only, nosniff, no directory listing)
const publicUploadsDir = path.resolve(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(publicUploadsDir)) {
  try { fs.mkdirSync(publicUploadsDir, { recursive: true }); } catch {}
}
app.use(
  '/uploads',
  express.static(publicUploadsDir, {
    index: false,
    dotfiles: 'deny',
    maxAge: '7d',
    immutable: true,
    setHeaders: (res) => {
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('Content-Security-Policy', "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'");
    },
  }),
);

// -------------------------------------------------------------------------
// HELPERS
// -------------------------------------------------------------------------
type AsyncHandler = (req: any, res: Response, next: NextFunction) => Promise<any>;
const wrap = (fn: AsyncHandler) => (req: Request, res: Response, next: NextFunction) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

const fail = (res: Response, status: number, error: string, code?: string) =>
  res.status(status).json({ success: false, error, ...(code ? { code } : {}) });

const isAdminRole = (role?: string) => ['admin', 'owner'].includes(String(role || '').toLowerCase());

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

const USERNAME_RE = /^[\p{L}\p{N}_.\-]{3,24}$/u;
const sanitizeText = (v: unknown, max: number): string =>
  typeof v === 'string' ? v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max) : '';

/** Only http(s) URLs or same-origin paths are allowed in user/admin supplied links. */
const safeUrl = (v: unknown, max = 600): string => {
  const s = sanitizeText(v, max);
  if (!s) return '';
  if (s.startsWith('/') && !s.startsWith('//')) return s;
  try {
    const u = new URL(s);
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.toString() : '';
  } catch {
    return '';
  }
};

const finiteNumber = (v: unknown, min: number, max: number): number | null => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < min || n > max) return null;
  return n;
};

const safeId = (v: unknown): string => {
  const s = typeof v === 'string' ? v.trim() : '';
  return /^[A-Za-z0-9_\-:.]{1,128}$/.test(s) ? s : '';
};

// -------------------------------------------------------------------------
// PERSISTENT SLIP STORE (DOUBLE-SPEND PREVENTION)
// -------------------------------------------------------------------------
class PersistentSlipStore {
  private filePath: string;
  private memorySet: Set<string>;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      try { fs.mkdirSync(dataDir, { recursive: true }); } catch (e) {
        console.error('[PersistentSlipStore] Directory creation warning:', e);
      }
    }
    this.filePath = path.resolve(dataDir, 'verified_slips.json');
    this.memorySet = new Set<string>();
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.filePath)) {
        const list = JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
        if (Array.isArray(list)) {
          list.forEach((ref) => {
            if (typeof ref === 'string') this.memorySet.add(ref.trim().toUpperCase());
          });
        }
      }
    } catch (err) {
      console.error('[PersistentSlipStore] Failed to read slips store:', err);
    }
  }

  private persist() {
    try {
      const tempPath = `${this.filePath}.tmp.${process.pid}.${Date.now()}`;
      fs.writeFileSync(tempPath, JSON.stringify(Array.from(this.memorySet)), 'utf-8');
      fs.renameSync(tempPath, this.filePath);
    } catch (err) {
      console.error('[PersistentSlipStore] Atomic write error:', err);
    }
  }

  public isUsed(transRef: string): boolean {
    return this.memorySet.has(transRef.trim().toUpperCase());
  }

  /** Returns false if this reference was already used (locally or in Supabase). */
  public async recordSlip(transRef: string, amount: number, userId: string, metadata?: any): Promise<boolean> {
    const cleanRef = transRef.trim().toUpperCase();
    if (this.memorySet.has(cleanRef)) return false;

    this.memorySet.add(cleanRef);
    this.persist();

    const supa = db.getSupabaseClient();
    if (supa) {
      const { error } = await supa.from('verified_slips').insert([
        { trans_ref: cleanRef, amount, user_id: userId, metadata: metadata || {} },
      ]);
      if (error) {
        // 23505 = unique violation: another instance already consumed this slip
        if ((error as any).code === '23505') return false;
        console.warn('[PersistentSlipStore] Supabase sync warning:', error.message);
      }
    }
    return true;
  }

  /** Release a reference when crediting failed so the customer can retry. */
  public async release(transRef: string) {
    const cleanRef = transRef.trim().toUpperCase();
    this.memorySet.delete(cleanRef);
    this.persist();
    const supa = db.getSupabaseClient();
    if (supa) {
      try { await supa.from('verified_slips').delete().eq('trans_ref', cleanRef); } catch {}
    }
  }
}

export const slipStore = new PersistentSlipStore();

// -------------------------------------------------------------------------
// MAGIC BYTES IMAGE VALIDATOR
// -------------------------------------------------------------------------
export function validateImageMagicBytes(buffer: Buffer): { valid: boolean; ext?: string; mime?: string } {
  if (!buffer || buffer.length < 12) return { valid: false };

  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return { valid: true, ext: 'jpg', mime: 'image/jpeg' };
  }
  if (
    buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47 &&
    buffer[4] === 0x0d && buffer[5] === 0x0a && buffer[6] === 0x1a && buffer[7] === 0x0a
  ) {
    return { valid: true, ext: 'png', mime: 'image/png' };
  }
  if (buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') {
    return { valid: true, ext: 'webp', mime: 'image/webp' };
  }
  return { valid: false };
}

// -------------------------------------------------------------------------
// IDEMPOTENCY STORE & ASYNC LOCKS
// -------------------------------------------------------------------------
class IdempotencyStore {
  private cache = new Map<string, { timestamp: number; response: any }>();
  private readonly TTL_MS = 24 * 60 * 60 * 1000;
  private readonly MAX_ENTRIES = 5000;

  get(key: string): any | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.timestamp > this.TTL_MS) {
      this.cache.delete(key);
      return null;
    }
    return entry.response;
  }

  set(key: string, response: any): void {
    if (this.cache.size >= this.MAX_ENTRIES) {
      // Drop the oldest entry (Map keeps insertion order)
      const oldest = this.cache.keys().next().value;
      if (oldest !== undefined) this.cache.delete(oldest);
    }
    this.cache.set(key, { timestamp: Date.now(), response });
  }
}
const buyIdempotencyStore = new IdempotencyStore();

class AsyncLock {
  private tails = new Map<string, Promise<void>>();

  private async acquireOne(key: string): Promise<() => void> {
    const prev = this.tails.get(key) || Promise.resolve();
    let release!: () => void;
    const next = new Promise<void>((resolve) => { release = resolve; });
    const tail = prev.then(() => next);
    this.tails.set(key, tail);
    await prev;
    return () => {
      release();
      if (this.tails.get(key) === tail) this.tails.delete(key);
    };
  }

  /** Acquire one or many keys (sorted to avoid deadlocks), run fn, then release. */
  async run<T>(keys: string | string[], fn: () => Promise<T>): Promise<T> {
    const list = Array.from(new Set(Array.isArray(keys) ? keys : [keys])).sort();
    const releases: Array<() => void> = [];
    try {
      for (const k of list) releases.push(await this.acquireOne(k));
      return await fn();
    } finally {
      releases.reverse().forEach((r) => r());
    }
  }
}
const locks = new AsyncLock();

// -------------------------------------------------------------------------
// RATE LIMITERS
// -------------------------------------------------------------------------
const mkLimiter = (windowMs: number, max: number, message: string) =>
  rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    message: { success: false, error: message, code: 'RATE_LIMITED' },
  });

const generalApiLimiter = mkLimiter(60 * 1000, 180, 'คำขอถี่เกินไป กรุณารอสักครู่แล้วลองใหม่');
const slipRateLimiter = mkLimiter(15 * 60 * 1000, 15, 'คุณส่งคำขอตรวจสอบสลิปเกินจำนวนที่กำหนด กรุณารอสักครู่');
const usernameLookupLimiter = mkLimiter(60 * 1000, 10, 'ค้นหาชื่อผู้ใช้ถี่เกินไป กรุณารอสักครู่');
const redeemLimiter = mkLimiter(15 * 60 * 1000, 20, 'ใช้คีย์ถี่เกินไป กรุณารอสักครู่แล้วลองใหม่');
const buyLimiter = mkLimiter(60 * 1000, 30, 'สั่งซื้อถี่เกินไป กรุณารอสักครู่');
const uploadLimiter = mkLimiter(60 * 1000, 20, 'อัปโหลดถี่เกินไป กรุณารอสักครู่');
const errorLogLimiter = mkLimiter(60 * 1000, 10, 'Too many error reports');
const authSyncLimiter = mkLimiter(60 * 1000, 30, 'คำขอถี่เกินไป กรุณารอสักครู่');

// -------------------------------------------------------------------------
// BLOCKED IP ENFORCEMENT (admin-managed list)
// -------------------------------------------------------------------------
const normalizeIp = (ip: string) => ip.replace(/^::ffff:/, '').trim();

app.use('/api/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const ip = normalizeIp(req.ip || '');
    if (ip && db.getBlockedIPs().some((b) => normalizeIp(b.ip) === ip)) {
      return fail(res, 403, 'ที่อยู่ IP ของคุณถูกระงับการเข้าถึง', 'IP_BLOCKED');
    }
    next();
  } catch (err) {
    next(err);
  }
});

app.use('/api/', generalApiLimiter);

// -------------------------------------------------------------------------
// AUTHENTICATION
// -------------------------------------------------------------------------
export interface AuthenticatedRequest extends Request {
  user?: { id: string; email?: string; authTime?: number };
}

async function resolveUserFromToken(token: string): Promise<AuthenticatedRequest['user'] | null> {
  if (!token || token.length > 4096) return null;

  // 1. Firebase ID token (signature verified by Firebase Admin)
  try {
    const decoded = await getFirebaseAuth().verifyIdToken(token);
    if (decoded?.uid) return { id: decoded.uid, email: decoded.email, authTime: decoded.auth_time };
  } catch {}

  // 2. Supabase JWT
  const supa = db.getSupabaseClient();
  if (supa && !token.startsWith('auth-token-')) {
    try {
      const { data: { user }, error } = await supa.auth.getUser(token);
      if (!error && user) return { id: user.id, email: user.email };
    } catch {}
  }

  // 3. Demo token (local development only, explicit opt-in)
  if (ALLOW_DEMO_AUTH && token.startsWith('auth-token-')) {
    const extractedId = token.replace('auth-token-', '').trim();
    if (extractedId) return { id: extractedId };
  }
  return null;
}

const readBearer = (req: Request): string => {
  const h = req.headers.authorization;
  if (!h || !h.startsWith('Bearer ')) return '';
  return h.slice(7).trim();
};

export const requireAuth = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const token = readBearer(req);
    if (!token) return fail(res, 401, 'กรุณาเข้าสู่ระบบก่อนทำรายการ', 'UNAUTHORIZED');

    const user = await resolveUserFromToken(token);
    if (!user) return fail(res, 401, 'เซสชันการเข้าสู่ระบบไม่ถูกต้องหรือหมดอายุ', 'UNAUTHORIZED');

    // Banned accounts are locked out of every authenticated endpoint
    const profile = await db.getProfile(user.id);
    if (profile && String((profile as any).status || '').toLowerCase() === 'banned') {
      return fail(res, 403, 'บัญชีของคุณถูกระงับการใช้งาน กรุณาติดต่อผู้ดูแลระบบ', 'ACCOUNT_BANNED');
    }

    req.user = user;
    return next();
  } catch (err) {
    return next(err);
  }
};

export const requireAdmin = [
  requireAuth,
  async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const profile = req.user ? await db.getProfile(req.user.id) : null;
      if (!profile || !isAdminRole(profile.role)) {
        return fail(res, 403, 'คุณไม่มีสิทธิ์ผู้ดูแลระบบ', 'FORBIDDEN');
      }
      return next();
    } catch (err) {
      return next(err);
    }
  },
];

/** Is the caller an admin? */
async function callerIsAdmin(req: AuthenticatedRequest): Promise<boolean> {
  const profile = req.user ? await db.getProfile(req.user.id) : null;
  return Boolean(profile && isAdminRole(profile.role));
}

// -------------------------------------------------------------------------
// USERNAME RESOLUTION (login by username)
// -------------------------------------------------------------------------
const handleResolveUsername = async (req: Request, res: Response) => {
  const username = sanitizeText(req.params.username || (req.query.username as string) || '', 40);
  if (!username || !USERNAME_RE.test(username)) {
    return fail(res, 400, 'ชื่อผู้ใช้ไม่ถูกต้อง');
  }
  const profile = await db.getProfileByUsername(username);
  if (profile?.email) return res.json({ success: true, email: profile.email });
  return fail(res, 404, 'ไม่พบชื่อผู้ใช้งานนี้ในระบบ');
};
app.get('/api/auth/resolve-username/:username', usernameLookupLimiter, wrap(handleResolveUsername));
app.get('/api/auth/resolve-username', usernameLookupLimiter, wrap(handleResolveUsername));

// -------------------------------------------------------------------------
// PROFILE
// -------------------------------------------------------------------------
app.post('/api/profile/sync', authSyncLimiter, requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  const email = (req.user!.email || '').toLowerCase();

  return locks.run(`profile_${userId}`, async () => {
    const existing = await db.getProfile(userId);

    const rawName = sanitizeText(req.body?.username, 40);
    const fullName = sanitizeText(req.body?.fullName, 60);
    const avatar = safeUrl(req.body?.avatarUrl, 400);

    if (existing) {
      // Never rewrite identity fields on every login — only fill in blanks
      const patch: Record<string, any> = {};
      if (!existing.full_name && fullName) patch.full_name = fullName;
      if (!existing.avatar_url && avatar) patch.avatar_url = avatar;
      const profile = Object.keys(patch).length ? await db.updateProfile(userId, patch) : existing;
      return res.json({ success: true, profile });
    }

    // New profile: derive a valid, UNIQUE username
    let base = (rawName || email.split('@')[0] || 'user').replace(/[^\p{L}\p{N}_.\-]/gu, '_').slice(0, 20);
    if (base.length < 3) base = (base + '___').slice(0, 3);
    let candidate = base;
    for (let i = 0; i < 6 && (await db.getProfileByUsername(candidate)); i++) {
      candidate = `${base}_${crypto.randomInt(1000, 9999)}`;
    }
    if (await db.getProfileByUsername(candidate)) {
      candidate = `user_${crypto.randomBytes(4).toString('hex')}`;
    }

    const profile = await db.upsertProfile({
      id: userId,
      email,
      username: candidate,
      full_name: fullName || rawName || candidate,
      avatar_url: avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(candidate)}`,
    });
    return res.json({ success: true, profile });
  });
}));

app.get('/api/profile/me', requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  let profile = await db.getProfile(userId);
  if (!profile) {
    const email = (req.user!.email || '').toLowerCase();
    profile = await db.upsertProfile({
      id: userId,
      email,
      username: `user_${crypto.randomBytes(4).toString('hex')}`,
    });
  }
  return res.json({ success: true, profile });
}));

// -------------------------------------------------------------------------
// PRODUCTS & STOCK
// -------------------------------------------------------------------------
function pickProductInput(body: any, partial: boolean): Partial<ServerProduct> | { error: string } {
  const out: Partial<ServerProduct> = {};
  const b = body || {};

  if (!partial || b.name !== undefined) {
    const name = sanitizeText(b.name, 160);
    if (!name) return { error: 'กรุณาระบุชื่อสินค้า' };
    out.name = name;
  }
  if (b.description !== undefined) out.description = sanitizeText(b.description, 4000);
  if (!partial || b.price !== undefined) {
    const price = finiteNumber(b.price, 0, 1_000_000);
    if (price === null) return { error: 'ราคาสินค้าไม่ถูกต้อง' };
    out.price = round2(price);
  }
  if (b.originalPrice !== undefined && b.originalPrice !== null && b.originalPrice !== '') {
    const op = finiteNumber(b.originalPrice, 0, 1_000_000);
    if (op === null) return { error: 'ราคาเดิมไม่ถูกต้อง' };
    out.originalPrice = round2(op);
  }
  if (b.stock !== undefined) {
    const stock = finiteNumber(b.stock, 0, 1_000_000);
    if (stock === null) return { error: 'จำนวนสต็อกไม่ถูกต้อง' };
    out.stock = Math.floor(stock);
  }
  if (b.soldCount !== undefined) {
    const sold = finiteNumber(b.soldCount, 0, 100_000_000);
    if (sold === null) return { error: 'ยอดขายไม่ถูกต้อง' };
    out.soldCount = Math.floor(sold);
  }
  if (b.imageUrl !== undefined) out.imageUrl = safeUrl(b.imageUrl);
  if (b.category !== undefined) out.category = sanitizeText(b.category, 80);
  if (b.tag !== undefined) out.tag = sanitizeText(b.tag, 40);
  if (b.isPopular !== undefined) out.isPopular = Boolean(b.isPopular);
  if (Array.isArray(b.stockData)) {
    const list: string[] = b.stockData
      .filter((s: unknown) => typeof s === 'string' && s.trim())
      .map((s: string) => s.trim().slice(0, 2000))
      .slice(0, 20000);
    out.stockData = list;
    out.stock = list.length;
  }
  return out;
}

app.get('/api/products', wrap(async (_req: Request, res: Response) => {
  const products = await db.getProducts();
  // NEVER expose stockData (the actual keys/accounts) to the public
  res.json(products.map(toPublicProduct));
}));

app.post('/api/products', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const input = pickProductInput(req.body, false);
  if ('error' in input) return fail(res, 400, input.error as string);
  const newProd = await db.createProduct(input);
  return res.json({ success: true, product: newProd, ...newProd });
}));

app.get('/api/products/:id', wrap(async (req: Request, res: Response) => {
  const prod = await db.getProductById(req.params.id);
  if (!prod) return fail(res, 404, 'ไม่พบสินค้านี้');
  // Admins may need the raw stock list (e.g. product editor); everyone else gets the public view.
  let asAdmin = false;
  try {
    const token = readBearer(req);
    const u = token ? await resolveUserFromToken(token) : null;
    const p = u ? await db.getProfile(u.id) : null;
    asAdmin = Boolean(p && isAdminRole(p.role));
  } catch {}
  return res.json(asAdmin ? prod : toPublicProduct(prod));
}));

app.put('/api/products/:id', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const input = pickProductInput(req.body, true);
  if ('error' in input) return fail(res, 400, input.error as string);
  const updated = await locks.run(`product_${req.params.id}`, () => db.updateProduct(req.params.id, input));
  if (!updated) return fail(res, 404, 'ไม่พบสินค้านี้');
  return res.json({ success: true, product: updated, ...updated });
}));

app.delete('/api/products/:id', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  await db.deleteProduct(req.params.id);
  return res.json({ success: true, message: 'ลบสินค้าสำเร็จ' });
}));

app.get('/api/products/:id/stock', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const prod = await db.getProductById(req.params.id);
  if (!prod) return fail(res, 404, 'ไม่พบสินค้านี้');
  return res.json({ stock: prod.stock, stockData: prod.stockData || [] });
}));

app.post('/api/products/:id/stock', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const { stock, stockData, newItems } = req.body || {};
  const clean = (arr: unknown[]) =>
    arr.filter((s): s is string => typeof s === 'string' && s.trim().length > 0).map((s) => s.trim().slice(0, 2000));

  const updated = await locks.run(`product_${req.params.id}`, async () => {
    const current = await db.getProductById(req.params.id);
    if (!current) return null;

    if (Array.isArray(newItems)) {
      // Append mode (used by the "add stock" dialog)
      const merged = [...(current.stockData || []), ...clean(newItems)].slice(0, 20000);
      return db.updateProduct(req.params.id, { stockData: merged, stock: merged.length });
    }
    if (Array.isArray(stockData)) {
      const list = clean(stockData).slice(0, 20000);
      return db.updateProduct(req.params.id, { stockData: list, stock: list.length });
    }
    if (stock !== undefined) {
      const n = finiteNumber(stock, 0, 1_000_000);
      if (n === null) return undefined;
      return db.updateProduct(req.params.id, { stock: Math.floor(n) });
    }
    return undefined;
  });

  if (updated === null) return fail(res, 404, 'ไม่พบสินค้านี้');
  if (updated === undefined) return fail(res, 400, 'ข้อมูลสต็อกไม่ถูกต้อง');
  return res.json({ success: true, product: updated });
}));

// -------------------------------------------------------------------------
// CATEGORIES
// -------------------------------------------------------------------------
function pickCategoryInput(body: any): any {
  const b = body || {};
  const out: Record<string, any> = {};
  if (b.id !== undefined) { const id = safeId(b.id); if (id) out.id = id; }
  if (b.name !== undefined) out.name = sanitizeText(b.name, 100);
  if (b.title !== undefined) out.title = sanitizeText(b.title, 140);
  if (b.subtitle !== undefined) out.subtitle = sanitizeText(b.subtitle, 300);
  if (b.bannerUrl !== undefined) out.bannerUrl = safeUrl(b.bannerUrl);
  if (b.imageUrl !== undefined) out.imageUrl = safeUrl(b.imageUrl);
  return out;
}

app.get('/api/categories', wrap(async (_req: Request, res: Response) => res.json(await db.getCategories())));

app.post('/api/categories', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const input = pickCategoryInput(req.body);
  if (!input.name && !input.title) return fail(res, 400, 'กรุณาระบุชื่อหมวดหมู่');
  const cat = await db.createCategory(input);
  return res.json({ success: true, category: cat, ...cat });
}));

app.put('/api/categories/:id', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const cat = await db.updateCategory(req.params.id, pickCategoryInput(req.body));
  if (!cat) return fail(res, 404, 'ไม่พบหมวดหมู่นี้');
  return res.json({ success: true, category: cat, ...cat });
}));

app.delete('/api/categories/:id', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  await db.deleteCategory(req.params.id);
  return res.json({ success: true, message: 'ลบหมวดหมู่สำเร็จ' });
}));

// -------------------------------------------------------------------------
// ATOMIC PURCHASE
// -------------------------------------------------------------------------
const MAX_QTY_PER_ORDER = 50;

app.post('/api/buy', buyLimiter, requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  const productId = safeId(req.body?.productId);
  const numQty = Math.floor(Number(req.body?.quantity ?? 1));

  if (!productId) return fail(res, 400, 'รหัสสินค้าไม่ถูกต้อง');
  if (!Number.isFinite(numQty) || numQty < 1 || numQty > MAX_QTY_PER_ORDER) {
    return fail(res, 400, `จำนวนต้องอยู่ระหว่าง 1 ถึง ${MAX_QTY_PER_ORDER} ชิ้น`);
  }

  const rawKey = req.headers['idempotency-key'];
  const idemHeader = typeof rawKey === 'string' ? rawKey.trim().slice(0, 128) : '';
  // Scope the key to the caller so one user can never replay another user's purchase
  const idemKey = idemHeader ? `${userId}:${idemHeader}` : '';

  if (idemKey) {
    const cached = buyIdempotencyStore.get(idemKey);
    if (cached) return res.json(cached);
  }

  // Lock BOTH the buyer (balance) and the product (stock) so concurrent
  // purchases can neither overspend a balance nor oversell the same key.
  return locks.run([`user_${userId}`, `product_${productId}`], async () => {
    if (idemKey) {
      const cached = buyIdempotencyStore.get(idemKey);
      if (cached) return res.json(cached);
    }

    const prod = await db.getProductById(productId);
    if (!prod) return fail(res, 404, 'ไม่พบสินค้านี้ในระบบ', 'PRODUCT_NOT_FOUND');

    const stockList = Array.isArray(prod.stockData) ? [...prod.stockData] : [];
    const hasItemStock = stockList.length > 0;
    const available = hasItemStock ? stockList.length : Number(prod.stock || 0);

    if (available < numQty) {
      return fail(res, 400, 'สินค้าในสต็อกไม่เพียงพอ', 'OUT_OF_STOCK');
    }

    const user = await db.getProfile(userId);
    if (!user) return fail(res, 401, 'กรุณาเข้าสู่ระบบก่อนทำรายการ', 'UNAUTHORIZED');

    const totalPrice = round2(Number(prod.price) * numQty);
    const balance = Number(user.balance || 0);
    if (balance + 1e-9 < totalPrice) {
      return fail(
        res,
        400,
        `ยอดเงินคงเหลือไม่เพียงพอ (ต้องการ ฿${totalPrice.toLocaleString()} แต่มี ฿${balance.toLocaleString()}) กรุณาเติมเงิน`,
        'INSUFFICIENT_BALANCE',
      );
    }

    // Deliver real stock items. Products without an item list are fulfilled manually
    // (we never fabricate redeemable-looking keys for the customer).
    const deliveredItems: string[] = hasItemStock ? stockList.splice(0, numQty) : [];
    const isManual = !hasItemStock;
    const newStock = hasItemStock ? stockList.length : Math.max(0, available - numQty);
    const newSold = Number(prod.soldCount || 0) + numQty;
    const newBalance = round2(Math.max(0, balance - totalPrice));

    // 1) stock -> 2) balance -> 3) order. Roll back on any failure.
    let stockWritten = false;
    let balanceWritten = false;
    try {
      const updatedProd = await db.updateProduct(productId, {
        stock: newStock,
        stockData: hasItemStock ? stockList : prod.stockData,
        soldCount: newSold,
      });
      stockWritten = true;

      const updatedUser = await db.updateProfile(userId, { balance: newBalance });
      balanceWritten = true;

      const deliveredStr = isManual
        ? 'รอแอดมินส่งมอบสินค้า — กรุณาติดต่อฝ่ายบริการลูกค้าพร้อมแจ้งเลขคำสั่งซื้อ'
        : deliveredItems.join('\n');
      const orderId = `ord-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
      const newOrder: ServerOrder = {
        id: orderId,
        orderId,
        user_id: userId,
        userId,
        uid: userId,
        username: user.username || 'User',
        product_id: prod.id,
        productId: prod.id,
        product_name: prod.name,
        productName: prod.name,
        price: totalPrice,
        amount: totalPrice,
        quantity: numQty,
        item_data: deliveredStr,
        itemData: deliveredStr,
        deliveredItem: deliveredStr,
        secretData: deliveredStr,
        status: isManual ? 'pending' : 'completed',
        created_at: new Date().toISOString(),
      };
      await db.createOrder(newOrder);

      const responsePayload = {
        success: true,
        message: isManual ? 'สั่งซื้อสำเร็จ! แอดมินจะส่งมอบสินค้าให้เร็วที่สุด' : 'สั่งซื้อสำเร็จ!',
        purchase: newOrder,
        updatedUser: {
          id: updatedUser?.id,
          username: updatedUser?.username,
          fullName: updatedUser?.full_name || updatedUser?.username,
          email: updatedUser?.email,
          balance: updatedUser?.balance,
          role: updatedUser?.role,
          rank: updatedUser?.rank,
          isPremium: updatedUser?.is_premium,
          avatarUrl: updatedUser?.avatar_url,
        },
        updatedProduct: toPublicProduct(updatedProd || { ...prod, stock: newStock }),
        item: deliveredStr,
        deliveredItem: deliveredStr,
        orderId,
        purchaseId: orderId,
        balance: newBalance,
        productName: prod.name,
        price: totalPrice,
      };

      if (idemKey) buyIdempotencyStore.set(idemKey, responsePayload);
      return res.json(responsePayload);
    } catch (err) {
      console.error('[Purchase] Failed, rolling back:', err);
      try {
        if (balanceWritten) await db.updateProfile(userId, { balance });
        if (stockWritten) {
          await db.updateProduct(productId, {
            stock: prod.stock,
            stockData: prod.stockData,
            soldCount: prod.soldCount,
          });
        }
      } catch (rollbackErr) {
        console.error('[Purchase] ROLLBACK FAILED — manual reconciliation needed:', { userId, productId, rollbackErr });
      }
      return fail(res, 500, 'ไม่สามารถทำรายการได้ในขณะนี้ ระบบได้คืนยอดเงินของคุณแล้ว กรุณาลองใหม่', 'PURCHASE_FAILED');
    }
  });
}));

// -------------------------------------------------------------------------
// USERS
// -------------------------------------------------------------------------
app.get('/api/users', ...requireAdmin, wrap(async (_req: Request, res: Response) => res.json(await db.listUsers())));

app.get('/api/users/:uid', requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const targetUid = req.params.uid;
  if (targetUid !== req.user!.id && !(await callerIsAdmin(req))) {
    return fail(res, 403, 'ไม่มีสิทธิ์เข้าถึงข้อมูลผู้ใช้อื่น', 'FORBIDDEN');
  }
  const profile = await db.getProfile(targetUid);
  if (!profile) return fail(res, 404, 'ไม่พบผู้ใช้นี้');
  return res.json(profile);
}));

app.post('/api/users/:uid', requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const targetUid = req.params.uid;
  const currentUid = req.user!.id;
  const isAdmin = await callerIsAdmin(req);

  if (targetUid !== currentUid && !isAdmin) {
    return fail(res, 403, 'ไม่มีสิทธิ์แก้ไขข้อมูลผู้ใช้อื่น', 'FORBIDDEN');
  }

  return locks.run(`user_${targetUid}`, async () => {
    const existing = await db.getProfile(targetUid);
    if (!existing) return fail(res, 404, 'ไม่พบผู้ใช้นี้');

    const b = req.body || {};
    const updates: Record<string, any> = {};

    // Fields every user may change on their own profile
    const fullName = b.fullName ?? b.full_name;
    if (fullName !== undefined) updates.full_name = sanitizeText(fullName, 60);
    const avatar = b.avatarUrl ?? b.avatar_url;
    if (avatar !== undefined) updates.avatar_url = safeUrl(avatar, 400);

    if (b.username !== undefined && b.username !== existing.username) {
      const uname = sanitizeText(b.username, 24);
      if (!USERNAME_RE.test(uname)) {
        return fail(res, 400, 'ชื่อผู้ใช้ต้องมี 3-24 ตัวอักษร (ตัวอักษร ตัวเลข _ . - เท่านั้น)');
      }
      const clash = await db.getProfileByUsername(uname);
      if (clash && clash.id !== targetUid) return fail(res, 409, 'ชื่อผู้ใช้นี้ถูกใช้งานแล้ว');
      updates.username = uname;
    }

    // Privileged fields: admins only
    if (isAdmin) {
      const selfEdit = targetUid === currentUid;
      if (b.role !== undefined && !selfEdit) {
        const role = sanitizeText(b.role, 20).toLowerCase();
        if (!['user', 'member', 'premium', 'vip', 'admin'].includes(role)) return fail(res, 400, 'บทบาทไม่ถูกต้อง');
        updates.role = role === 'member' ? 'user' : role;
      }
      if (b.balance !== undefined) {
        const bal = finiteNumber(b.balance, 0, 100_000_000);
        if (bal === null) return fail(res, 400, 'ยอดเงินไม่ถูกต้อง');
        updates.balance = round2(bal);
      }
      if (b.rank !== undefined) updates.rank = sanitizeText(b.rank, 20).toLowerCase();
      const prem = b.isPremium ?? b.is_premium;
      if (prem !== undefined) updates.is_premium = Boolean(prem);
      if (b.status !== undefined && !selfEdit) {
        const st = String(b.status).toLowerCase();
        if (!['active', 'banned'].includes(st)) return fail(res, 400, 'สถานะไม่ถูกต้อง');
        updates.status = st;
      }
    }

    if (Object.keys(updates).length === 0) return res.json({ success: true, user: existing, profile: existing });
    const updated = await db.updateProfile(targetUid, updates);
    return res.json({ success: true, user: updated, profile: updated });
  });
}));

app.delete('/api/users/:uid', requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const targetUid = req.params.uid;
  const isSelf = targetUid === req.user!.id;
  const isAdmin = await callerIsAdmin(req);

  if (!isSelf && !isAdmin) return fail(res, 403, 'ไม่มีสิทธิ์ลบผู้ใช้อื่น', 'FORBIDDEN');
  // An admin deleting their own account would risk locking the store out
  if (isSelf && isAdmin) return fail(res, 400, 'ผู้ดูแลระบบไม่สามารถลบบัญชีของตนเองได้ กรุณาโอนสิทธิ์ให้ผู้อื่นก่อน');

  await db.deleteUser(targetUid);
  try { await getFirebaseAuth().deleteUser(targetUid); } catch { /* may not exist in Firebase */ }
  return res.json({ success: true, message: 'ลบผู้ใช้สำเร็จ' });
}));

app.post('/api/users/:uid/password', requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const targetUid = req.params.uid;
  const isSelf = targetUid === req.user!.id;
  const isAdmin = await callerIsAdmin(req);
  if (!isSelf && !isAdmin) return fail(res, 403, 'ไม่มีสิทธิ์แก้ไขรหัสผ่านผู้ใช้อื่น', 'FORBIDDEN');

  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  if (password.length < 8 || password.length > 128) {
    return fail(res, 400, 'รหัสผ่านต้องมีความยาว 8-128 ตัวอักษร');
  }

  // Self-service changes require a recent sign-in
  if (isSelf && !isAdmin) {
    const authTime = req.user!.authTime;
    if (!authTime || Date.now() / 1000 - authTime > 10 * 60) {
      return fail(res, 401, 'กรุณาเข้าสู่ระบบใหม่อีกครั้งก่อนเปลี่ยนรหัสผ่าน', 'REAUTH_REQUIRED');
    }
  }

  try {
    await getFirebaseAuth().updateUser(targetUid, { password });
  } catch (err: any) {
    console.error('[Password] update failed:', err?.code || err);
    return fail(res, 500, 'ไม่สามารถเปลี่ยนรหัสผ่านได้ในขณะนี้');
  }
  return res.json({ success: true, message: 'เปลี่ยนรหัสผ่านเรียบร้อย' });
}));

// -------------------------------------------------------------------------
// LICENSE KEYS & REDEEM
// -------------------------------------------------------------------------
const generateKey = () => {
  const part = () => crypto.randomBytes(3).toString('hex').toUpperCase();
  return `ASTRAX-${part()}-${part()}-${part()}`;
};

function pickKeyInput(item: any): any | { error: string } {
  const src = typeof item === 'string' ? { key: item } : item || {};
  const type = ['balance', 'rank_premium', 'discount'].includes(src.type) ? src.type : 'balance';
  const value = src.value === undefined ? 100 : finiteNumber(src.value, 0, 1_000_000);
  if (value === null) return { error: 'มูลค่าคีย์ไม่ถูกต้อง' };
  const key = typeof src.key === 'string' && src.key.trim() ? src.key.trim().toUpperCase() : generateKey();
  if (!/^[A-Z0-9][A-Z0-9_\-]{5,63}$/.test(key)) return { error: 'รูปแบบคีย์ไม่ถูกต้อง (A-Z 0-9 _ - ยาว 6-64 ตัว)' };
  return { key, type, value: round2(value), description: sanitizeText(src.description, 200) || undefined };
}

app.get('/api/license_keys', ...requireAdmin, wrap(async (_req: Request, res: Response) => res.json(await db.getLicenseKeys())));

app.post('/api/license_keys', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const input = pickKeyInput(req.body);
  if ('error' in input) return fail(res, 400, input.error);
  return res.json({ success: true, key: await db.createLicenseKey(input) });
}));

app.post('/api/license_keys/bulk', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const keysInput = Array.isArray(req.body?.keys) ? req.body.keys : [];
  if (keysInput.length === 0 || keysInput.length > 500) return fail(res, 400, 'จำนวนคีย์ต้องอยู่ระหว่าง 1-500');
  const createdList = [];
  for (const k of keysInput) {
    const input = pickKeyInput(k);
    if ('error' in input) return fail(res, 400, input.error);
    createdList.push(await db.createLicenseKey(input));
  }
  return res.json({ success: true, count: createdList.length, keys: createdList });
}));

app.delete('/api/license_keys/:id', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const id = safeId(req.params.id);
  if (!id) return fail(res, 400, 'รหัสคีย์ไม่ถูกต้อง');
  await db.deleteLicenseKey(id);
  return res.json({ success: true, message: 'ลบคีย์สำเร็จ' });
}));

app.post('/api/license_keys/bulk_delete', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const ids = (Array.isArray(req.body?.ids) ? req.body.ids : []).map(safeId).filter(Boolean).slice(0, 2000);
  if (ids.length === 0) return fail(res, 400, 'ไม่พบรายการที่ต้องการลบ');
  return res.json({ success: true, deletedCount: await db.bulkDeleteLicenseKeys(ids) });
}));

app.get('/api/used_keys', requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  const profile = await db.getProfile(userId);
  const allKeys = await db.getLicenseKeys();
  const used = allKeys.filter((k) => k.is_used || k.isUsed);
  if (profile && isAdminRole(profile.role)) return res.json(used);

  const mine = used
    .filter((k) => k.used_by === userId || k.usedBy === userId || (profile?.username && k.used_by === profile.username))
    .map((k) => ({ ...k, uid: userId }));
  return res.json(mine);
}));

app.post('/api/redeem', redeemLimiter, requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  const key = req.body?.key;
  if (!key || typeof key !== 'string' || key.length > 64) return fail(res, 400, 'กรุณาระบุคีย์');
  const cleanKey = key.trim().toUpperCase();

  return locks.run([`redeem_${cleanKey}`, `user_${userId}`], async () => {
    const supa = db.getSupabaseClient();
    if (supa) {
      const { data, error } = await supa.rpc('redeem_license_key_for_user', { input_key: cleanKey, p_user_id: userId });
      if (!error && data) {
        const profile = await db.getProfile(userId);
        return res.json({
          success: true,
          message: 'ใช้งานคีย์สำเร็จ',
          amount: data.value,
          value: data.value,
          type: data.type,
          balance: profile?.balance ?? data.new_balance,
          rank: profile?.rank || 'user',
        });
      }
      const missingFn = error && (error.code === 'PGRST202' || /could not find the function/i.test(error.message || ''));
      if (error && !missingFn) {
        return fail(res, 400, 'คีย์ไม่ถูกต้องหรือถูกใช้งานไปแล้ว', 'INVALID_KEY');
      }
      // RPC not provisioned -> fall through to the in-process implementation
    }

    const result = await db.redeemKey(cleanKey, userId);
    if (!result.success) return fail(res, result.status || 400, result.error || 'คีย์ไม่ถูกต้อง', 'INVALID_KEY');
    return res.json(result);
  });
}));

// -------------------------------------------------------------------------
// BLOCKED IPS
// -------------------------------------------------------------------------
app.get('/api/blocked_ips', ...requireAdmin, wrap(async (_req: Request, res: Response) => res.json(db.getBlockedIPs())));

app.post('/api/blocked_ips', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const ip = normalizeIp(sanitizeText(req.body?.ip, 64));
  if (!net.isIP(ip)) return fail(res, 400, 'รูปแบบ IP Address ไม่ถูกต้อง');
  if (ip === normalizeIp(req.ip || '')) return fail(res, 400, 'ไม่สามารถบล็อค IP ของตนเองได้');
  const item = db.addBlockedIP(ip, sanitizeText(req.body?.reason, 200));
  return res.json({ success: true, item });
}));

app.delete('/api/blocked_ips/:ip', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  db.deleteBlockedIP(req.params.ip);
  return res.json({ success: true, message: 'ปลดบล็อค IP สำเร็จ' });
}));

// -------------------------------------------------------------------------
// SITE SETTINGS
// -------------------------------------------------------------------------
const SETTINGS_URL_FIELDS = ['contact_line', 'discord_link', 'facebook_link', 'instagram_link', 'popup_img_url', 'popup_link', 'spotify_url'];
const SETTINGS_TEXT_FIELDS: Record<string, number> = {
  site_name: 60,
  announcement_text: 1000,
  contact_email: 120,
  truewallet_phone: 20,
  promptpay_number: 40,
  promptpay_name: 100,
};

function pickSettingsInput(body: any): Record<string, any> {
  const b = body || {};
  const out: Record<string, any> = {};
  for (const f of SETTINGS_URL_FIELDS) if (b[f] !== undefined) out[f] = safeUrl(b[f]);
  for (const [f, max] of Object.entries(SETTINGS_TEXT_FIELDS)) if (b[f] !== undefined) out[f] = sanitizeText(b[f], max);
  if (out.site_name === '') delete out.site_name;
  if (b.popup_enabled !== undefined) out.popup_enabled = Boolean(b.popup_enabled);
  if (b.spotify_autoplay !== undefined) out.spotify_autoplay = Boolean(b.spotify_autoplay);
  for (const f of ['stats_users_offset', 'stats_sales_offset']) {
    if (b[f] !== undefined) {
      const n = finiteNumber(b[f], 0, 1_000_000_000);
      if (n !== null) out[f] = n;
    }
  }
  if (Array.isArray(b.banners)) out.banners = b.banners.map((x: unknown) => safeUrl(x)).filter(Boolean).slice(0, 20);
  return out;
}

app.get('/api/settings', wrap(async (_req: Request, res: Response) => res.json(await db.getSettings())));

app.post('/api/settings', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const settings = await db.updateSettings(pickSettingsInput(req.body));
  return res.json({ success: true, settings });
}));

// -------------------------------------------------------------------------
// CUSTOM PAGES
// -------------------------------------------------------------------------
const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 80);

function pickPageInput(body: any): any {
  const b = body || {};
  const out: Record<string, any> = {};
  if (b.title !== undefined) out.title = sanitizeText(b.title, 140);
  if (b.content !== undefined) out.content = typeof b.content === 'string' ? b.content.slice(0, 100_000) : '';
  if (b.slug !== undefined) { const s = slugify(String(b.slug)); if (s) out.slug = s; }
  return out;
}

app.get('/api/pages', (_req: Request, res: Response) => res.json(db.getPages()));

app.post('/api/pages', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const input = pickPageInput(req.body);
  if (!input.title) return fail(res, 400, 'กรุณาระบุชื่อหน้า');
  if (!input.slug) input.slug = slugify(input.title) || `page-${Date.now()}`;
  return res.json({ success: true, page: db.createPage(input) });
}));

app.put('/api/pages/:id', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const page = db.updatePage(req.params.id, pickPageInput(req.body));
  if (!page) return fail(res, 404, 'ไม่พบหน้านี้');
  return res.json({ success: true, page });
}));

app.delete('/api/pages/:id', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  db.deletePage(req.params.id);
  return res.json({ success: true, message: 'ลบหน้าสำเร็จ' });
}));

// -------------------------------------------------------------------------
// ORDERS / PURCHASES HISTORY
// -------------------------------------------------------------------------
app.get('/api/purchases', requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const isAdmin = await callerIsAdmin(req);
  const orders = await db.getOrders(isAdmin ? undefined : req.user!.id);

  const limitParam = req.query.limit;
  if (limitParam === undefined) return res.json(orders);

  const limit = Math.min(200, Math.max(1, Math.floor(Number(limitParam)) || 50));
  const offset = Math.max(0, Math.floor(Number(req.query.cursor)) || 0);
  const page = orders.slice(offset, offset + limit);
  const next = offset + limit < orders.length ? String(offset + limit) : null;
  return res.json({ data: page, nextCursor: next, total: orders.length });
}));

let latestCache: { at: number; data: any[] } = { at: 0, data: [] };
app.get('/api/latest-purchases', wrap(async (_req: Request, res: Response) => {
  if (Date.now() - latestCache.at > 15_000) {
    const orders = await db.getOrders();
    latestCache = {
      at: Date.now(),
      data: orders.slice(0, 15).map((o) => ({
        id: o.id,
        productName: o.product_name,
        amount: o.amount,
        username: o.username ? (o.username.length > 3 ? o.username.slice(0, 3) + '***' : 'User***') : 'User***',
        createdAt: o.created_at,
      })),
    };
  }
  return res.json(latestCache.data);
}));

// -------------------------------------------------------------------------
// TOPUPS
// -------------------------------------------------------------------------
app.get('/api/topups', requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const isAdmin = await callerIsAdmin(req);
  return res.json(await db.getTopups(isAdmin ? undefined : req.user!.id));
}));

// SECURITY: this endpoint previously credited ANY amount to ANY logged-in user with no
// payment verification. It is disabled until a real, verified TrueMoney integration exists.
app.post('/api/topup/truemoney', requireAuth, (_req: Request, res: Response) =>
  fail(res, 501, 'ระบบเติมเงินผ่าน TrueMoney ยังไม่เปิดให้บริการ กรุณาเติมเงินผ่านการโอนและแนบสลิป', 'NOT_IMPLEMENTED'),
);

// -------------------------------------------------------------------------
// LOGS SYSTEM
// -------------------------------------------------------------------------
app.get('/api/logs-system', (_req: Request, res: Response) => res.json(db.getLogsSystem()));

app.post('/api/logs-system', ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const b = req.body;
  if (!b || typeof b !== 'object' || Array.isArray(b) || JSON.stringify(b).length > 200_000) {
    return fail(res, 400, 'ข้อมูลไม่ถูกต้อง');
  }
  db.saveLogsSystem(b);
  return res.json({ success: true });
}));

// -------------------------------------------------------------------------
// STATS & HEALTH & CLIENT ERROR REPORTS
// -------------------------------------------------------------------------
let statsCache: { at: number; data: any } = { at: 0, data: null };
app.get('/api/stats', wrap(async (_req: Request, res: Response) => {
  if (!statsCache.data || Date.now() - statsCache.at > 30_000) {
    const s = await db.getStats();
    statsCache = { at: Date.now(), data: { ...s, totalTopupsAmount: s.topups } };
  }
  return res.json(statsCache.data);
}));

app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    clientIp: normalizeIp(req.ip || '') || '127.0.0.1',
    environment: isProduction ? 'production' : 'development',
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/log_error', errorLogLimiter, (req: Request, res: Response) => {
  const b = req.body || {};
  console.error('[ClientError]', {
    message: sanitizeText(b.message, 300),
    url: sanitizeText(b.url, 200),
    stack: sanitizeText(b.stack, 1500),
  });
  res.status(204).end();
});

// -------------------------------------------------------------------------
// IMAGE UPLOAD (admin only, magic-bytes validated, random file names)
// -------------------------------------------------------------------------
app.post('/api/upload', uploadLimiter, largeJson, ...requireAdmin, wrap(async (req: Request, res: Response) => {
  const bodyImg = req.body?.image || req.body?.file || req.body?.data || req.body?.img;
  if (typeof bodyImg !== 'string') return fail(res, 400, 'กรุณาอัปโหลดรูปภาพ');

  const buffer = Buffer.from(bodyImg.replace(/^data:image\/[\w+.-]+;base64,/, ''), 'base64');
  if (buffer.length === 0) return fail(res, 400, 'กรุณาอัปโหลดรูปภาพ');
  if (buffer.length > 8 * 1024 * 1024) return fail(res, 413, 'ไฟล์ใหญ่เกิน 8MB');

  const validation = validateImageMagicBytes(buffer);
  if (!validation.valid || !validation.ext) {
    return fail(res, 400, 'ไฟล์รูปภาพไม่ถูกต้อง รองรับเฉพาะไฟล์ JPEG, PNG, WEBP เท่านั้น');
  }

  const filename = `up_${Date.now()}_${crypto.randomBytes(6).toString('hex')}.${validation.ext}`;
  await fs.promises.mkdir(publicUploadsDir, { recursive: true });
  await fs.promises.writeFile(path.join(publicUploadsDir, filename), buffer, { flag: 'wx' });

  const publicUrl = `/uploads/${filename}`;
  return res.json({ success: true, url: publicUrl, imageUrl: publicUrl, ext: validation.ext });
}));

// -------------------------------------------------------------------------
// SLIP VERIFICATION
// -------------------------------------------------------------------------
const SLIP_ERROR_MESSAGES: Record<string, string> = {
  'bad-request': 'ข้อมูลคำขอไม่ถูกต้อง (Body ไม่ถูกต้อง)',
  'terms-not-accepted': 'ไม่ได้ยอมรับข้อกำหนด TOS / Privacy / EULA',
  'invalid-image': 'Base64 image ไม่ถูกต้อง หรือไฟล์รูปภาพเสียหาย',
  'qr-not-found': 'หา QR ในรูปไม่เจอ กรุณาถ่ายหรือแนบสลิปที่เห็น QR Code ชัดเจน',
  'invalid-qr': 'QR format ไม่ถูกต้อง หรือไม่ใช่ QR สลิปโอนเงินธนาคาร',
  'amount-not-found': 'OCR อ่านยอดเงินไม่ได้ กรุณาระบุยอดเงินให้ชัดเจน',
  'amount-not-verified': 'ยอดตรวจกับธนาคารไม่ผ่าน หรือยอดเงินที่ระบุไม่ตรงกับสลิป',
  'invalid-slip-data': 'ข้อมูลสลิปไม่สมบูรณ์',
  'slip-not-found': 'ไม่พบสลิปในระบบธนาคาร หรือสลิปยังไม่อัปเดต',
  'rate-limit-exceeded': 'เกินขีดจำกัดการตรวจสอบ กรุณารอสักครู่แล้วลองใหม่',
  'slip-already-used': 'สลิปนี้ถูกใช้งานไปแล้วในระบบ กรุณาใช้สลิปใหม่',
  'wrong-receiver': 'สลิปนี้ไม่ได้โอนเข้าบัญชีของร้านค้า',
  'slip-too-old': 'สลิปนี้เก่าเกินกำหนด กรุณาใช้สลิปที่เพิ่งโอน',
};

interface ProcessSlipOptions {
  img?: string;
  amount?: number | string;
  isNoSlip?: boolean;
  qrcode_data?: string;
  tos?: boolean;
  privacy?: boolean;
  eula?: boolean;
  userId: string;
}

/** Collect digit strings from every field whose key mentions "receiver"/"recipient". */
function collectReceiverDigits(node: any, out: string[] = [], inReceiver = false): string[] {
  if (node && typeof node === 'object') {
    for (const [k, v] of Object.entries(node)) {
      const hit = inReceiver || /receiver|recipient|to_account|toaccount/i.test(k);
      if (typeof v === 'string' || typeof v === 'number') {
        if (hit) out.push(String(v).replace(/\D/g, ''));
      } else {
        collectReceiverDigits(v, out, hit);
      }
    }
  }
  return out.filter(Boolean);
}

/**
 * A valid bank slip proves a transfer happened — NOT that it was paid to this shop.
 * When an expected receiver account is configured we require the slip's receiver
 * to match (banks mask digits, so we compare the last 4 digits).
 */
async function slipMatchesReceiver(slipData: any): Promise<boolean> {
  let expected = (process.env.SLIP_EXPECTED_RECEIVER || '').replace(/\D/g, '');
  if (!expected) {
    try { expected = String((await db.getSettings()).promptpay_number || '').replace(/\D/g, ''); } catch {}
  }
  if (!expected || expected.length < 4) return true; // not configured -> cannot enforce
  const tail = expected.slice(-4);
  const digits = collectReceiverDigits(slipData);
  if (digits.length === 0) return false; // configured but slip has no receiver info -> fail closed
  return digits.some((d) => d.includes(tail));
}

export async function executeSlipVerification(options: ProcessSlipOptions) {
  if (options.tos === false || options.privacy === false || options.eula === false) {
    return { status: 400, body: { success: false, slug: 'terms-not-accepted', error: SLIP_ERROR_MESSAGES['terms-not-accepted'] } as any };
  }

  const ronzyBase = (process.env.RONZY_SLIP_API_URL || 'https://ronzy.xyz').replace(/\/+$/, '');
  let targetUrl: string;
  let requestBody: any;

  const numericAmount = options.amount !== undefined && options.amount !== '' ? Number(options.amount) : undefined;
  const hasValidAmount = typeof numericAmount === 'number' && Number.isFinite(numericAmount) && numericAmount > 0 && numericAmount <= 200_000;
  if (options.amount !== undefined && options.amount !== '' && !hasValidAmount) {
    return { status: 400, body: { success: false, slug: 'bad-request', error: 'ยอดเงินไม่ถูกต้อง' } as any };
  }

  if (options.isNoSlip) {
    if (!hasValidAmount) {
      return { status: 400, body: { success: false, slug: 'bad-request', error: 'ต้องระบุยอดเงิน (amount)' } as any };
    }
    const qrCode = (options.qrcode_data || '').trim();
    if (!qrCode || qrCode.length > 4000) {
      return { status: 422, body: { success: false, slug: 'qr-not-found', error: 'ไม่พบข้อมูล qrcode_data' } as any };
    }
    targetUrl = `${ronzyBase}/api/slip/${numericAmount}/no_slip`;
    requestBody = { qrcode_data: qrCode, tos: true, privacy: true, eula: true };
  } else {
    let imgData = (options.img || '').trim();
    if (!imgData) {
      return { status: 400, body: { success: false, slug: 'invalid-image', error: 'กรุณาอัปโหลดรูปภาพสลิปโอนเงิน' } as any };
    }
    const raw = imgData.replace(/^data:image\/[\w+.-]+;base64,/, '');
    const head = Buffer.from(raw.slice(0, 64), 'base64');
    // Pad so the 12-byte magic-number check has enough bytes
    if (!validateImageMagicBytes(Buffer.concat([head, Buffer.alloc(12)])).valid) {
      return { status: 400, body: { success: false, slug: 'invalid-image', error: SLIP_ERROR_MESSAGES['invalid-image'] } as any };
    }
    if (!imgData.startsWith('data:')) imgData = `data:image/jpeg;base64,${imgData}`;
    targetUrl = hasValidAmount ? `${ronzyBase}/api/slip/${numericAmount}` : `${ronzyBase}/api/slip`;
    requestBody = { img: imgData, tos: true, privacy: true, eula: true };
  }

  let ronzyRes: any;
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json', 'User-Agent': 'Astrax-Store/1.0' };
    if (process.env.RONZY_API_KEY) headers['X-API-Key'] = process.env.RONZY_API_KEY;
    ronzyRes = await axios.post(targetUrl, requestBody, {
      headers,
      timeout: 30000,
      maxBodyLength: 16 * 1024 * 1024,
      validateStatus: () => true,
    });
  } catch {
    return { status: 502, body: { success: false, slug: 'bad-request', error: 'ไม่สามารถติดต่อเซิร์ฟเวอร์ตรวจสอบสลิปได้ กรุณาลองใหม่อีกครั้ง' } as any };
  }

  const resData = ronzyRes.data || {};
  if (ronzyRes.status !== 200) {
    const slug = typeof resData.slug === 'string' ? resData.slug : ronzyRes.status === 404 ? 'slip-not-found' : 'bad-request';
    const thaiError = SLIP_ERROR_MESSAGES[slug] || 'เกิดข้อผิดพลาดในการตรวจสอบสลิป';
    const status = ronzyRes.status >= 400 && ronzyRes.status < 600 ? ronzyRes.status : 400;
    return { status, body: { success: false, slug, error: thaiError } as any };
  }

  const slipData = resData.data || {};
  const transRef = String(slipData.ref || slipData.transRef || '').trim();
  if (!transRef || transRef.length > 100) {
    return { status: 422, body: { success: false, slug: 'invalid-slip-data', error: 'ไม่สามารถระบุเลขอ้างอิง (ref) จากผลตรวจสลิปได้' } as any };
  }

  // Amount credited = amount proven by the bank lookup. (The client-requested amount is
  // only a fallback because the upstream already rejects mismatches with `amount-not-verified`.)
  const slipAmount = round2(Number(slipData.amount ?? (hasValidAmount ? numericAmount : 0)));
  if (!Number.isFinite(slipAmount) || slipAmount <= 0 || slipAmount > 200_000) {
    return { status: 422, body: { success: false, slug: 'amount-not-verified', error: 'ยอดเงินในสลิปไม่ถูกต้อง' } as any };
  }

  if (!(await slipMatchesReceiver(slipData))) {
    return { status: 400, body: { success: false, slug: 'wrong-receiver', error: SLIP_ERROR_MESSAGES['wrong-receiver'] } as any };
  }

  const maxAgeHours = Number(process.env.SLIP_MAX_AGE_HOURS || 0);
  if (maxAgeHours > 0 && slipData.date) {
    const t = Date.parse(slipData.date);
    if (Number.isFinite(t) && Date.now() - t > maxAgeHours * 3600 * 1000) {
      return { status: 400, body: { success: false, slug: 'slip-too-old', error: SLIP_ERROR_MESSAGES['slip-too-old'] } as any };
    }
  }

  // Serialise per user + per slip so double-submits can never credit twice
  return locks.run([`user_${options.userId}`, `slip_${transRef.toUpperCase()}`], async () => {
    if (slipStore.isUsed(transRef)) {
      return { status: 400, body: { success: false, slug: 'slip-already-used', error: SLIP_ERROR_MESSAGES['slip-already-used'] } as any };
    }

    const user = await db.getProfile(options.userId);
    if (!user) return { status: 401, body: { success: false, error: 'ไม่พบผู้ใช้งาน' } as any };

    const recorded = await slipStore.recordSlip(transRef, slipAmount, options.userId, slipData);
    if (!recorded) {
      return { status: 400, body: { success: false, slug: 'slip-already-used', error: SLIP_ERROR_MESSAGES['slip-already-used'] } as any };
    }

    try {
      const newBal = round2(Number(user.balance || 0) + slipAmount);
      await db.updateProfile(options.userId, { balance: newBal });
      await db.recordTopup({
        id: 'tu-' + transRef,
        user_id: options.userId,
        username: user.username || 'User',
        type: 'promptpay_slip',
        amount: slipAmount,
        reference_no: transRef,
        status: 'approved',
        created_at: new Date().toISOString(),
      });

      return {
        status: 200,
        body: {
          success: true,
          message: 'ตรวจสอบสลิปและเติมเงินสำเร็จ',
          fromCache: resData.fromCache ?? false,
          data: slipData,
          amount: slipAmount,
          balance: newBal,
          transRef,
          topup: {
            id: transRef,
            amount: slipAmount,
            userId: options.userId,
            date: slipData.date || new Date().toISOString(),
            status: 'success',
            title: `โอนเงินผ่านสลิป (${transRef})`,
          },
        } as any,
      };
    } catch (err) {
      console.error('[Slip] Crediting failed, releasing slip:', err);
      try { await db.updateProfile(options.userId, { balance: Number(user.balance || 0) }); } catch {}
      await slipStore.release(transRef);
      return { status: 500, body: { success: false, error: 'เติมเงินไม่สำเร็จ กรุณาลองใหม่อีกครั้ง' } as any };
    }
  });
}

const slipBody = (req: Request) => ({
  img: req.body?.img || req.body?.imageBase64 || req.body?.image,
  tos: req.body?.tos,
  privacy: req.body?.privacy,
  eula: req.body?.eula,
});

app.post('/api/slip', slipRateLimiter, largeJson, requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const result = await executeSlipVerification({ ...slipBody(req), amount: req.body?.amount, userId: req.user!.id });
  return res.status(result.status).json(result.body);
}));

app.post('/api/slip/:amount', slipRateLimiter, largeJson, requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const result = await executeSlipVerification({ ...slipBody(req), amount: req.params.amount, userId: req.user!.id });
  return res.status(result.status).json(result.body);
}));

app.post('/api/slip/:amount/no_slip', slipRateLimiter, requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const result = await executeSlipVerification({
    ...slipBody(req),
    amount: req.params.amount,
    isNoSlip: true,
    qrcode_data: req.body?.qrcode_data || req.body?.qr,
    userId: req.user!.id,
  });
  return res.status(result.status).json(result.body);
}));

app.post('/api/topup/slip', slipRateLimiter, largeJson, requireAuth, wrap(async (req: AuthenticatedRequest, res: Response) => {
  const result = await executeSlipVerification({
    ...slipBody(req),
    tos: req.body?.tos ?? true,
    privacy: req.body?.privacy ?? true,
    eula: req.body?.eula ?? true,
    amount: req.body?.amount,
    userId: req.user!.id,
  });
  return res.status(result.status).json(result.body);
}));

// -------------------------------------------------------------------------
// API 404 + ERROR HANDLING
// -------------------------------------------------------------------------
app.use('/api', (_req: Request, res: Response) => fail(res, 404, 'ไม่พบ API ที่ร้องขอ', 'NOT_FOUND'));

app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
  if (res.headersSent) return;
  // body-parser errors
  if (err?.type === 'entity.too.large') return fail(res, 413, 'ข้อมูลที่ส่งมีขนาดใหญ่เกินกำหนด', 'PAYLOAD_TOO_LARGE');
  if (err?.type === 'entity.parse.failed') return fail(res, 400, 'รูปแบบข้อมูลไม่ถูกต้อง', 'BAD_JSON');

  console.error(`[Error] ${req.method} ${req.originalUrl}:`, err);
  // Never leak internal error messages to clients in production
  return fail(res, 500, isProduction ? 'เกิดข้อผิดพลาดภายในระบบ กรุณาลองใหม่อีกครั้ง' : String(err?.message || err), 'INTERNAL_ERROR');
});

process.on('unhandledRejection', (reason) => console.error('[unhandledRejection]', reason));

// -------------------------------------------------------------------------
// STATIC ASSETS & VITE INTEGRATION
// -------------------------------------------------------------------------
async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    // Hashed build assets are immutable; the HTML shell must always revalidate
    app.use('/assets', express.static(path.join(distPath, 'assets'), { immutable: true, maxAge: '1y', index: false }));
    app.use(express.static(distPath, { index: false, maxAge: '1h' }));
    app.get('*', (_req: Request, res: Response) => {
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT} in ${isProduction ? 'production' : 'development'} mode`);
  });

  const shutdown = (signal: string) => {
    console.log(`[Shutdown] ${signal} received, closing server...`);
    db.flush();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

// Only auto-start when run directly, not during unit tests
if (process.env.NODE_ENV !== 'test') {
  startServer();
}

export { app };