const select = (selector) => document.querySelector(selector);
const selectAll = (selector) => [...document.querySelectorAll(selector)];

const resourceButton = selectAll('#site-nav button').find((button) => button.textContent.includes('สินค้า'));
if (resourceButton) {
  const menu = document.createElement('div');
  menu.className = 'resource-menu';
  menu.hidden = true;
  menu.id = 'resources-menu';
  menu.innerHTML = ['ไอดีเกม', 'ซอร์สโค้ด', 'รายการสินค้า', 'วิธีสั่งซื้อ', 'ติดต่อร้าน'].map((title) => `<a href="https://getartcraft.com/${title.toLowerCase().replaceAll(' ', '-')}" target="_blank" rel="noopener noreferrer">${title}</a>`).join('');
  resourceButton.parentElement.append(menu);
  resourceButton.setAttribute('aria-controls', menu.id);
  resourceButton.addEventListener('click', () => {
    menu.hidden = !menu.hidden;
    resourceButton.setAttribute('aria-expanded', String(!menu.hidden));
    resourceButton.setAttribute('data-state', menu.hidden ? 'closed' : 'open');
  });
  document.addEventListener('click', (event) => {
    if (!resourceButton.parentElement.contains(event.target)) {
      menu.hidden = true;
      resourceButton.setAttribute('aria-expanded', 'false');
    }
  });
}

const mobileButton = select('[aria-controls="mobile-nav"]');
const mobileMenu = document.createElement('div');
mobileMenu.id = 'mobile-nav';
mobileMenu.hidden = true;
mobileMenu.innerHTML = '<a href="/">หน้าแรก</a><a href="/create-image">ไอดีเกม</a><a href="/create-video">ซอร์สโค้ด</a><a href="#features">สินค้า</a><a href="https://getartcraft.com/tutorials" target="_blank" rel="noopener noreferrer">หมวดสินค้า</a><a href="#start" data-download>เลือกสินค้า</a><a href="mailto:hello@storyteller.ai">ติดต่อร้าน</a><a href="https://getartcraft.com/apps" target="_blank" rel="noopener noreferrer">หมวดสินค้าทั้งหมด</a><a href="/create-image">ดูสินค้า ↗</a>';
select('#site-nav').append(mobileMenu);
mobileButton?.addEventListener('click', () => {
  mobileMenu.hidden = !mobileMenu.hidden;
  mobileButton.setAttribute('aria-expanded', String(!mobileMenu.hidden));
});
mobileMenu.addEventListener('click', (event) => {
  if (event.target.closest('a')) {
    mobileMenu.hidden = true;
    mobileButton?.setAttribute('aria-expanded', 'false');
  }
});

const sun = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/></svg>';
const moon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 12.5A9 9 0 1 1 11.5 3a6 6 0 0 0 9.5 9.5Z"/></svg>';
function updateTheme(theme) {
  document.documentElement.dataset.theme = theme;
  selectAll('#site-nav button[aria-label*="theme"]').forEach((button) => {
    button.innerHTML = theme === 'dark' ? sun : moon;
    button.setAttribute('aria-label', `Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`);
  });
}
updateTheme(localStorage.getItem('artcraft-theme') || 'dark');
selectAll('#site-nav button[aria-label*="theme"]').forEach((button) => button.addEventListener('click', () => {
  const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  updateTheme(next);
  localStorage.setItem('artcraft-theme', next);
}));

let activeDialog;
function openDialog(content, className = '') {
  activeDialog?.remove();
  const dialog = document.createElement('dialog');
  dialog.className = className;
  dialog.innerHTML = `<button class="dialog-close" aria-label="Close dialog">×</button>${content}`;
  document.body.append(dialog);
  dialog.querySelector('.dialog-close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener('close', () => dialog.remove());
  dialog.showModal();
  activeDialog = dialog;
}
document.addEventListener('click', (event) => {
  if (event.target.closest('[data-download]')) {
    event.preventDefault();
    openDialog('<div class="dialog-inner"><h2>Take your studio with you.</h2><p>Free and open source. Choose your desktop platform to view the official ArtCraft downloads.</p><div class="dialog-actions"><a href="https://getartcraft.com/download" target="_blank" rel="noopener noreferrer">macOS ↗</a><a href="https://getartcraft.com/download" target="_blank" rel="noopener noreferrer">Windows ↗</a><a href="/create-image">Use on web →</a></div></div>');
  }
  const film = event.target.closest('[data-film]');
  if (film) {
    openDialog(`<iframe src="https://www.youtube.com/embed/${film.dataset.film}?autoplay=1" title="KODDYKUB item preview" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`, 'film-dialog');
  }
});

const sections = ['hero', 'features', 'ownership', 'made-with', 'start']
  .map((id) => ({ id, element: select(`#${id}`) }))
  .filter((section) => section.element);
const queue = select('.section-queue');
const sectionLinks = selectAll('[data-section]');
const progressFill = select('.scroll-progress__fill');
let frameQueued = false;
let currentSection = '';
let previousProgress = -1;

function updateScrollUI() {
  frameQueued = false;
  const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  const progress = Math.min(1, Math.max(0, window.scrollY / maxScroll));
  let nextSection = 'hero';
  const threshold = window.innerHeight * .45;

  // Read all layout values before any DOM writes to avoid forced synchronous layout.
  for (const section of sections) {
    if (section.element.getBoundingClientRect().top < threshold) nextSection = section.id;
  }

  if (progressFill && Math.abs(progress - previousProgress) > .001) {
    progressFill.style.transform = `scaleY(${progress})`;
    previousProgress = progress;
  }

  if (nextSection !== currentSection) {
    currentSection = nextSection;
    queue.classList.toggle('at-home', nextSection === 'hero');
    for (const link of sectionLinks) {
      link.classList.toggle('active', link.dataset.section === nextSection && nextSection !== 'hero');
    }
  }
}

function scheduleScrollUI() {
  if (frameQueued) return;
  frameQueued = true;
  requestAnimationFrame(updateScrollUI);
}

window.addEventListener('scroll', scheduleScrollUI, { passive: true });
window.addEventListener('resize', scheduleScrollUI, { passive: true });
scheduleScrollUI();

const pageLoader = select('#page-loader');
const loaderStartedAt = performance.now();
let loaderDismissed = false;
function dismissPageLoader() {
  if (!pageLoader || loaderDismissed) return;
  const remaining = Math.max(0, 180 - (performance.now() - loaderStartedAt));
  if (remaining > 0) {
    window.setTimeout(dismissPageLoader, remaining);
    return;
  }
  loaderDismissed = true;
  pageLoader.classList.add('is-hidden');
  pageLoader.setAttribute('aria-hidden', 'true');
  pageLoader.setAttribute('inert', '');
  window.setTimeout(() => pageLoader.remove(), 520);
}
window.addEventListener('load', dismissPageLoader, { once: true });
window.setTimeout(dismissPageLoader, 2400);
if (document.readyState === 'complete') dismissPageLoader();

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const revealObserver = !reduceMotion && 'IntersectionObserver' in window
  ? new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-revealed');
        entry.target.inert = false;
        observer.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.12 })
  : null;

const revealSections = selectAll('main > section:not(#hero), main footer, body > footer');
for (const section of revealSections) {
  const candidates = [...section.querySelectorAll('h2, h3, p, .grid > *, article, figure')]
    .filter((element) => {
      if (element.matches('h2, h3, p') && element.closest('.grid')) return false;
      return !element.closest('#hero, .page-loader');
    });
  let order = 0;
  for (const element of candidates) {
    if (element.hasAttribute('data-scroll-reveal')) continue;
    element.setAttribute('data-scroll-reveal', '');
    element.style.setProperty('--reveal-delay', `${Math.min(order * 55, 275)}ms`);
    order += 1;
    if (revealObserver) {
      element.inert = true;
      revealObserver.observe(element);
    }
    else element.classList.add('is-revealed');
  }
}

const hero = select('#hero');
if (hero && 'IntersectionObserver' in window) {
  const heroVisibilityObserver = new IntersectionObserver(([entry]) => {
    hero.classList.toggle('is-offscreen', !entry.isIntersecting);
  }, { rootMargin: '80px' });
  heroVisibilityObserver.observe(hero);
}

const videoObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) entry.target.play().catch(() => {});
    else entry.target.pause();
  });
}, { rootMargin: '150px' });
selectAll('#features video').forEach((video) => videoObserver.observe(video));

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    mobileMenu.hidden = true;
    mobileButton?.setAttribute('aria-expanded', 'false');
    const resourceMenu = select('#resources-menu');
    if (resourceMenu) resourceMenu.hidden = true;
    resourceButton?.setAttribute('aria-expanded', 'false');
  }
});
