import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

export interface ServerProfile {
  id: string;
  email: string;
  username: string;
  full_name?: string;
  fullName?: string;
  role: 'admin' | 'user' | string;
  rank: 'user' | 'basic' | 'premium' | string;
  balance: number;
  is_premium: boolean;
  isPremium?: boolean;
  avatar_url?: string;
  avatarUrl?: string;
  /** 'active' | 'banned' */
  status?: string;
  created_at: string;
  updated_at: string;
}

export interface ServerProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  soldCount?: number;
  imageUrl: string;
  stock: number;
  category?: string;
  isPopular?: boolean;
  tag?: string;
  stockData?: string[];
  created_at?: string;
}

export interface ServerCategory {
  id: string;
  name: string;
  title: string;
  subtitle: string;
  bannerUrl: string;
  imageUrl?: string;
  created_at?: string;
}

export interface ServerOrder {
  id: string;
  orderId?: string;
  user_id: string;
  userId?: string;
  uid?: string;
  username: string;
  product_id: string;
  productId?: string;
  product_name: string;
  productName?: string;
  price: number;
  amount: number;
  quantity?: number;
  item_data: string;
  itemData?: string;
  deliveredItem?: string;
  secretData?: string;
  status: 'completed' | 'pending';
  created_at: string;
  date?: string;
  timestamp?: string;
}

export interface ServerTopup {
  id: string;
  user_id: string;
  userId?: string;
  uid?: string;
  username: string;
  type: string;
  amount: number;
  money?: number;
  reference_no: string;
  referenceNo?: string;
  status: 'approved' | 'pending' | 'rejected';
  created_at: string;
  date?: string;
}

export interface ServerLicenseKey {
  id: string;
  key: string;
  type: 'balance' | 'rank_premium' | 'discount';
  value: number;
  description: string;
  is_used: boolean;
  isUsed?: boolean;
  used_by?: string;
  usedBy?: string;
  used_at?: string;
  usedAt?: string;
  created_at: string;
}

export interface ServerBlockedIP {
  id: string;
  ip: string;
  reason: string;
  blocked_at: string;
  blockedAt?: string;
}

export interface ServerSiteSettings {
  id?: string;
  site_name: string;
  announcement_text?: string;
  contact_line?: string;
  discord_link?: string;
  facebook_link?: string;
  instagram_link?: string;
  contact_email?: string;
  truewallet_phone?: string;
  promptpay_number?: string;
  promptpay_name?: string;
  popup_enabled?: boolean;
  popup_img_url?: string;
  popup_link?: string;
  stats_users_offset: number;
  stats_sales_offset: number;
  banners?: string[];
  spotify_url?: string;
  spotify_autoplay?: boolean;
  updated_at?: string;
}

/** Strip fields that must never reach the public (the real keys/accounts in stock). */
export function toPublicProduct<T extends Partial<ServerProduct>>(p: T): Omit<T, 'stockData'> {
  const { stockData: _omit, ...rest } = p as any;
  return rest;
}

export interface ServerPage {
  id: string;
  slug?: string;
  title: string;
  content: string;
  updatedAt?: string;
}

const DEFAULT_PROFILES: ServerProfile[] = [
  {
    id: "demo-admin-001",
    email: "admin@astrax.store",
    username: "admin",
    fullName: "System Administrator",
    role: "admin",
    rank: "premium",
    balance: 5000,
    is_premium: true,
    isPremium: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "demo-user-002",
    email: "user@astrax.store",
    username: "demo_user",
    fullName: "Demo User",
    role: "user",
    rank: "user",
    balance: 500,
    is_premium: false,
    isPremium: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

const DEFAULT_CATEGORIES: ServerCategory[] = [
  {
    id: "social",
    name: "Social",
    title: "Social",
    subtitle: "YouTube Premium, Netflix, Discord Nitro, Bilibili, iQIYI, Prime Video",
    bannerUrl: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?auto=format&fit=crop&w=600&q=80",
  },
  {
    id: "social_account",
    name: "Social Account",
    title: "Social Account",
    subtitle: "Facebook, Twitter / X, Instagram, TikTok ไอดีคุณภาพสูง",
    bannerUrl: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=600&q=80",
  },
  {
    id: "ai_account",
    name: "AI Account",
    title: "AI Account",
    subtitle: "ChatGPT Plus, Canva Pro, Claude Pro, Midjourney AI",
    bannerUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=600&q=80",
  },
  {
    id: "game_accounts",
    name: "Game Accounts",
    title: "Game Accounts",
    subtitle: "Valorant, RoV, Genshin Impact, Free Fire พร้อมรับประกัน",
    bannerUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80",
  },
  {
    id: "software_tools",
    name: "Software Tools",
    title: "Software Tools",
    subtitle: "Windows 11 Pro, Office 365, VPN และบอทบริการอัตโนมัติ",
    bannerUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80",
  }
];

const DEFAULT_PRODUCTS: ServerProduct[] = [
  // Social Category (11 Products)
  {
    id: "yt_premium_30d",
    name: "Youtube Premium 30 วัน ไม่ต่อเมล",
    description: "ฟังเพลงแบบไม่มีโฆษณาคั่น ดาวน์โหลดดูออฟไลน์ได้ เล่นเบื้องหลังได้ 100%",
    price: 59,
    originalPrice: 159,
    soldCount: 342,
    imageUrl: "https://images.unsplash.com/photo-1543783207-ec64e4d95325?auto=format&fit=crop&w=600&q=80",
    stock: 4,
    category: "Social",
    isPopular: true,
    tag: "HOT SALE",
    stockData: ["YT-PREM-CODE-991A", "YT-PREM-CODE-992B", "YT-PREM-CODE-993C", "YT-PREM-CODE-994D"]
  },
  {
    id: "netflix_4k_30d_private",
    name: "Netflix 4K 30 วัน ส่วนตัว",
    description: "รับชมภาพยนตร์ Ultra HD 4K รองรับทุกอุปกรณ์ มือถือ ทีวี จอส่วนตัว",
    price: 129,
    originalPrice: 419,
    soldCount: 198,
    imageUrl: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?auto=format&fit=crop&w=600&q=80",
    stock: 0,
    category: "Social",
    isPopular: true,
    tag: "HOT SALE",
    stockData: []
  },
  {
    id: "nitro_promo_3m",
    name: "Nitro Promo 3 เดือน",
    description: "ไนโตรบูสต์ 3 เดือน เติมได้ทันที ไม่ต้องเข้าเช็คบัญชี หรือผ่านรหัสผ่าน",
    price: 89,
    originalPrice: 299,
    soldCount: 420,
    imageUrl: "https://images.unsplash.com/photo-1614680376593-902f749f7ffc?auto=format&fit=crop&w=600&q=80",
    stock: 22,
    category: "Social",
    isPopular: true,
    tag: "HOT SALE",
    stockData: ["NITRO-3M-A1", "NITRO-3M-B2", "NITRO-3M-C3"]
  },
  {
    id: "bilibili_prem_30d",
    name: "Bilibili Premium 30 วัน",
    description: "รับชมอนิเมะความคมชัด 4K พากย์ไทย ครบทุกตอนก่อนใคร ไม่มีโฆษณา",
    price: 35,
    originalPrice: 99,
    soldCount: 88,
    imageUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80",
    stock: 0,
    category: "Social",
    isPopular: true,
    tag: "HOT",
    stockData: []
  },
  {
    id: "iqiyi_vip_30d",
    name: "iQIYI VIP 30 วัน",
    description: "ดูซีรีส์เกาหลี ซีรีส์จีน และรายการวาไรตี้ระดับ VIP Full HD",
    price: 29,
    originalPrice: 119,
    soldCount: 156,
    imageUrl: "https://images.unsplash.com/photo-1578022761797-b8636ac1773c?auto=format&fit=crop&w=600&q=80",
    stock: 4,
    category: "Social",
    isPopular: true,
    tag: "HOT",
    stockData: ["IQIYI-VIP-30D-KEY1", "IQIYI-VIP-30D-KEY2", "IQIYI-VIP-30D-KEY3", "IQIYI-VIP-30D-KEY4"]
  },
  {
    id: "prime_video_30d",
    name: "Prime Video 30 วัน",
    description: "Amazon Prime Video สตรีมภาพยนตร์และซีรีส์ระดับพรีเมียม",
    price: 49,
    originalPrice: 149,
    soldCount: 75,
    imageUrl: "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&w=600&q=80",
    stock: 10,
    category: "Social",
    isPopular: false,
    tag: "HOT",
    stockData: ["PRIME-30D-K1", "PRIME-30D-K2"]
  },
  {
    id: "netflix_profile_30d",
    name: "Netflix 4K จอแยก (1 จอ)",
    description: "Netflix 4K แชร์จอคุณภาพสูง มีพินล็อคจอเฉพาะตัว ไม่ชนเวลาดู",
    price: 79,
    originalPrice: 169,
    soldCount: 230,
    imageUrl: "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?auto=format&fit=crop&w=600&q=80",
    stock: 15,
    category: "Social",
    isPopular: true,
    tag: "HOT",
    stockData: ["NFLX-SCR-K1", "NFLX-SCR-K2"]
  },
  {
    id: "wetv_vip_30d",
    name: "WeTV VIP 30 วัน",
    description: "WeTV สตรีมมิ่ง VIP ดูซีรีส์ ละคร และการ์ตูนจีนพากย์ไทย",
    price: 39,
    originalPrice: 119,
    soldCount: 92,
    imageUrl: "https://images.unsplash.com/photo-1586899028174-e7098604235b?auto=format&fit=crop&w=600&q=80",
    stock: 8,
    category: "Social",
    isPopular: false,
    tag: "HOT",
    stockData: ["WETV-VIP-01", "WETV-VIP-02"]
  },
  {
    id: "spotify_prem_3m",
    name: "Spotify Individual 3 เดือน",
    description: "ฟังเพลงแบบไม่มีโฆษณา เพลิดเพลินกับเสียงคุณภาพสูงแบบ Hi-Fi ไม่มีข้อผูกมัด",
    price: 149,
    originalPrice: 389,
    soldCount: 115,
    imageUrl: "https://images.unsplash.com/photo-1614680376593-902f749f7ffc?auto=format&fit=crop&w=600&q=80",
    stock: 12,
    category: "Social",
    isPopular: false,
    tag: "คุ้มค่า",
    stockData: ["SPOTIFY-3M-01", "SPOTIFY-3M-02"]
  },
  {
    id: "disney_plus_30d",
    name: "Disney+ Hotstar 30 วัน",
    description: "ภาพยนตร์ Marvel, Disney, Star Wars และซีรีส์ดังระดับโลก คมชัดระดับ 4K",
    price: 69,
    originalPrice: 189,
    soldCount: 65,
    imageUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80",
    stock: 6,
    category: "Social",
    isPopular: false,
    tag: "แนะนำ",
    stockData: ["DISNEY-30D-K1", "DISNEY-30D-K2"]
  },
  {
    id: "tiktok_coins_pkg",
    name: "TikTok Coins Gift Pack",
    description: "เหรียญ TikTok ส่งของขวัญให้ครีเอเตอร์ที่คุณชื่นชอบ ส่งตรงเข้าไอดี",
    price: 99,
    originalPrice: 149,
    soldCount: 45,
    imageUrl: "https://images.unsplash.com/photo-1598128558393-70ff21433be0?auto=format&fit=crop&w=600&q=80",
    stock: 18,
    category: "Social",
    isPopular: false,
    tag: "ยอดนิยม",
    stockData: ["TIKTOK-COIN-01", "TIKTOK-COIN-02"]
  },

  // Social Account Category (4 Products)
  {
    id: "fb_acc_old_2018",
    name: "Facebook Account Old 2018+",
    description: "ไอดีเฟสบุ๊คปีเก่า 2018+ ยืนยันตัวตนแล้ว พร้อมใช้งาน ยิงแอดได้",
    price: 85,
    originalPrice: 180,
    soldCount: 88,
    imageUrl: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=600&q=80",
    stock: 12,
    category: "Social Account",
    isPopular: true,
    tag: "HOT",
    stockData: ["FB-OLD2018-01", "FB-OLD2018-02"]
  },
  {
    id: "twitter_x_verified",
    name: "Twitter / X Verified Account",
    description: "บัญชีทวิตเตอร์ (X) ติ๊กฟ้า Verified ยืนยันเรียบร้อย พร้อมเปลี่ยนข้อมูล",
    price: 150,
    originalPrice: 350,
    soldCount: 42,
    imageUrl: "https://images.unsplash.com/photo-1611605698335-8b1569810432?auto=format&fit=crop&w=600&q=80",
    stock: 4,
    category: "Social Account",
    isPopular: true,
    tag: "HOT",
    stockData: ["TWITTER-X-K1", "TWITTER-X-K2"]
  },
  {
    id: "ig_aged_2020",
    name: "Instagram Aged 2020+",
    description: "ไอดีไอจีสร้างปี 2020 ไม่โดนตรวจจับ ปลอดภัยสำหรับทำคอนเทนต์",
    price: 95,
    originalPrice: 200,
    soldCount: 60,
    imageUrl: "https://images.unsplash.com/photo-1611262588024-d12430b98920?auto=format&fit=crop&w=600&q=80",
    stock: 7,
    category: "Social Account",
    isPopular: false,
    tag: "แนะนำ",
    stockData: ["IG-AGED2020-01", "IG-AGED2020-02"]
  },
  {
    id: "tiktok_1k_followers",
    name: "TikTok 1k+ Followers (Live Ready)",
    description: "ไอดีติ๊กต๊อกผู้ติดตาม 1,000+ คน พร้อมเปิดไลฟ์สดได้ทันที ไม่ติดเงื่อนไข",
    price: 120,
    originalPrice: 280,
    soldCount: 77,
    imageUrl: "https://images.unsplash.com/photo-1598128558393-70ff21433be0?auto=format&fit=crop&w=600&q=80",
    stock: 5,
    category: "Social Account",
    isPopular: true,
    tag: "HOT",
    stockData: ["TIKTOK-1K-01", "TIKTOK-1K-02"]
  },

  // AI Account Category (4 Products)
  {
    id: "chatgpt_plus_gpt4o",
    name: "ChatGPT Plus (GPT-4o)",
    description: "บัญชี ChatGPT Plus ตัวท็อป เข้าถึง GPT-4o, DALL-E 3 และ Voice Mode ล่าสุด",
    price: 199,
    originalPrice: 750,
    soldCount: 310,
    imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=600&q=80",
    stock: 5,
    category: "AI Account",
    isPopular: true,
    tag: "HOT",
    stockData: ["GPT4O-PLUS-01", "GPT4O-PLUS-02"]
  },
  {
    id: "canva_pro_lifetime",
    name: "Canva Pro Lifetime Edu",
    description: "ปลดล็อกเทมเพลตและฟังก์ชัน Pro ทั้งหมดใน Canva ตลอดชีพ ไม่ต้องจ่ายรายเดือน",
    price: 49,
    originalPrice: 290,
    soldCount: 520,
    imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80",
    stock: 30,
    category: "AI Account",
    isPopular: true,
    tag: "HOT",
    stockData: ["CANVA-EDU-K1", "CANVA-EDU-K2", "CANVA-EDU-K3"]
  },
  {
    id: "claude_pro_35",
    name: "Claude Pro 3.5 Sonnet",
    description: "เข้าใช้งาน Claude 3.5 Sonnet โมเดล AI เขียนโค้ดและทำงานเร็วที่สุด",
    price: 249,
    originalPrice: 800,
    soldCount: 140,
    imageUrl: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=600&q=80",
    stock: 3,
    category: "AI Account",
    isPopular: true,
    tag: "HOT",
    stockData: ["CLAUDE-PRO-01", "CLAUDE-PRO-02"]
  },
  {
    id: "midjourney_std",
    name: "Midjourney Standard Plan",
    description: "บอทวาดภาพ AI อัจฉริยะ สร้างภาพคมชัดสูง สไตล์ photorealistic ไร้ขีดจำกัด",
    price: 299,
    originalPrice: 1100,
    soldCount: 88,
    imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80",
    stock: 6,
    category: "AI Account",
    isPopular: false,
    tag: "HOT",
    stockData: ["MIDJOURNEY-STD-01", "MIDJOURNEY-STD-02"]
  }
];

const DEFAULT_SETTINGS: ServerSiteSettings = {
  id: "default",
  site_name: "DekCode Shop",
  announcement_text: "ยินดีต้อนรับสู่ DekCode Shop ศูนย์รวมซอร์สโค้ด สคริปต์ และบริการดิจิทัลระดับมืออาชีพ จัดส่งอัตโนมัติ 100%",
  contact_line: "",
  discord_link: "https://discord.gg/dekcode",
  facebook_link: "",
  contact_email: "support@dekcode.shop",
  popup_enabled: false,
  popup_img_url: "",
  popup_link: "",
  stats_users_offset: 0,
  stats_sales_offset: 0,
  banners: []
};

interface AppDataStore {
  profiles: ServerProfile[];
  products: ServerProduct[];
  categories: ServerCategory[];
  orders: ServerOrder[];
  topups: ServerTopup[];
  licenseKeys: ServerLicenseKey[];
  blockedIPs: ServerBlockedIP[];
  settings: ServerSiteSettings;
  pages: ServerPage[];
  logsSystem: any;
}

export class ServerDatabase {
  private filePath: string;
  private memoryData: AppDataStore;
  private supabase: SupabaseClient | null = null;
  private saveTimer: NodeJS.Timeout | null = null;
  private dirty = false;

  /**
   * In production with Supabase configured, Supabase is the single source of truth.
   * Local JSON is a development convenience only: money-critical reads must never silently
   * fall back to a stale local copy, and failed remote writes must surface as errors.
   */
  private get strict(): boolean {
    return Boolean(this.supabase) && process.env.NODE_ENV === 'production';
  }

  /** Check a Supabase result. supabase-js does NOT throw on failure — it returns { error }. */
  private remote(label: string, result: { error: any } | null | undefined) {
    const error = result?.error;
    if (!error) return;
    const msg = `[ServerDatabase] Supabase ${label} failed: ${error.message || error}`;
    if (this.strict) throw new Error(msg);
    console.warn(msg);
  }

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      try { fs.mkdirSync(dataDir, { recursive: true }); } catch {}
    }
    this.filePath = path.resolve(dataDir, 'app_store.json');
    this.memoryData = this.loadInitialData();
    this.normalizeStock();
    if (!fs.existsSync(this.filePath)) {
      this.flush();
    }
    this.initSupabase();
  }

  /** Keep `stock` consistent with the real item list wherever an item list exists. */
  private normalizeStock() {
    for (const p of this.memoryData.products) {
      if (Array.isArray(p.stockData) && p.stockData.length > 0) p.stock = p.stockData.length;
    }
  }

  private initSupabase() {
    const supabaseUrl = (process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '').trim();
    const supabaseKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '').trim();
    if (supabaseUrl && supabaseKey && supabaseUrl.startsWith('https://')) {
      try {
        this.supabase = createClient(supabaseUrl, supabaseKey, {
          auth: { persistSession: false }
        });
        console.log(`[ServerDatabase] Supabase client connected (${supabaseUrl})`);
      } catch (err) {
        console.warn('[ServerDatabase] Supabase init warning:', err);
      }
    }
  }

  public getSupabaseClient(): SupabaseClient | null {
    return this.supabase;
  }

  private loadInitialData(): AppDataStore {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          profiles: Array.isArray(parsed.profiles) && parsed.profiles.length > 0 ? parsed.profiles : [...DEFAULT_PROFILES],
          products: Array.isArray(parsed.products) && parsed.products.length > 0 ? parsed.products : [...DEFAULT_PRODUCTS],
          categories: Array.isArray(parsed.categories) && parsed.categories.length > 0 ? parsed.categories : [...DEFAULT_CATEGORIES],
          orders: Array.isArray(parsed.orders) ? parsed.orders : [],
          topups: Array.isArray(parsed.topups) ? parsed.topups : [],
          licenseKeys: Array.isArray(parsed.licenseKeys) ? parsed.licenseKeys : [],
          blockedIPs: Array.isArray(parsed.blockedIPs) ? parsed.blockedIPs : [],
          settings: parsed.settings ? { ...DEFAULT_SETTINGS, ...parsed.settings } : { ...DEFAULT_SETTINGS },
          pages: Array.isArray(parsed.pages) ? parsed.pages : [],
          logsSystem: parsed.logsSystem || { categories: [], items: [], isVip: false }
        };
      }
    } catch (e) {
      console.error('[ServerDatabase] Error reading data file:', e);
    }

    return {
      profiles: [...DEFAULT_PROFILES],
      products: [...DEFAULT_PRODUCTS],
      categories: [...DEFAULT_CATEGORIES],
      orders: [],
      topups: [],
      licenseKeys: [],
      blockedIPs: [],
      settings: { ...DEFAULT_SETTINGS },
      pages: [],
      logsSystem: { categories: [], items: [], isVip: false }
    };
  }

  /** Debounced write: bursts of changes are coalesced into a single atomic file write. */
  private save() {
    this.dirty = true;
    if (this.saveTimer) return;
    this.saveTimer = setTimeout(() => {
      this.saveTimer = null;
      this.flush();
    }, 150);
    this.saveTimer.unref?.();
  }

  /** Write immediately (used on shutdown and first boot). */
  public flush() {
    if (this.saveTimer) {
      clearTimeout(this.saveTimer);
      this.saveTimer = null;
    }
    if (!this.dirty && fs.existsSync(this.filePath)) return;
    try {
      const tempPath = `${this.filePath}.tmp.${process.pid}.${Date.now()}`;
      fs.writeFileSync(tempPath, JSON.stringify(this.memoryData), 'utf-8');
      fs.renameSync(tempPath, this.filePath);
      this.dirty = false;
    } catch (err) {
      console.error('[ServerDatabase] Atomic file write failed:', err);
    }
  }

  // PROFILES / USERS
  public async getProfile(userId: string): Promise<ServerProfile | null> {
    if (this.supabase) {
      try {
        const { data, error } = await this.supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .single();
        if (!error && data) {
          return {
            id: data.id,
            email: data.email,
            username: data.username,
            full_name: data.full_name || data.username,
            fullName: data.full_name || data.username,
            role: data.role || 'user',
            rank: data.rank || 'user',
            balance: Number(data.balance || 0),
            is_premium: Boolean(data.is_premium),
            isPremium: Boolean(data.is_premium),
            avatar_url: data.avatar_url,
            avatarUrl: data.avatar_url,
            status: data.status || 'active',
            created_at: data.created_at || new Date().toISOString(),
            updated_at: data.updated_at || new Date().toISOString()
          };
        }
        // PGRST116 = no rows. Anything else is a real failure.
        if (error && (error as any).code !== 'PGRST116' && this.strict) {
          throw new Error(`[ServerDatabase] getProfile failed: ${error.message}`);
        }
      } catch (e) {
        if (this.strict) throw e;
      }
      if (this.strict) return null;
    }

    const local = this.memoryData.profiles.find(p => p.id === userId);
    return local ? { ...local } : null;
  }

  public async getProfileByUsername(username: string): Promise<ServerProfile | null> {
    const cleanUser = username.trim().toLowerCase();
    if (this.supabase) {
      try {
        const { data, error } = await this.supabase
          .from('profiles')
          .select('*')
          .ilike('username', cleanUser.replace(/[\\%_]/g, (m) => '\\' + m))
          .limit(1)
          .maybeSingle();
        if (!error && data) {
          return {
            id: data.id,
            email: data.email,
            username: data.username,
            full_name: data.full_name,
            fullName: data.full_name,
            role: data.role,
            rank: data.rank,
            balance: Number(data.balance || 0),
            is_premium: Boolean(data.is_premium),
            avatar_url: data.avatar_url,
            created_at: data.created_at,
            updated_at: data.updated_at
          };
        }
      } catch {}
      if (this.strict) return null;
    }

    const local = this.memoryData.profiles.find(p => (p.username || '').toLowerCase() === cleanUser);
    return local ? { ...local } : null;
  }

  public async listUsers(): Promise<ServerProfile[]> {
    if (this.supabase) {
      try {
        const { data, error } = await this.supabase
          .from('profiles')
          .select('*')
          .order('created_at', { ascending: false });
        if (!error && Array.isArray(data)) {
          return data.map(p => ({
            id: p.id,
            email: p.email,
            username: p.username,
            full_name: p.full_name || p.username,
            fullName: p.full_name || p.username,
            role: p.role || 'user',
            rank: p.rank || 'user',
            balance: Number(p.balance || 0),
            is_premium: Boolean(p.is_premium),
            isPremium: Boolean(p.is_premium),
            avatar_url: p.avatar_url,
            status: p.status || 'active',
            created_at: p.created_at,
            updated_at: p.updated_at
          }));
        }
      } catch {}
      if (this.strict) throw new Error('[ServerDatabase] listUsers failed');
    }

    return [...this.memoryData.profiles];
  }

  public async upsertProfile(profile: Partial<ServerProfile> & { id: string }): Promise<ServerProfile> {
    const now = new Date().toISOString();
    const existing = await this.getProfile(profile.id);

    const merged: ServerProfile = {
      id: profile.id,
      email: profile.email || existing?.email || '',
      username: profile.username || existing?.username || profile.email?.split('@')[0] || 'User',
      full_name: profile.full_name || profile.fullName || existing?.full_name || profile.username || 'User',
      fullName: profile.full_name || profile.fullName || existing?.full_name || profile.username || 'User',
      role: profile.role || existing?.role || 'user',
      rank: profile.rank || existing?.rank || 'user',
      balance: profile.balance !== undefined ? Number(profile.balance) : (existing?.balance || 0),
      is_premium: profile.is_premium !== undefined ? Boolean(profile.is_premium) : (existing ? Boolean(existing.is_premium) : false),
      isPremium: profile.is_premium !== undefined ? Boolean(profile.is_premium) : (existing ? Boolean(existing.is_premium) : false),
      avatar_url: profile.avatar_url || profile.avatarUrl || existing?.avatar_url,
      avatarUrl: profile.avatar_url || profile.avatarUrl || existing?.avatar_url,
      created_at: existing?.created_at || now,
      updated_at: now
    };

    // Update in memory & disk
    const idx = this.memoryData.profiles.findIndex(p => p.id === profile.id);
    if (idx !== -1) {
      this.memoryData.profiles[idx] = merged;
    } else {
      this.memoryData.profiles.push(merged);
    }
    this.save();

    // Sync to Supabase
    if (this.supabase) {
      try {
        this.remote('profile upsert', await this.supabase.from('profiles').upsert([{
          id: merged.id,
          email: merged.email,
          username: merged.username,
          full_name: merged.full_name,
          role: merged.role,
          rank: merged.rank,
          balance: merged.balance,
          is_premium: merged.is_premium,
          avatar_url: merged.avatar_url,
          updated_at: now
        }]));
      } catch (err) {
        if (this.strict) throw err;
        console.warn('[ServerDatabase] Supabase profile upsert warning:', err);
      }
    }

    return merged;
  }

  public async updateProfile(userId: string, updates: Partial<ServerProfile>): Promise<ServerProfile | null> {
    const existing = await this.getProfile(userId);
    if (!existing) return null;

    // Whitelist: callers can never overwrite id / email / created_at through this method
    const allowed = ['username', 'full_name', 'fullName', 'role', 'rank', 'balance', 'is_premium', 'isPremium', 'avatar_url', 'avatarUrl', 'status'];
    const safe: Record<string, any> = {};
    for (const k of allowed) {
      if ((updates as any)[k] !== undefined) safe[k] = (updates as any)[k];
    }
    if (safe.balance !== undefined) {
      const b = Number(safe.balance);
      if (!Number.isFinite(b) || b < 0) throw new Error('Invalid balance');
      safe.balance = Math.round((b + Number.EPSILON) * 100) / 100;
    }

    const updated: ServerProfile = {
      ...existing,
      ...safe,
      updated_at: new Date().toISOString()
    };
    if (safe.fullName !== undefined) updated.full_name = safe.fullName;
    updated.fullName = updated.full_name;
    if (safe.isPremium !== undefined) updated.is_premium = Boolean(safe.isPremium);
    updated.isPremium = updated.is_premium;
    if (safe.avatarUrl !== undefined) updated.avatar_url = safe.avatarUrl;
    updated.avatarUrl = updated.avatar_url;

    if (this.supabase) {
      try {
        const payload: any = { updated_at: updated.updated_at };
        if (safe.username !== undefined) payload.username = safe.username;
        if (safe.full_name !== undefined || safe.fullName !== undefined) payload.full_name = safe.full_name ?? safe.fullName;
        if (safe.role !== undefined) payload.role = safe.role;
        if (safe.rank !== undefined) payload.rank = safe.rank;
        if (safe.balance !== undefined) payload.balance = safe.balance;
        if (safe.is_premium !== undefined || safe.isPremium !== undefined) {
          payload.is_premium = Boolean(safe.is_premium ?? safe.isPremium);
        }
        if (safe.avatar_url !== undefined || safe.avatarUrl !== undefined) payload.avatar_url = safe.avatar_url ?? safe.avatarUrl;
        if (safe.status !== undefined) payload.status = safe.status;

        this.remote('profile update', await this.supabase.from('profiles').update(payload).eq('id', userId));
      } catch (err) {
        if (this.strict) throw err;
        console.warn('[ServerDatabase] Supabase profile update warning:', err);
      }
    }

    const idx = this.memoryData.profiles.findIndex(p => p.id === userId);
    if (idx !== -1) {
      this.memoryData.profiles[idx] = updated;
    } else if (!this.strict) {
      this.memoryData.profiles.push(updated);
    }
    this.save();

    return updated;
  }

  public async deleteUser(userId: string): Promise<boolean> {
    this.memoryData.profiles = this.memoryData.profiles.filter(p => p.id !== userId);
    this.save();

    if (this.supabase) {
      try {
        this.remote('profile delete', await this.supabase.from('profiles').delete().eq('id', userId));
      } catch (err) {
        if (this.strict) throw err;
      }
    }
    return true;
  }

  // PRODUCTS
  public async getProducts(): Promise<ServerProduct[]> {
    if (this.supabase) {
      try {
        const { data, error } = await this.supabase
          .from('products')
          .select('*')
          .order('created_at', { ascending: false });
        if (!error && Array.isArray(data) && data.length > 0) {
          return data.map(p => ({
            id: p.id,
            name: p.name,
            description: p.description,
            price: Number(p.price || 0),
            originalPrice: p.original_price ? Number(p.original_price) : undefined,
            soldCount: Number(p.sold_count || 0),
            imageUrl: p.image_url,
            stock: Number(p.stock || 0),
            category: p.category,
            isPopular: Boolean(p.is_popular),
            tag: p.tag,
            stockData: Array.isArray(p.stock_data) ? p.stock_data : [],
            created_at: p.created_at
          }));
        }
        if (error && this.strict) throw new Error(`[ServerDatabase] getProducts failed: ${error.message}`);
        if (!error && this.strict) return [];
      } catch (e) {
        if (this.strict) throw e;
      }
    }

    return [...this.memoryData.products];
  }

  public async getProductById(id: string): Promise<ServerProduct | null> {
    if (this.supabase) {
      try {
        const { data, error } = await this.supabase
          .from('products')
          .select('*')
          .eq('id', id)
          .single();
        if (!error && data) {
          return {
            id: data.id,
            name: data.name,
            description: data.description,
            price: Number(data.price || 0),
            originalPrice: data.original_price ? Number(data.original_price) : undefined,
            soldCount: Number(data.sold_count || 0),
            imageUrl: data.image_url,
            stock: Number(data.stock || 0),
            category: data.category,
            isPopular: Boolean(data.is_popular),
            tag: data.tag,
            stockData: Array.isArray(data.stock_data) ? data.stock_data : [],
            created_at: data.created_at
          };
        }
        if (error && (error as any).code !== 'PGRST116' && this.strict) {
          throw new Error(`[ServerDatabase] getProductById failed: ${error.message}`);
        }
      } catch (e) {
        if (this.strict) throw e;
      }
      if (this.strict) return null;
    }

    const local = this.memoryData.products.find(p => p.id === id);
    return local ? { ...local } : null;
  }

  public async createProduct(prod: Partial<ServerProduct>): Promise<ServerProduct> {
    const id = prod.id || 'prod_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex');
    if (this.memoryData.products.some(p => p.id === id)) throw new Error('Product id already exists');
    const newProd: ServerProduct = {
      id,
      name: prod.name || 'Unnamed Product',
      description: prod.description || '',
      price: Number(prod.price || 0),
      originalPrice: prod.originalPrice ? Number(prod.originalPrice) : undefined,
      soldCount: Number(prod.soldCount || 0),
      imageUrl: prod.imageUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
      stock: Number(prod.stock || 0),
      category: prod.category || 'general',
      isPopular: Boolean(prod.isPopular),
      tag: prod.tag || '',
      stockData: Array.isArray(prod.stockData) ? prod.stockData : [],
      created_at: new Date().toISOString()
    };

    this.memoryData.products.unshift(newProd);
    this.save();

    if (this.supabase) {
      try {
        this.remote('product insert', await this.supabase.from('products').insert([{
          id: newProd.id,
          name: newProd.name,
          description: newProd.description,
          price: newProd.price,
          original_price: newProd.originalPrice,
          sold_count: newProd.soldCount,
          image_url: newProd.imageUrl,
          stock: newProd.stock,
          category: newProd.category,
          is_popular: newProd.isPopular,
          tag: newProd.tag,
          stock_data: newProd.stockData
        }]));
      } catch (err) {
        if (this.strict) throw err;
        console.warn('[ServerDatabase] Supabase createProduct warning:', err);
      }
    }

    return newProd;
  }

  public async updateProduct(id: string, updates: Partial<ServerProduct>): Promise<ServerProduct | null> {
    const existing = await this.getProductById(id);
    if (!existing) return null;

    const { id: _ignoreId, created_at: _ignoreCreated, ...safeUpdates } = updates as any;
    const merged: ServerProduct = {
      ...existing,
      ...safeUpdates
    };
    if (Array.isArray(merged.stockData) && merged.stockData.length > 0) merged.stock = merged.stockData.length;

    if (this.supabase) {
      try {
        const payload: any = {};
        if (updates.name !== undefined) payload.name = updates.name;
        if (updates.description !== undefined) payload.description = updates.description;
        if (updates.price !== undefined) payload.price = Number(updates.price);
        if (updates.originalPrice !== undefined) payload.original_price = updates.originalPrice;
        if (updates.soldCount !== undefined) payload.sold_count = Number(updates.soldCount);
        if (updates.imageUrl !== undefined) payload.image_url = updates.imageUrl;
        if (updates.stock !== undefined) payload.stock = Number(updates.stock);
        if (updates.category !== undefined) payload.category = updates.category;
        if (updates.isPopular !== undefined) payload.is_popular = updates.isPopular;
        if (updates.tag !== undefined) payload.tag = updates.tag;
        if (updates.stockData !== undefined) payload.stock_data = updates.stockData;

        this.remote('product update', await this.supabase.from('products').update(payload).eq('id', id));
      } catch (err) {
        if (this.strict) throw err;
        console.warn('[ServerDatabase] Supabase updateProduct warning:', err);
      }
    }

    const idx = this.memoryData.products.findIndex(p => p.id === id);
    if (idx !== -1) {
      this.memoryData.products[idx] = merged;
      this.save();
    }

    return merged;
  }

  public async deleteProduct(id: string): Promise<boolean> {
    this.memoryData.products = this.memoryData.products.filter(p => p.id !== id);
    this.save();

    if (this.supabase) {
      try {
        this.remote('product delete', await this.supabase.from('products').delete().eq('id', id));
      } catch (err) {
        if (this.strict) throw err;
      }
    }
    return true;
  }

  // CATEGORIES
  public async getCategories(): Promise<ServerCategory[]> {
    if (this.supabase) {
      try {
        const { data, error } = await this.supabase
          .from('categories')
          .select('*')
          .order('created_at', { ascending: true });
        if (!error && Array.isArray(data) && data.length > 0) {
          return data.map(c => ({
            id: c.id,
            name: c.name,
            title: c.title || c.name,
            subtitle: c.subtitle || '',
            bannerUrl: c.banner_url || '',
            imageUrl: c.image_url || '',
            created_at: c.created_at
          }));
        }
      } catch {}
    }

    return [...this.memoryData.categories];
  }

  public async createCategory(cat: Partial<ServerCategory>): Promise<ServerCategory> {
    const id = cat.id || 'cat_' + Date.now() + '_' + crypto.randomBytes(2).toString('hex');
    const newCat: ServerCategory = {
      id,
      name: cat.name || 'New Category',
      title: cat.title || cat.name || 'New Category',
      subtitle: cat.subtitle || '',
      bannerUrl: cat.bannerUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
      imageUrl: cat.imageUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
      created_at: new Date().toISOString()
    };

    this.memoryData.categories.push(newCat);
    this.save();

    if (this.supabase) {
      try {
        this.remote('category insert', await this.supabase.from('categories').insert([{
          id: newCat.id,
          name: newCat.name,
          title: newCat.title,
          subtitle: newCat.subtitle,
          banner_url: newCat.bannerUrl,
          image_url: newCat.imageUrl
        }]));
      } catch (err) {
        if (this.strict) throw err;
      }
    }

    return newCat;
  }

  public async updateCategory(id: string, updates: Partial<ServerCategory>): Promise<ServerCategory | null> {
    const idx = this.memoryData.categories.findIndex(c => c.id === id);
    if (idx === -1 && !this.supabase) return null;

    const { id: _ignoreId, ...safeUpdates } = updates as any;
    const base = idx !== -1
      ? this.memoryData.categories[idx]
      : ({ id, name: '', title: '', subtitle: '', bannerUrl: '' } as ServerCategory);
    const updated = { ...base, ...safeUpdates, id };
    if (idx !== -1) this.memoryData.categories[idx] = updated;
    else this.memoryData.categories.push(updated);
    this.save();

    if (this.supabase) {
      try {
        const payload: any = {};
        if (updates.name) payload.name = updates.name;
        if (updates.title) payload.title = updates.title;
        if (updates.subtitle !== undefined) payload.subtitle = updates.subtitle;
        if (updates.bannerUrl) payload.banner_url = updates.bannerUrl;
        if (updates.imageUrl) payload.image_url = updates.imageUrl;
        this.remote('category update', await this.supabase.from('categories').update(payload).eq('id', id));
      } catch (err) {
        if (this.strict) throw err;
      }
    }

    return updated;
  }

  public async deleteCategory(id: string): Promise<boolean> {
    this.memoryData.categories = this.memoryData.categories.filter(c => c.id !== id);
    this.save();

    if (this.supabase) {
      try {
        this.remote('category delete', await this.supabase.from('categories').delete().eq('id', id));
      } catch (err) {
        if (this.strict) throw err;
      }
    }
    return true;
  }

  // ORDERS / PURCHASES
  public async getOrders(userId?: string): Promise<ServerOrder[]> {
    if (this.supabase) {
      try {
        let query = this.supabase.from('orders').select('*').order('created_at', { ascending: false });
        if (userId) {
          query = query.eq('user_id', userId);
        }
        const { data, error } = await query;
        if (!error && Array.isArray(data)) {
          return data.map(o => ({
            id: o.id,
            orderId: o.id,
            user_id: o.user_id,
            userId: o.user_id,
            uid: o.user_id,
            username: o.username || 'User',
            product_id: o.product_id,
            productId: o.product_id,
            product_name: o.product_name,
            productName: o.product_name,
            price: Number(o.price || 0),
            amount: Number(o.amount || o.price || 0),
            quantity: Number(o.quantity || 1),
            item_data: o.item_data || '',
            itemData: o.item_data || '',
            deliveredItem: o.item_data || '',
            secretData: o.item_data || '',
            status: o.status || 'completed',
            created_at: o.created_at,
            date: o.created_at,
            timestamp: o.created_at
          }));
        }
      } catch {}
      if (this.strict) throw new Error('[ServerDatabase] getOrders failed');
    }

    if (userId) {
      return this.memoryData.orders.filter(o => o.user_id === userId || o.userId === userId || o.uid === userId);
    }
    return [...this.memoryData.orders];
  }

  public async createOrder(order: ServerOrder): Promise<ServerOrder> {
    this.memoryData.orders.unshift(order);
    this.save();

    if (this.supabase) {
      try {
        this.remote('order insert', await this.supabase.from('orders').insert([{
          id: order.id,
          user_id: order.user_id,
          username: order.username,
          product_id: order.product_id,
          product_name: order.product_name,
          price: order.price,
          amount: order.amount,
          quantity: order.quantity || 1,
          item_data: order.item_data,
          status: order.status,
          created_at: order.created_at
        }]));
      } catch (err) {
        if (this.strict) throw err;
        console.warn('[ServerDatabase] Supabase createOrder warning:', err);
      }
    }

    return order;
  }

  // LICENSE KEYS
  public async getLicenseKeys(): Promise<ServerLicenseKey[]> {
    if (this.supabase) {
      try {
        const { data, error } = await this.supabase
          .from('license_keys')
          .select('*')
          .order('created_at', { ascending: false });
        if (!error && Array.isArray(data)) {
          return data.map(k => ({
            id: k.id,
            key: k.key,
            type: k.type || 'balance',
            value: Number(k.value || 0),
            description: k.description || '',
            is_used: Boolean(k.is_used),
            isUsed: Boolean(k.is_used),
            used_by: k.used_by,
            usedBy: k.used_by,
            used_at: k.used_at,
            usedAt: k.used_at,
            created_at: k.created_at
          }));
        }
      } catch {}
      if (this.strict) throw new Error('[ServerDatabase] getLicenseKeys failed');
    }

    return [...this.memoryData.licenseKeys];
  }

  public async createLicenseKey(keyData: Partial<ServerLicenseKey>): Promise<ServerLicenseKey> {
    const id = keyData.id || 'key_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex');
    const newKey: ServerLicenseKey = {
      id,
      key: (keyData.key || 'ASTRAX-' + crypto.randomBytes(5).toString('hex').toUpperCase()).trim().toUpperCase(),
      type: keyData.type || 'balance',
      value: Number(keyData.value || 100),
      description: keyData.description || 'รหัสคีย์สิทธิพิเศษ',
      is_used: false,
      isUsed: false,
      created_at: new Date().toISOString()
    };

    this.memoryData.licenseKeys.unshift(newKey);
    this.save();

    if (this.supabase) {
      try {
        this.remote('license key insert', await this.supabase.from('license_keys').insert([{
          id: newKey.id,
          key: newKey.key,
          type: newKey.type,
          value: newKey.value,
          description: newKey.description,
          is_used: false
        }]));
      } catch (err) {
        if (this.strict) throw err;
      }
    }

    return newKey;
  }

  public async deleteLicenseKey(idOrKey: string): Promise<boolean> {
    this.memoryData.licenseKeys = this.memoryData.licenseKeys.filter(k => k.id !== idOrKey && k.key !== idOrKey);
    this.save();

    if (this.supabase) {
      try {
        // Two separate parameterised deletes (never interpolate input into an .or() filter string)
        this.remote('license key delete', await this.supabase.from('license_keys').delete().eq('id', idOrKey));
        this.remote('license key delete', await this.supabase.from('license_keys').delete().eq('key', idOrKey));
      } catch (err) {
        if (this.strict) throw err;
      }
    }
    return true;
  }

  public async bulkDeleteLicenseKeys(ids: string[]): Promise<number> {
    const set = new Set(ids);
    const initialCount = this.memoryData.licenseKeys.length;
    this.memoryData.licenseKeys = this.memoryData.licenseKeys.filter(k => !set.has(k.id) && !set.has(k.key));
    this.save();
    const deletedCount = initialCount - this.memoryData.licenseKeys.length;

    if (this.supabase) {
      try {
        this.remote('license key bulk delete', await this.supabase.from('license_keys').delete().in('id', ids));
      } catch (err) {
        if (this.strict) throw err;
      }
    }
    return deletedCount;
  }

  public async redeemKey(rawKey: string, userId: string): Promise<{ success: boolean; status?: number; error?: string; amount?: number; balance?: number; rank?: string; message?: string }> {
    const cleanKey = rawKey.trim().toUpperCase();

    // 1. Check in local store / memory
    const targetKey = this.memoryData.licenseKeys.find(k => k.key.toUpperCase() === cleanKey);
    if (!targetKey) {
      return { success: false, status: 404, error: 'ไม่พบคีย์นี้ในระบบ หรือคีย์ไม่ถูกต้อง' };
    }
    if (targetKey.is_used || targetKey.isUsed) {
      return { success: false, status: 400, error: 'คีย์นี้ถูกใช้งานไปแล้ว' };
    }

    const profile = await this.getProfile(userId);
    if (!profile) {
      return { success: false, status: 401, error: 'กรุณาเข้าสู่ระบบก่อนเติมคีย์' };
    }

    // Mark key as used
    const now = new Date().toISOString();
    targetKey.is_used = true;
    targetKey.isUsed = true;
    targetKey.used_by = profile.username || userId;
    targetKey.usedBy = profile.username || userId;
    targetKey.used_at = now;
    targetKey.usedAt = now;

    const newBalance = (profile.balance || 0) + targetKey.value;
    const isRankUpgrade = targetKey.type === 'rank_premium';

    await this.updateProfile(userId, {
      balance: newBalance,
      ...(isRankUpgrade ? { rank: 'premium', is_premium: true } : {})
    });

    this.save();

    if (this.supabase) {
      try {
        this.remote('license key redeem', await this.supabase.from('license_keys').update({
          is_used: true,
          used_by: userId,
          used_at: now
        }).eq('id', targetKey.id).eq('is_used', false));
      } catch (err) {
        if (this.strict) throw err;
      }
    }

    return {
      success: true,
      message: `เติมคีย์สำเร็จ! ได้รับ ฿${targetKey.value.toLocaleString()} บาท`,
      amount: targetKey.value,
      balance: newBalance,
      rank: isRankUpgrade ? 'premium' : profile.rank
    };
  }

  // BLOCKED IPS
  public getBlockedIPs(): ServerBlockedIP[] {
    return [...this.memoryData.blockedIPs];
  }

  public addBlockedIP(ip: string, reason: string): ServerBlockedIP {
    const cleanIp = ip.trim();
    const newIp: ServerBlockedIP = {
      id: 'ip_' + Date.now() + '_' + crypto.randomBytes(2).toString('hex'),
      ip: cleanIp,
      reason: reason || 'Blocked by administrator',
      blocked_at: new Date().toISOString(),
      blockedAt: new Date().toISOString()
    };
    this.memoryData.blockedIPs.push(newIp);
    this.save();
    return newIp;
  }

  public deleteBlockedIP(ip: string): boolean {
    const cleanIp = decodeURIComponent(ip).trim();
    this.memoryData.blockedIPs = this.memoryData.blockedIPs.filter(b => b.ip !== cleanIp && b.id !== cleanIp);
    this.save();
    return true;
  }

  // SETTINGS
  public async getSettings(): Promise<ServerSiteSettings> {
    if (this.supabase) {
      try {
        const { data, error } = await this.supabase
          .from('site_settings')
          .select('*')
          .eq('id', 'default')
          .single();
        if (!error && data) {
          return {
            id: data.id,
            site_name: data.site_name || 'Astrax',
            announcement_text: data.announcement_text || '',
            contact_line: data.contact_line || '',
            discord_link: data.discord_link || '',
            facebook_link: data.facebook_link || '',
            contact_email: data.contact_email || 'support@astrax.store',
            promptpay_number: data.promptpay_number || '',
            promptpay_name: data.promptpay_name || '',
            truewallet_phone: data.truewallet_phone || '',
            popup_enabled: data.popup_enabled ?? true,
            popup_img_url: data.popup_img_url || '',
            popup_link: data.popup_link || '',
            instagram_link: data.instagram_link || '',
            stats_users_offset: Number(data.stats_users_offset || 0),
            stats_sales_offset: Number(data.stats_sales_offset || 0),
            spotify_url: data.spotify_url || '',
            spotify_autoplay: Boolean(data.spotify_autoplay),
            banners: Array.isArray(data.banners) ? data.banners : [],
            updated_at: data.updated_at
          };
        }
      } catch {}
    }

    return { ...this.memoryData.settings };
  }

  public async updateSettings(updates: Partial<ServerSiteSettings>): Promise<ServerSiteSettings> {
    const { id: _ignoreId, ...safeUpdates } = updates as any;
    const merged: ServerSiteSettings = {
      ...this.memoryData.settings,
      ...safeUpdates,
      id: 'default',
      updated_at: new Date().toISOString()
    };
    this.memoryData.settings = merged;
    this.save();

    if (this.supabase) {
      try {
        this.remote('settings upsert', await this.supabase.from('site_settings').upsert([{
          id: 'default',
          site_name: merged.site_name,
          announcement_text: merged.announcement_text,
          contact_line: merged.contact_line,
          discord_link: merged.discord_link,
          facebook_link: merged.facebook_link,
          instagram_link: merged.instagram_link,
          contact_email: merged.contact_email,
          promptpay_number: merged.promptpay_number,
          promptpay_name: merged.promptpay_name,
          truewallet_phone: merged.truewallet_phone,
          popup_enabled: merged.popup_enabled,
          popup_img_url: merged.popup_img_url,
          popup_link: merged.popup_link,
          stats_users_offset: merged.stats_users_offset,
          stats_sales_offset: merged.stats_sales_offset,
          spotify_url: merged.spotify_url,
          spotify_autoplay: merged.spotify_autoplay,
          banners: merged.banners,
          updated_at: merged.updated_at
        }]));
      } catch (err) {
        if (this.strict) throw err;
      }
    }

    return merged;
  }

  // PAGES
  public getPages(): ServerPage[] {
    return [...this.memoryData.pages];
  }

  private uniqueSlug(base: string): string {
    let slug = base;
    let n = 2;
    while (this.memoryData.pages.some(p => p.slug === slug)) slug = `${base}-${n++}`;
    return slug;
  }

  public createPage(pageData: Partial<ServerPage>): ServerPage {
    const newPage: ServerPage = {
      id: pageData.id || 'page_' + Date.now() + '_' + crypto.randomBytes(2).toString('hex'),
      slug: this.uniqueSlug(pageData.slug || 'page-' + Date.now()),
      title: pageData.title || 'Untitled Page',
      content: pageData.content || '',
      updatedAt: new Date().toISOString()
    };
    this.memoryData.pages.push(newPage);
    this.save();
    return newPage;
  }

  public updatePage(id: string, updates: Partial<ServerPage>): ServerPage | null {
    const idx = this.memoryData.pages.findIndex(p => p.id === id);
    if (idx === -1) return null;
    const { id: _ignoreId, ...safeUpdates } = updates as any;
    const updated = { ...this.memoryData.pages[idx], ...safeUpdates, id, updatedAt: new Date().toISOString() };
    this.memoryData.pages[idx] = updated;
    this.save();
    return updated;
  }

  public deletePage(id: string): boolean {
    this.memoryData.pages = this.memoryData.pages.filter(p => p.id !== id);
    this.save();
    return true;
  }

  // TOPUPS
  public async getTopups(userId?: string): Promise<ServerTopup[]> {
    if (this.supabase) {
      try {
        let q = this.supabase.from('topups').select('*').order('created_at', { ascending: false });
        if (userId) q = q.eq('user_id', userId);
        const { data, error } = await q;
        if (!error && Array.isArray(data)) {
          return data.map(t => ({
            id: t.id,
            user_id: t.user_id,
            userId: t.user_id,
            uid: t.user_id,
            username: t.username || 'User',
            type: t.type || 'promptpay',
            amount: Number(t.amount || 0),
            money: Number(t.amount || 0),
            reference_no: t.reference_no || t.id,
            referenceNo: t.reference_no || t.id,
            status: t.status || 'approved',
            created_at: t.created_at,
            date: t.created_at
          }));
        }
      } catch {}
      if (this.strict) throw new Error('[ServerDatabase] getTopups failed');
    }

    if (userId) {
      return this.memoryData.topups.filter(t => t.user_id === userId || t.userId === userId || t.uid === userId);
    }
    return [...this.memoryData.topups];
  }

  public async recordTopup(topup: ServerTopup): Promise<ServerTopup> {
    this.memoryData.topups.unshift(topup);
    this.save();

    if (this.supabase) {
      try {
        this.remote('topup insert', await this.supabase.from('topups').insert([{
          id: topup.id,
          user_id: topup.user_id,
          username: topup.username,
          type: topup.type,
          amount: topup.amount,
          reference_no: topup.reference_no,
          status: topup.status,
          created_at: topup.created_at
        }]));
      } catch (err) {
        if (this.strict) throw err;
      }
    }

    return topup;
  }

  // STATS
  public async getStats(): Promise<{ users: number; stock: number; sales: number; topups: number; totalOrders: number }> {
    const products = await this.getProducts();
    const orders = await this.getOrders();
    const topups = await this.getTopups();
    const users = await this.listUsers();

    const totalStock = products.reduce((acc, p) => acc + (p.stock || 0), 0);
    const totalSales = orders.reduce((acc, o) => acc + (o.amount || o.price || 0), 0);
    const totalTopups = topups.reduce((acc, t) => acc + (t.amount || t.money || 0), 0);

    return {
      users: users.length,
      stock: totalStock,
      sales: totalSales,
      topups: totalTopups,
      totalOrders: orders.length
    };
  }

  // LOGS SYSTEM
  public getLogsSystem(): any {
    return this.memoryData.logsSystem;
  }

  public saveLogsSystem(data: any): void {
    this.memoryData.logsSystem = data;
    this.save();
  }
}

export const db = new ServerDatabase();