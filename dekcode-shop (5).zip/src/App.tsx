import {
  BrowserRouter,
  Routes,
  Route,
  useNavigate,
  useLocation,
} from "react-router-dom";
import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
  Suspense,
  lazy,
} from "react";
import { sanitizeCategories } from "./utils";
import {
  Loader,
  Gamepad2,
  ListChecks,
  Play,
  Square,
  Check,
  X,
  Shield,
  Terminal,
  CheckCircle2,
  Home,
  ShoppingCart,
  CreditCard,
  Phone,
  Upload,
  Key,
  Crown,
  LogOut,
  User,
  Gift,
  Lock,
  FileImage,
  Database,
  Globe,
  Mail,
  BarChart3,
  Settings,
  Activity,
  FileText,
  AlertTriangle,
  Download,
  ChevronRight,
  ChevronDown,
  Trash2,
  ShieldAlert,
  Plus,
  Ban,
  History,
  Search,
  Copy,
  Menu,
  Server,
  Package,
  Wallet,
  Coins,
  MessageSquare,
  MessageCircle,
  Bot,
  Image as ImageIcon,
  LogIn,
  UserPlus,
  ArrowUpRight,
  Zap,
  Music,
  ShieldCheck,
  ShoppingBag,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Swal from "sweetalert2";
import axios from "axios";
import { setupApi, apiError } from "./lib/api";
import { supabase as auth } from "./lib/supabase"; // demo/mock auth client (DEV only)
import { onAuthChange, logOut as firebaseLogOut } from "./lib/firebase";
import { SupabaseConfigModal } from "./components/SupabaseConfigModal";

// Attach Firebase ID tokens, retry only idempotent requests, surface IP blocks
setupApi();

// Remove unused jsQR import to save bundle size
type SupabaseUser = any;
import { useToastStore } from "./lib/toastStore";
import { ToastContainer } from "./components/ui/Toast";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { UserPlan, PurchaseResponse } from "./types";
const ReceiptModal = lazy(() => import("./components/modals/ReceiptModal").then(m => ({ default: m.ReceiptModal })));
import { PopupBanner } from "./components/PopupBanner";
import { Product, SiteStats, Category } from "./types";
import { getAvatarUrl } from "./lib/avatar";
import { getUserRank } from "./lib/rank";
import { demoStore } from "./lib/mockApi";

import { DevLogo } from "./components/DevLogo";
import { AppLoader } from "./components/AppLoader";
import { HomeView } from "./components/HomeView";
import { HeaderNavbar } from "./components/HeaderNavbar";
import { MobileDrawer } from "./components/MobileDrawer";
import { Footer as DesignFooter } from "./components/design/Footer";

// Lazy-load secondary views to keep initial bundle size well under 500KB
const ProfileView = lazy(() =>
  import("./components/ProfileView").then((m) => ({ default: m.ProfileView }))
);
const CategoriesView = lazy(() =>
  import("./components/CategoriesView").then((m) => ({ default: m.CategoriesView }))
);
const AuthView = lazy(() =>
  import("./components/AuthView").then((m) => ({ default: m.AuthView }))
);
const ProductDetailView = lazy(() =>
  import("./components/ProductDetailView").then((m) => ({ default: m.ProductDetailView }))
);
const CategoryProductsView = lazy(() =>
  import("./components/CategoryProductsView").then((m) => ({ default: m.CategoryProductsView }))
);
const SearchView = lazy(() =>
  import("./components/SearchView").then((m) => ({ default: m.SearchView }))
);

const AdminDashboard = lazy(() =>
  import("./components/AdminDashboard").then((module) => ({
    default: module.AdminDashboard,
  })),
);
const PageView = lazy(() =>
  import("./components/PageView").then((module) => ({
    default: module.PageView,
  })),
);
const HistoryLogsView = lazy(() =>
  import("./components/HistoryLogsView").then((module) => ({
    default: module.HistoryLogsView,
  })),
);
const WalletView = lazy(() =>
  import("./components/WalletView").then((module) => ({
    default: module.WalletView,
  })),
);
const historyImport = () => import("./components/HistoryView");
const HistoryView = lazy(() =>
  historyImport().then((module) => ({
    default: module.HistoryView,
  })),
);

const ContactView = lazy(() =>
  import("./components/ContactView").then((module) => ({
    default: module.ContactView,
  })),
);
const settingsImport = () => import("./components/SettingsView");
const SettingsView = lazy(() =>
  settingsImport().then((module) => ({
    default: module.SettingsView,
  })),
);
const LogCategoriesView = lazy(() =>
  import("./components/LogCategoriesView").then((module) => ({
    default: module.LogCategoriesView,
  })),
);

enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
  AUTH = "auth",
}

function AppContent() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [userPlan, setUserPlan] = useState<UserPlan | null>(null);
  const [siteSettings, setSiteSettings] = useState(() => {
    const defaultSettings = {
      site_name: "DekCode Shop",
      truewallet_phone: "081-234-5678",
      contact_line: "",
      discord_link: "https://discord.gg/dekcode",
      facebook_link: "",
      instagram_link: "",
      contact_email: "support@dekcode.shop",
      popup_enabled: false,
      popup_img_url: "",
      popup_link: "",
      stats_users_offset: 0,
      stats_sales_offset: 0,
      spotify_url: "",
      spotify_autoplay: false,
      announcement_text: "ยินดีต้อนรับสู่ DekCode Shop ศูนย์รวมซอร์สโค้ด สคริปต์ และบริการดิจิทัลระดับมืออาชีพ จัดส่งอัตโนมัติ 100%",
    };
    try {
      const saved = localStorage.getItem("dekcode_settings_cache") || localStorage.getItem("astrax_settings_cache") || localStorage.getItem("apex_settings_cache");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.site_name || parsed.site_name === "Astrax" || parsed.site_name === "DEV" || parsed.site_name === "Apex Store" || parsed.site_name === "Zenone") {
          parsed.site_name = "DekCode Shop";
        }
        return parsed;
      }
      return defaultSettings;
    } catch {
      return defaultSettings;
    }
  });

  // Removed music state and useEffects

  // Real Products State
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem("dekcode_products_cache") || localStorage.getItem("apex_products_cache");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed.some((p: any) => p.category === "game_accounts")) {
          return parsed;
        }
      }
    } catch (e) {}
    return demoStore.getProducts();
  });

  const [siteStats, setSiteStats] = useState<SiteStats>(() => {
    const defaultStats = {
      users: 1420,
      stock: 180,
      sales: 3260,
      topups: 890,
    };
    try {
      const saved = localStorage.getItem("dekcode_stats_cache") || localStorage.getItem("apex_stats_cache");
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed;
      }
      return defaultStats;
    } catch {
      return defaultStats;
    }
  });

  const [customPages, setCustomPages] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("dekcode_pages_cache") || localStorage.getItem("apex_pages_cache");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [categories, setCategories] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("dekcode_categories_cache") || localStorage.getItem("apex_categories_cache");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed.some((c: any) => c.id === "game_accounts")) return sanitizeCategories(parsed);
      }
    } catch (e) {}
    return demoStore.getCategories();
  });

  const [selectedPage, setSelectedPage] = useState<any>(null);

  const [licenseKeys, setLicenseKeys] = useState<any[]>([]);
  const [usedKeysHistory, setUsedKeysHistory] = useState<any[]>([]);
  const [blockedIPs, setBlockedIPs] = useState<any[]>([]);
  const [adminTab, setAdminTab] = useState<string>("overview");
  const [isIPBlocked, setIsIPBlocked] = useState(false);

  // Navigation State
  type ViewType =
    | "home"
    | "search"
    | "categories"
    | "category_products"
    | "dashboard"
    | "admin"
    | "profile"
    | "logs"
    | "history"
    | "wallet_history"
    | "order_history"
    | "random_history"
    | "settings"
    | "contact"
    | "login"
    | "signup"
    | "wallet"
    | "redeem"
    | "product_detail"
    | "custom_page"
    | "log_categories"
    | "vip_logs"
    | "free_logs";
  const [activeView, setRawActiveView] = useState<ViewType>(() => {
    const hostname = window.location.hostname;
    if (hostname.startsWith("account.")) return "login";
    if (hostname.startsWith("dash.")) return "dashboard";
    return "home";
  });
  const [selectedProductId, setSelectedProductId] = useState<string | null>(
    null,
  );
  const [selectedCategory, setSelectedCategory] = useState<string | null>(
    "all",
  );
  const [usersList, setUsersList] = useState<any[]>([]);

  const setActiveView = useCallback(
    (view: any, metadata?: { productId?: string; categoryId?: string; page?: any }) => {
      let pathSuffix = view === "home" ? "" : view;
      if (view === "product_detail" && metadata?.productId) {
        setSelectedProductId(metadata.productId);
        pathSuffix = `products/${metadata.productId}`;
      } else if (view === "category_products" && metadata?.categoryId) {
        setSelectedCategory(metadata.categoryId);
        pathSuffix = `category/${metadata.categoryId}`;
      } else if (view === "custom_page" && metadata?.page) {
        setSelectedPage(metadata.page);
        pathSuffix = `page/${metadata.page.slug || metadata.page.id}`;
      }

      if (activeView === view && window.location.pathname === "/" + pathSuffix) return;
      window.history.pushState(null, "", "/" + pathSuffix);
      setRawActiveView(view);
    },
    [activeView],
  );

  // Handle URL pathname routing and deep links
  useEffect(() => {
    const handlePopState = () => {
      let path = window.location.pathname.replace(/^\/+/, "");
      if (path === "") {
        const hostname = window.location.hostname;
        if (hostname.startsWith("account.")) path = "login";
        else if (hostname.startsWith("dash.")) path = "dashboard";
        else path = "home";
      }

      // Check deep link patterns: /products/:id or /product/:id
      if (path.startsWith("products/") || path.startsWith("product/")) {
        const pid = path.split("/")[1]?.trim();
        if (pid) {
          setSelectedProductId(pid);
          setRawActiveView("product_detail");
          return;
        }
      }

      // Check deep link patterns: /category/:id
      if (path.startsWith("category/")) {
        const cid = path.split("/")[1]?.trim();
        if (cid) {
          setSelectedCategory(cid);
          setRawActiveView("category_products");
          return;
        }
      }

      // Check deep link patterns: /page/:slug
      if (path.startsWith("page/")) {
        const slug = path.split("/")[1]?.trim();
        if (slug) {
          const matchedPage = customPages.find((p) => p.slug === slug || p.id === slug);
          if (matchedPage) {
            setSelectedPage(matchedPage);
            setRawActiveView("custom_page");
            return;
          }
        }
      }

      // Routing aliases
      if (path === "register") path = "signup";
      if (path === "topup") path = "wallet";
      if (path === "store") path = "categories";
      if (path === "terms") {
        setShowTerms(true);
        return;
      }
      if (path === "privacy") {
        setShowPrivacy(true);
        return;
      }

      const validViews = [
        "landing",
        "home",
        "search",
        "categories",
        "category_products",
        "dashboard",
        "admin",
        "profile",
        "logs",
        "history",
        "wallet_history",
        "order_history",
        "random_history",
        "settings",
        "contact",
        "login",
        "signup",
        "wallet",
        "redeem",
        "product_detail",
        "custom_page",
        "log_categories",
        "vip_logs",
        "free_logs",
      ];

      if (path && validViews.includes(path)) {
        if (path !== activeView) {
          setRawActiveView(path as any);
        }
      } else if (path === "home" && activeView !== "home") {
        setRawActiveView("home");
      }
    };

    // Initial check on mount
    handlePopState();

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, [activeView, customPages]);

  // Support query param ?product=...
  useEffect(() => {
    if (products.length > 0) {
      const params = new URLSearchParams(window.location.search);
      const pid = params.get("product");
      if (pid) {
        const p = products.find((prod) => prod.id === pid);
        if (p && activeView !== "product_detail") {
          setSelectedProductId(pid);
          setRawActiveView("product_detail");
          window.history.replaceState(null, "", "/products/" + pid);
        }
      }
    }
  }, [products, activeView]);

  // Dynamic document.title
  useEffect(() => {
    let title = "DekCode Shop";
    if (activeView === "home") {
      title = "DekCode Shop - ศูนย์รวมซอร์สโค้ดและสคริปต์ดิจิทัล";
    } else if (activeView === "product_detail" && selectedProductId) {
      const p = products.find((prod) => prod.id === selectedProductId);
      title = p ? `${p.name} | DekCode Shop` : "รายละเอียดสินค้า | DekCode Shop";
    } else if (activeView === "categories") {
      title = "หมวดหมู่ซอร์สโค้ดและสคริปต์ | DekCode Shop";
    } else if (activeView === "category_products") {
      const c = categories.find((cat) => cat.id === selectedCategory);
      title = c ? `${c.name || c.title} | DekCode Shop` : "รายการสินค้า | DekCode Shop";
    } else if (activeView === "search") {
      title = "ค้นหาสินค้า | DekCode Shop";
    } else if (activeView === "wallet") {
      title = "เติมเงินและกระเป๋าเงิน | DekCode Shop";
    } else if (activeView === "history" || activeView === "order_history") {
      title = "ประวัติการสั่งซื้อ | DekCode Shop";
    } else if (activeView === "wallet_history") {
      title = "ประวัติการเติมเงิน | DekCode Shop";
    } else if (activeView === "profile") {
      title = "โปรไฟล์ส่วนตัว | DekCode Shop";
    } else if (activeView === "settings") {
      title = "การตั้งค่าบัญชี | DekCode Shop";
    } else if (activeView === "contact") {
      title = "ติดต่อฝ่ายบริการลูกค้า | DekCode Shop";
    } else if (activeView === "login") {
      title = "เข้าสู่ระบบ | DekCode Shop";
    } else if (activeView === "signup") {
      title = "สมัครสมาชิก | DekCode Shop";
    } else if (activeView === "admin") {
      title = "แดชบอร์ดผู้ดูแลระบบ | DekCode Shop";
    } else if (activeView === "custom_page" && selectedPage) {
      title = `${selectedPage.title} | DekCode Shop`;
    }
    document.title = title;
  }, [activeView, selectedProductId, selectedCategory, selectedPage, products, categories]);

  useEffect(() => {
    if (isAdmin) {
      document.body.classList.add("admin-mode");
    } else {
      document.body.classList.remove("admin-mode");
    }
  }, [isAdmin]);

  useEffect(() => {
    const onBlocked = () => setIsIPBlocked(true);
    window.addEventListener("astrax:ip-blocked", onBlocked);
    return () => window.removeEventListener("astrax:ip-blocked", onBlocked);
  }, []);

  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [showContactUs, setShowContactUs] = useState(false);
  const [clientIp, setClientIp] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [forceReveal, setForceReveal] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);

  const [showSupabaseModal, setShowSupabaseModal] = useState(false);
  const [purchasedItemReceipt, setPurchasedItemReceipt] = useState<any>(null);

  // Accessibility: Close topmost modal on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (purchasedItemReceipt) {
          setPurchasedItemReceipt(null);
          return;
        }
        if (showSupabaseModal) {
          setShowSupabaseModal(false);
          return;
        }
        if (showContactUs) {
          setShowContactUs(false);
          return;
        }
        if (showTerms) {
          setShowTerms(false);
          return;
        }
        if (showPrivacy) {
          setShowPrivacy(false);
          return;
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [purchasedItemReceipt, showSupabaseModal, showContactUs, showTerms, showPrivacy]);

  function handleDbError(
    error: unknown,
    operationType: OperationType,
    path: string | null,
  ) {
    const errInfo = {
      error: error instanceof Error ? error.message : String(error),
      authInfo: {
        userId: (window as any)._user?.id,
      },
      operationType,
      path,
    };
    console.error("Database Error: ", JSON.stringify(errInfo));
  }

  const addToast = useToastStore((state) => state.addToast);

  const handleCopy = (text: string, title?: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    addToast({
      type: "success",
      title: title || "สำเร็จ",
      message: "คัดลอกลงในคลิปบอร์ดแล้ว",
      duration: 3000
    });
  };
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(true);
  const [isDesktopUserMenuOpen, setIsDesktopUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDesktopToolsOpen, setIsDesktopToolsOpen] = useState(false);
  const [isMobileToolsOpen, setIsMobileToolsOpen] = useState(false);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isMobileMenuOpen]);

  const [vipTab, setVipTab] = useState<"key">("key");

  const [purchaseHistory, setPurchaseHistory] = useState<any[]>([]);

  const [topupHistory, setTopupHistory] = useState<any[]>([]);

  const [purchasesNextCursor, setPurchasesNextCursor] = useState<string | null>(null);
  const isAdminDataLoadingRef = useRef(false);

  useEffect(() => {
    // Topup history is user-specific, we do not cache it in localStorage.
  }, [topupHistory]);

  const handlePurchase = async (product: Product, quantity: number = 1) => {
    if (product.stock < quantity) {
      Swal.fire({
        icon: "error",
        title: "สินค้าไม่เพียงพอ",
        text: "สินค้าหน้านี้มีสต๊อกไม่พอสำหรับจำนวนที่คุณต้องการ",
        confirmButtonColor: "#dc2626",
      });
      return;
    }

    const totalPrice = product.price * quantity;

    if (!userPlan || (userPlan.balance || 0) < totalPrice) {
      Swal.fire({
        icon: "error",
        title: "ยอดเงินไม่เพียงพอ",
        text: `กรุณาเติมเงินก่อนทำการสั่งซื้อสินค้า (ยอดรวม: ฿${totalPrice.toLocaleString()})`,
        confirmButtonColor: "#dc2626",
      });
      return;
    }

    try {
      const idempotencyKey = `buy_${product.id}_${Date.now()}_${Math.random()}`;
      const res = await axios.post<PurchaseResponse>("/api/buy", {
        productId: product.id,
        quantity,
      }, {
        headers: {
          'Idempotency-Key': idempotencyKey
        }
      });
      const {
        purchase: newHistoryItem,
        updatedUser,
        updatedProduct,
      } = res.data || {};

      // Defensive check: if response is missing critical fields, do NOT replace with undefined!
      if (!newHistoryItem || !updatedProduct || !updatedUser) {
        console.warn("[Purchase] Incomplete purchase payload received from server:", res.data);
        // Safely refetch data without corrupting UI state
        try {
          const [productsRes, userRes] = await Promise.allSettled([
            axios.get("/api/products"),
            axios.get("/api/profile/me")
          ]);
          if (productsRes.status === "fulfilled" && Array.isArray(productsRes.value.data)) {
            setProducts(productsRes.value.data);
          }
          if (userRes.status === "fulfilled" && userRes.value.data?.profile) {
            setUserPlan(userRes.value.data.profile);
          }
        } catch (refetchErr) {
          console.warn("[Purchase] Refetch fallback failed:", refetchErr);
        }

        Swal.fire({
          icon: "warning",
          title: "ยังยืนยันผลการสั่งซื้อไม่ได้",
          text: "ไม่สามารถยืนยันผลการสั่งซื้อได้อย่างสมบูรณ์ กรุณาตรวจยอดเงินคงเหลือและประวัติการสั่งซื้อก่อนทำรายการซ้ำ",
          confirmButtonColor: "#f59e0b",
          confirmButtonText: "ไปที่ประวัติการสั่งซื้อ",
        }).then(() => {
          setActiveView("history");
        });
        return;
      }

      // Update state with result from server
      setProducts((prevProducts) =>
        prevProducts.map((p) => (p.id === product.id ? updatedProduct : p)),
      );
      setUserPlan(updatedUser);
      setPurchaseHistory((prev) => [newHistoryItem, ...prev]);

      // Update site stats for admin
      setSiteStats((prev) => ({
        ...prev,
        sales: prev.sales + totalPrice,
        stock: Math.max(0, prev.stock - quantity),
      }));

      // Create and auto download TXT file of purchased items, if quantity > 1 and secretData exists
      if (quantity > 1 && newHistoryItem.secretData) {
        const blob = new Blob([newHistoryItem.secretData], {
          type: "text/plain;charset=utf-8",
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `dekcode_order_${product.id}_x${quantity}_${new Date().toISOString().slice(0, 10)}.txt`;
        link.click();
        URL.revokeObjectURL(url);
      }

      // Show success and redirect
      Swal.fire({
        icon: "success",
        title: "สั่งซื้อสำเร็จ!",
        text:
          quantity === 1
            ? `คุณได้สั่งซื้อ ${product.name} สำเร็จแล้ว`
            : "ระบบได้ดาวน์โหลดไฟล์คีย์/ข้อมูลสินค้าให้ท่านอัตโนมัติ (และสามารถตรวจสอบย้อนหลังได้ที่ประวัติการสั่งซื้อ)",
        confirmButtonColor: "#16a34a",
        confirmButtonText: "ตกลง",
      }).then(() => {
        setActiveView("history");
        if (quantity === 1) {
          setPurchasedItemReceipt({
            ...newHistoryItem,
            title: "สั่งซื้อสำเร็จ",
            icon: ShoppingCart,
            bg: "bg-blue-600",
            color: "text-white",
          });
        }
      });
    } catch (err: any) {
      console.error("Purchase error:", err);
      const errorMessage = apiError(err, "");
      
      if (err.response?.data?.code === "OUT_OF_STOCK") {
        Swal.fire({
          icon: "error",
          title: "ขออภัย",
          text: "สินค้าชิ้นนี้เพิ่งหมดไป หรือจำนวนในสต๊อกไม่เพียงพอ",
          confirmButtonColor: "#dc2626",
        });
        
        // Refetch to update stock and disable button
        axios.get("/api/products")
          .then((res) => {
             if (res.data && Array.isArray(res.data)) {
                setProducts(res.data);
                // Also update selected product if we are on the detail page
                if (activeView === "product_detail") {
                   const updated = res.data.find((p: any) => p.id === product.id);
                   if (updated && updated.stock === 0) {
                      // Handled by UI automatically via products state propagation
                   }
                }
             }
          }).catch(console.error);
      } else {
        Swal.fire({
          icon: "error",
          title: "เกิดข้อผิดพลาด",
          text:
            errorMessage ||
            "ไม่สามารถทำรายการได้ในขณะนี้ กรุณาลองใหม่",
          confirmButtonColor: "#dc2626",
        });
      }
    }
  };

  const [isDBReady, setIsDBReady] = useState(false);
  const [dbErrorDetail, setDbErrorDetail] = useState<string | null>(null);

  const syncUserPlan = useCallback(
    async (newPlan: UserPlan | null, uid: string) => {
      if (!newPlan || !uid) return;
      try {
        await axios.post(`/api/users/${uid}`, newPlan);
      } catch (err) {
        console.error("Failed to sync user plan:", err);
      }
    },
    [],
  );

  const [authReady, setAuthReady] = useState(false);

  // Pages that require a signed-in user. Redirect guests to the login screen.
  useEffect(() => {
    const protectedViews = ["profile","history","order_history","random_history","wallet_history","wallet","settings","logs","redeem"];
    if (authReady && !user && protectedViews.includes(activeView)) {
      setActiveView("login");
    }
    if (authReady && activeView === "admin" && !isAdmin && !user) {
      setActiveView("login");
    }
  }, [authReady, user, isAdmin, activeView, setActiveView]);

  // Load the signed-in user's profile from the server (the ONLY source of truth for role/balance)
  const loadProfile = useCallback(async (currentUser: any) => {
    try {
      const res = await axios.get("/api/profile/me");
      const profile = res.data?.profile;
      if (profile) {
        setUserPlan(profile);
        setIsAdmin(["admin", "owner"].includes(String(profile.role || "").toLowerCase()));
        try { localStorage.setItem("astrax_userplan_cache", JSON.stringify({ username: profile.username, balance: profile.balance })); } catch {}
      }
    } catch (err: any) {
      if (err.response?.status === 401) {
        setUserPlan(null);
        setIsAdmin(false);
      } else {
        console.error("Profile load error:", err);
      }
    }
  }, []);

  // Firebase is the real identity provider; the Supabase client below is a DEV-only mock.
  useEffect(() => {
    const unsubFb = onAuthChange((fbUser) => {
      setAuthReady(true);
      if (fbUser) {
        const email = (fbUser.email || "").toLowerCase();
        const currentUser: any = {
          id: fbUser.uid,
          uid: fbUser.uid,
          email: fbUser.email,
          displayName: fbUser.displayName,
          user_metadata: {
            username: fbUser.displayName || email.split("@")[0] || "User",
            avatar_url: fbUser.photoURL || undefined,
          },
        };
        setUser(currentUser);
        loadProfile(currentUser);
      } else {
        setUser(null);
        setUserPlan(null);
        setIsAdmin(false);
      }
    });

    // DEV mock sessions (VITE_USE_MOCK_API=true) only
    let mockUnsub: (() => void) | undefined;
    if (import.meta.env.DEV && import.meta.env.VITE_USE_MOCK_API === "true") {
      const { data } = auth.auth.onAuthStateChange(async (_event: any, session: any) => {
        const currentUser: any = session?.user || null;
        if (currentUser) currentUser.uid = currentUser.id;
        setUser(currentUser);
        if (currentUser) loadProfile(currentUser);
      });
      mockUnsub = () => data?.subscription?.unsubscribe();
    }

    return () => {
      unsubFb();
      mockUnsub?.();
    };
  }, [loadProfile]);

  const [logCategories, setLogCategories] = useState<any[]>([]);

  const fetchRequestId = useRef(0);
  const fetchAbortController = useRef<AbortController | null>(null);

  const fetchAllData = useCallback(async () => {
    try {
      if (fetchAbortController.current) {
        fetchAbortController.current.abort();
      }
      const controller = new AbortController();
      fetchAbortController.current = controller;

      fetchRequestId.current += 1;
      const currentRequestId = fetchRequestId.current;

      const fetchApi = async (url: string) => {
        try {
          const res = await axios.get(url, { signal: controller.signal });
          
          if (currentRequestId !== fetchRequestId.current) {
            return { data: null, error: 'stale' };
          }
          
          return { data: res.data, error: null };
        } catch (e: any) {
          if (axios.isCancel(e)) return { data: null, error: 'canceled' };
          if (currentRequestId !== fetchRequestId.current) return { data: null, error: 'stale' };
          const status = e.response?.status;
          const errorMsg = e.response?.data?.error || e.message;
          if (status !== 401 && status !== 403 && status !== 404 && url !== "/api/logs-system") {
             console.error(`Fetch ERROR for ${url}:`, errorMsg);
          } else if (url === "/api/logs-system") {
             return { data: { categories: [], items: [], isVip: false }, error: null };
          }
          return { data: null, error: errorMsg };
        }
      };

      // 1. Critical Landing Page Data - Parallel Fetching with Promise.all
      const publicEndpoints = [
        "/api/settings",
        "/api/products",
        "/api/categories",
        "/api/stats",
        "/api/pages"
      ];

      const mainFetchPromise = Promise.all(
        publicEndpoints.map(url =>
          axios.get(url, { signal: controller.signal })
            .then(res => ({ url, data: res.data, isCanceled: false }))
            .catch(async err => {
              if (axios.isCancel(err)) {
                return { url, data: null, isCanceled: true };
              }

              // Fallback to local cache if network prevented fetch
              let cachedData: any = null;
              try {
                if (url === "/api/settings") cachedData = JSON.parse(localStorage.getItem("apex_settings_cache") || "null");
                else if (url === "/api/products") cachedData = JSON.parse(localStorage.getItem("apex_products_cache") || "null");
                else if (url === "/api/categories") cachedData = JSON.parse(localStorage.getItem("apex_categories_cache") || "null");
                else if (url === "/api/stats") cachedData = JSON.parse(localStorage.getItem("apex_stats_cache") || "null");
                else if (url === "/api/pages") cachedData = JSON.parse(localStorage.getItem("apex_pages_cache") || "null");
              } catch (e) {}

              return { url, data: cachedData, isCanceled: false };
            })
        )
      ).then(async results => {
        if (currentRequestId !== fetchRequestId.current) return;
        
        for (const res of results) {
          if (res.isCanceled) continue;
          
          if (res.url === "/api/settings" && res.data) {
            setSiteSettings(res.data);
            try { localStorage.setItem("apex_settings_cache", JSON.stringify(res.data)); } catch (e) {}
          } else if (res.url === "/api/products" && res.data && Array.isArray(res.data)) {
            setProducts(res.data);
            try { localStorage.setItem("apex_products_cache", JSON.stringify(res.data)); } catch (e) {}
          } else if (res.url === "/api/categories" && res.data && Array.isArray(res.data)) {
            const sanitized = sanitizeCategories(res.data);
            setCategories(sanitized);
            try { localStorage.setItem("apex_categories_cache", JSON.stringify(sanitized)); } catch (e) {}
          } else if (res.url === "/api/stats" && res.data) {
            const statsObj = {
              users: res.data.users ?? 0,
              stock: res.data.stock ?? 0,
              sales: res.data.sales ?? 0,
              topups: res.data.totalTopupsAmount ?? res.data.topups ?? 0,
              totalOrders: res.data.totalOrders ?? 0,
            };
            setSiteStats(statsObj);
            try { localStorage.setItem("apex_stats_cache", JSON.stringify(statsObj)); } catch (e) {}
          } else if (res.url === "/api/pages" && res.data) {
            const d = res.data;
            const pagesToSet = Array.isArray(d) ? d : (d.data && Array.isArray(d.data) ? d.data : []);
            setCustomPages(pagesToSet);
            try { localStorage.setItem("apex_pages_cache", JSON.stringify(pagesToSet)); } catch (e) {}
          }
        }

      });

      // 2. Secondary Data & User Data
      const logsPromise = fetchApi("/api/logs-system").then(res => {
        if (res.data && Array.isArray(res.data.categories)) {
          setLogCategories(res.data.categories.filter((c: any) => c.isVisible));
        }
      });

      // Health check for DB readiness
      const healthPromise = axios
        .get("/api/health")
        .then(() => {
          setIsDBReady(true);
          setDbErrorDetail(null);
        })
        .catch((e) => {
          setIsDBReady(false);
          let errorMsg =
            e.response?.data?.error || e.message || "Unknown Error";
          setDbErrorDetail(`Backend API ไม่ตอบสนอง (Offline): ${errorMsg}`);
        });

      // Await only the critical home view endpoints + backend health check to reveal the home UI instantly
      await Promise.all([mainFetchPromise, healthPromise]);
    } catch (err: any) {
      // Catch silently
    }
  }, []);

  // Dedicated user-session data retriever (decoupled from the landing page loop)
  const fetchUserData = useCallback(async () => {
    if (!user) return;
    try {
      const [usedKeysRes, purchasesRes, topupsRes] = await Promise.all([
        axios.get("/api/used_keys").catch(() => null),
        axios.get("/api/purchases?limit=20").catch(() => null),
        axios.get("/api/topups").catch(() => null)
      ]);
      if (usedKeysRes?.data) setUsedKeysHistory(usedKeysRes.data);
      if (purchasesRes?.data) {
        const purchaseData = Array.isArray(purchasesRes.data) 
          ? purchasesRes.data 
          : purchasesRes.data.data;
        if (Array.isArray(purchaseData)) {
          setPurchaseHistory(purchaseData);
          if (purchasesRes.data.nextCursor) {
            setPurchasesNextCursor(purchasesRes.data.nextCursor);
          }
        }
      }
      if (topupsRes?.data && Array.isArray(topupsRes.data)) setTopupHistory(topupsRes.data);
    } catch (err) {
      // Handled silently
    }
  }, [user]);

  // Dedicated admin logs/entities data retriever (decoupled from the landing page loop)
  const fetchAdminData = useCallback(async () => {
    if (!isAdmin || isAdminDataLoadingRef.current) return;
    isAdminDataLoadingRef.current = true;
    try {
      const [licensesRes, blockedIpsRes, usersRes] = await Promise.all([
        axios.get("/api/license_keys").catch(() => null),
        axios.get("/api/blocked_ips").catch(() => null),
        axios.get("/api/users").catch(() => null)
      ]);
      if (licensesRes?.data) {
        setLicenseKeys(Array.isArray(licensesRes.data) ? licensesRes.data : Array.isArray(licensesRes.data.data) ? licensesRes.data.data : []);
      }
      if (blockedIpsRes?.data) {
        setBlockedIPs(Array.isArray(blockedIpsRes.data) ? blockedIpsRes.data : Array.isArray(blockedIpsRes.data.data) ? blockedIpsRes.data.data : []);
      }
      if (usersRes?.data) {
        setUsersList(Array.isArray(usersRes.data) ? usersRes.data : Array.isArray(usersRes.data.data) ? usersRes.data.data : []);
      }
    } catch (err) {
      // Handled silently
    } finally {
      isAdminDataLoadingRef.current = false;
    }
  }, [isAdmin]);

  // Combined system-wide data refresh function for user/admin actions
  const refreshAllSystemData = useCallback(async () => {
    await Promise.all([
      fetchAllData(),
      user ? fetchUserData() : Promise.resolve(),
      isAdmin ? fetchAdminData() : Promise.resolve()
    ]);
  }, [fetchAllData, fetchUserData, fetchAdminData, user, isAdmin]);

  // Backend API Listeners - Public static endpoints refreshed every 60 seconds
  useEffect(() => {
    fetchAllData();
    const timer = setInterval(fetchAllData, 60000);
    return () => {
      clearInterval(timer);
      if (fetchAbortController.current) {
        fetchAbortController.current.abort();
      }
    };
  }, [fetchAllData]);

  // Trigger user private data load on session changes
  useEffect(() => {
    if (user) {
      fetchUserData();
    } else {
      setUsedKeysHistory([]);
      setPurchaseHistory([]);
      setTopupHistory([]);
    }
  }, [user, fetchUserData]);

  // Trigger admin private data load on status changes
  useEffect(() => {
    if (isAdmin) {
      fetchAdminData();
    } else {
      setLicenseKeys([]);
      setBlockedIPs([]);
      setUsersList([]);
    }
  }, [isAdmin, fetchAdminData]);

  // App Init & check IP
  useEffect(() => {
    const initApp = async () => {
      const savedUserPlan = localStorage.getItem("astrax_userplan_cache");
      if (savedUserPlan) {
        try {
          const cached = JSON.parse(savedUserPlan);
          // Cache is for instant paint only — never restore privileges from localStorage
          setUserPlan({ username: cached.username, balance: Number(cached.balance) || 0 } as any);
        } catch {}
      }

      setIsLoaded(true);

      const timeoutId = setTimeout(() => {
        setForceReveal(true);
        setIsLoaded(true);
      }, 1200);

      // Concurrent parallel boot loading of metadata, pages, settings, stats, and client configuration
      try {
        await Promise.all([
          axios.get("/api/health")
            .then(res => {
              const ip = res.data?.clientIp || "Unknown";
              setClientIp(ip);
            })
            .catch(() => {
              setClientIp("offline_local");
            }),
          fetchAllData()
        ]);
      } catch (err) {
        console.error("Initial system parallel data fetch failed:", err);
      } finally {
        clearTimeout(timeoutId);
        setIsLoaded(true);
      }
    };
    initApp();
  }, [fetchAllData]);

  const redeemKey = async (
    keyInput: string,
    usernameInput: string = "ผู้ใช้งานทั่วไป",
  ) => {
    if (!keyInput) return;
    try {
      Swal.fire({
        title: "กำลังตรวจสอบ...",
        allowOutsideClick: false,
        didOpen: () => {
          Swal.showLoading();
        },
        background: "#09090b",
        color: "#fff",
      });

      const res = await axios.post("/api/redeem", { key: keyInput.trim() });
      const { rank, balance, amount } = res.data || {};

      setUserPlan((prev: any) => ({
        ...(prev || {}),
        ...(typeof balance === "number" ? { balance } : {}),
        ...(rank ? { rank, isPremium: rank === "premium" || prev?.isPremium } : {}),
      }));

      Swal.fire({
        icon: "success",
        title: "ใช้คีย์สำเร็จ",
        text: amount ? `ได้รับ ฿${Number(amount).toLocaleString()} เข้ากระเป๋าเงินแล้ว` : "เปิดใช้งานสิทธิ์เรียบร้อยแล้ว",
        background: "#09090b",
        color: "#fff",
      });
    } catch (err: any) {
      const status = err.response?.status;
      if (status === 400 || status === 404) {
        Swal.fire({
          icon: "error",
          title: "ใช้คีย์ไม่ได้",
          text: "รหัสอาจพิมพ์ผิด หรือถูกใช้งานไปแล้ว",
          background: "#09090b",
          color: "#fff",
        });
      } else {
        handleDbError(err, OperationType.WRITE, "license_keys");
        Swal.fire({ icon: "error", title: "เกิดข้อผิดพลาด", text: apiError(err), background: "#09090b", color: "#fff" });
      }
    }
  };
  const handleLogoClick = () => {
    setActiveView("login");
  };

  const handleLogout = async () => {
    try {
      await firebaseLogOut();
    } catch (err) {
      console.error("Firebase logout error:", err);
    }
    try {
      await auth.auth.signOut();
    } catch (err) {
      console.error("Logout error:", err);
    }
    try {
      localStorage.removeItem("astrax_userplan_cache");
    } catch {}
    localStorage.removeItem("apex_admin");
    delete axios.defaults.headers.common["Authorization"];
    setIsAdmin(false);
    setUserPlan(null);
    setUser(null);
    setPurchaseHistory([]);
    setTopupHistory([]);
    setUsedKeysHistory([]);
    setActiveView("home");
    Swal.fire({
      icon: "info",
      title: "ออกจากระบบแล้ว",
      timer: 1500,
      showConfirmButton: false,
      background: "#09090b",
      color: "#fff",
    });
  };

  const resendVerification = async () => {
    // Disabled as requested
  };

  const addLicenseKey = async () => {
    const { value: formValues } = await Swal.fire({
      title: "สร้างคีย์ใหม่",
      html:
        '<select id="swal-input1" class="swal2-select bg-[#2c2c2e] border-white/10 text-white w-full rounded-xl">' +
        '<option value="balance">คีย์เติมเงิน (Balance)</option>' +
        '<option value="rank_premium">อัปเกรดเป็น Premium</option>' +
        "</select>" +
        '<input id="swal-input3" class="swal2-input bg-[#2c2c2e] border-white/10 text-white w-full rounded-xl" placeholder="มูลค่า (บาท)" type="number" min="0" value="100">' +
        '<input id="swal-input2" class="swal2-input bg-[#2c2c2e] border-white/10 text-white w-full rounded-xl" placeholder="จำนวนคีย์ (1-50)" type="number" min="1" max="50" value="1">',
      focusConfirm: false,
      showCancelButton: true,
      confirmButtonText: "สร้างคีย์",
      cancelButtonText: "ยกเลิก",
      background: "#1c1c1e",
      color: "#f5f5f7",
      confirmButtonColor: "#0071e3",
      preConfirm: () => [
        (document.getElementById("swal-input1") as HTMLSelectElement).value,
        (document.getElementById("swal-input2") as HTMLInputElement).value,
        (document.getElementById("swal-input3") as HTMLInputElement).value,
      ],
    });

    if (formValues) {
      const [type, countStr, valueStr] = formValues;
      const count = Math.min(50, Math.max(1, parseInt(countStr) || 1));
      const value = Math.max(0, Number(valueStr) || 0);

      try {
        // Keys are generated server-side with a cryptographically secure RNG
        const keys = Array.from({ length: count }, () => ({ type, value }));
        await axios.post(`/api/license_keys/bulk`, { keys });
        Swal.fire("สำเร็จ", `สร้างคีย์ ${count} รายการ สำเร็จ`, "success");
        refreshAllSystemData();
      } catch (err) {
        handleDbError(err, OperationType.WRITE, "license_keys");
        Swal.fire("ผิดพลาด", "ไม่สามารถสร้างคีย์ได้: " + apiError(err), "error");
      }
    }
  };

  const blockIP = async () => {
    const { value: ipData } = await Swal.fire({
      title: "บล็อค IP ผู้ใช้",
      html:
        '<input id="swal-ip" class="swal2-input bg-[#2c2c2e] border-white/10 text-white w-full rounded-xl" placeholder="IP Address เช่น 1.1.1.1">' +
        '<input id="swal-reason" class="swal2-input bg-[#2c2c2e] border-white/10 text-white w-full rounded-xl" placeholder="เหตุผลการบล็อค">',
      focusConfirm: false,
      background: "#1c1c1e",
      color: "#f5f5f7",
      confirmButtonColor: "#0071e3",
      preConfirm: () => {
        return [
          (document.getElementById("swal-ip") as HTMLInputElement).value,
          (document.getElementById("swal-reason") as HTMLInputElement).value,
        ];
      },
    });

    if (ipData) {
      const [ip, reason] = ipData;
      if (!ip) return;
      try {
        await axios.post(`/api/blocked_ips`, {
          ip,
          reason: reason || "Violation of terms",
        });
        Swal.fire({
          title: "สำเร็จ",
          text: `บล็อค IP ${ip} สำเร็จ`,
          icon: "success",
          background: "#1c1c1e",
          color: "#f5f5f7",
          confirmButtonColor: "#0071e3",
        });
      } catch (err) {
        handleDbError(err, OperationType.WRITE, "blocked_ips");
        Swal.fire({
          title: "ข้อผิดพลาด",
          text: "ไม่สามารถบล็อคได้: " + (err as Error).message,
          icon: "error",
          background: "#1c1c1e",
          color: "#f5f5f7",
          confirmButtonColor: "#0071e3",
        });
      }
    }
  };

  const deleteKey = async (keyId: string) => {
    const result = await Swal.fire({
      title: "ยืนยันการลบ?",
      text: "คุณกำลังลบคีย์ " + keyId,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#ef4444",
      cancelButtonColor: "#2c2c2e",
      confirmButtonText: "ลบออก",
      background: "#1c1c1e",
      color: "#f5f5f7",
    });

    if (result.isConfirmed) {
      try {
        await axios.delete(`/api/license_keys/${keyId}`);
        Swal.fire("ลบแล้ว", "คีย์ถูกลบออกจากระบบแล้ว", "success");
        setLicenseKeys((prev) => prev.filter((k) => k.id !== keyId));
      } catch (err) {
        handleDbError(err, OperationType.DELETE, "license_keys/" + keyId);
        Swal.fire(
          "ข้อผิดพลาด",
          "ลบไม่สำเร็จ: " + (err as Error).message,
          "error",
        );
      }
    }
  };

  const bulkDeleteKeys = async () => {
    const totalActive = licenseKeys.filter((k) => !(k.is_used || k.isUsed)).length;
    const totalUsed = licenseKeys.filter((k) => k.is_used || k.isUsed).length;
    const totalAll = licenseKeys.length;

    const result = await Swal.fire({
      title: "ลบคีย์หลายรายการ",
      html: `
        <div class="text-left text-xs space-y-2 mb-4 text-label-2">
          <div><span>คีย์ทั้งหมด:</span> <span class="font-semibold text-accent">${totalAll}</span> รายการ</div>
          <div><span>ยังไม่ได้ใช้:</span> <span class="font-semibold text-accent">${totalActive}</span> รายการ</div>
          <div><span>ใช้แล้ว:</span> <span class="font-semibold text-warning">${totalUsed}</span> รายการ</div>
        </div>
        <select id="bulk-delete-type" class="swal2-select bg-[#2c2c2e] border-white/10 text-white w-full rounded-xl text-xs" style="width: 100%; margin-bottom: 10px;">
          <option value="used">ลบเฉพาะคีย์ที่ใช้แล้ว (Used)</option>
          <option value="active">ลบเฉพาะคีย์ที่ยังไม่ได้ใช้ (Active)</option>
          <option value="all">ลบคีย์ทั้งหมด (All)</option>
        </select>
        <input id="bulk-delete-count" type="number" min="1" class="swal2-input bg-[#2c2c2e] border-white/10 text-white w-full rounded-xl text-xs" placeholder="จำนวนที่ต้องการลบ (เว้นว่างเพื่อลบทั้งหมดตามประเภท)" style="width: 100%; margin: 0; box-sizing: border-box;">
      `,
      showCancelButton: true,
      confirmButtonText: "ถัดไป",
      cancelButtonText: "ยกเลิก",
      background: "#1c1c1e",
      color: "#f5f5f7",
      confirmButtonColor: "#0071e3",
      cancelButtonColor: "#2c2c2e",
      preConfirm: () => {
        const type = (
          document.getElementById("bulk-delete-type") as HTMLSelectElement
        ).value;
        const countStr = (
          document.getElementById("bulk-delete-count") as HTMLInputElement
        ).value;
        const count = countStr ? parseInt(countStr) : null;
        return { type, count };
      },
    });

    if (result.isConfirmed) {
      const { type, count } = result.value;
      let keysToDelete = licenseKeys;
      if (type === "active")
        keysToDelete = keysToDelete.filter((k) => !(k.is_used || k.isUsed));
      if (type === "used")
        keysToDelete = keysToDelete.filter((k) => k.is_used || k.isUsed);

      if (keysToDelete.length === 0) {
        return Swal.fire({
          title: "ข้อมูล",
          text: "ไม่มีคีย์ในระบบที่ตรงกับเงื่อนไข",
          icon: "info",
          background: "#1c1c1e",
          color: "#f5f5f7",
          confirmButtonColor: "#0071e3",
        });
      }

      if (count && count > 0 && count < keysToDelete.length) {
        keysToDelete = keysToDelete.slice(0, count);
      }

      const confirm2 = await Swal.fire({
        title: "ยืนยันขั้นสุดท้าย",
        text: `คุณต้องการลบคีย์จำนวน ${keysToDelete.length} รายการใช่หรือไม่?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#ef4444",
        cancelButtonColor: "#2c2c2e",
        confirmButtonText: "ยืนยันการลบ",
        cancelButtonText: "ยกเลิก",
        background: "#1c1c1e",
        color: "#f5f5f7",
      });

      if (confirm2.isConfirmed) {
        Swal.fire({
          title: "กำลังลบ...",
          allowOutsideClick: false,
          didOpen: () => {
            Swal.showLoading();
          },
        });
        try {
          const ids = keysToDelete.map((k) => k.id);
          const res = await axios.post("/api/license_keys/bulk_delete", {
            ids,
          });
          const deletedCount = res.data.deletedCount;
          setLicenseKeys((prev) => prev.filter((k) => !ids.includes(k.id)));
          Swal.fire(
            "ลบแล้ว",
            `ลบคีย์สำเร็จจำนวน ${deletedCount} รายการ`,
            "success",
          );
        } catch (err: any) {
          Swal.fire("ข้อผิดพลาด", "ลบไม่สำเร็จ: " + err.message, "error");
        }
      }
    }
  };

  const unblockIP = async (ip: string) => {
    try {
      await axios.delete(`/api/blocked_ips/${encodeURIComponent(ip)}`);
      Swal.fire("สำเร็จ", "ปลดบล็อค IP เรียบร้อย", "success");
      setBlockedIPs((prev) => prev.filter((i) => i.ip !== ip));
    } catch (err) {
      handleDbError(err, OperationType.DELETE, "blocked_ips/" + ip);
      Swal.fire("ข้อผิดพลาด", "ไม่สำเร็จ: " + (err as Error).message, "error");
    }
  };

  if (isIPBlocked)
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center p-4">
        <div className="w-full max-w-lg bg-surface text-label border border-accent/20 p-8 sm:p-12 text-center relative overflow-hidden rounded-3xl shadow-2xl">
          <ShieldAlert className="w-16 h-16 text-accent mx-auto mb-6 animate-pulse" />
          <h1 className="text-2xl sm:text-3xl font-bold text-accent mb-4 uppercase tracking-tighter">
            Access Revoked
          </h1>
          <p className="text-label-2 text-sm leading-relaxed mb-8">
            ที่อยู่ IP ของคุณ ({clientIp})
            ถูกระงับการเข้าถึงระบบเนื่องจากละเมิดข้อตกลงการใช้งานหรือพบพฤติกรรมที่น่าสงสัย
            หากคุณคิดว่าเป็นความผิดพลาด กรุณาติดต่อผู้ดูแลระบบ DekCode Shop
          </p>
          <div className="bg-surface-2 p-4 text-13 text-label-2 font-mono mb-8 border border-separator rounded-2xl">
            Error Code: DEKCODE_SECURITY_BLOCK_L4
          </div>
          <button
            onClick={() => window.location.reload()}
            className="bg-accent hover:bg-accent-hover text-white px-8 py-3 text-14 font-bold transition-all rounded-full cursor-pointer shadow-lg shadow-accent/20 active:scale-95"
          >
            TRY RECONNECTING
          </button>
        </div>
      </div>
    );

  const isHomeViewReady = isLoaded || forceReveal;
  if (!isLoaded && !forceReveal && !dbErrorDetail)
    return <AppLoader progress={loadingProgress > 0 ? loadingProgress : undefined} />;

  return (
    <div id="app-root" className="min-h-screen w-full bg-bg text-label font-sans selection:bg-accent/30 selection:text-white flex flex-col relative transition-colors">
      {activeView === "login" || activeView === "signup" ? (
        <Suspense
          fallback={
            <div className="min-h-screen w-full flex items-center justify-center bg-bg">
              <div className="w-8 h-8 border-2 border-white/20 border-t-accent rounded-full animate-spin" />
            </div>
          }
        >
          <AuthView
            initialMode={activeView === "signup" ? "signup" : "login"}
            setActiveView={setActiveView}
            siteSettings={siteSettings}
            onOpenTerms={() => setShowTerms(true)}
            onOpenPrivacy={() => setShowPrivacy(true)}
            onOpenContact={() => setShowContactUs(true)}
          />
        </Suspense>
      ) : (
        <>
          <Suspense fallback={null}>
            <PopupBanner
              enabled={siteSettings?.popup_enabled ?? true}
              imgUrl={siteSettings?.popup_img_url ?? ""}
              linkUrl={siteSettings?.popup_link ?? ""}
              siteName={siteSettings?.site_name || "DekCode Shop"}
              onNavigate={(view) => {
                setActiveView(view);
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
            />
          </Suspense>

          {/* Top Bar with Smooth Shrinking Animation on Scroll */}
          <HeaderNavbar
            activeView={activeView}
            setActiveView={setActiveView}
            user={user}
            userPlan={userPlan}
            isAdmin={isAdmin}
            onLogout={handleLogout}
            onOpenSearch={() => setActiveView("search")}
            onOpenContact={() => setShowContactUs(true)}
            onOpenSupabaseConfig={() => setShowSupabaseModal(true)}
            isMobileMenuOpen={isMobileMenuOpen}
            setIsMobileMenuOpen={setIsMobileMenuOpen}
            isDesktopUserMenuOpen={isDesktopUserMenuOpen}
            setIsDesktopUserMenuOpen={setIsDesktopUserMenuOpen}
            isUserMenuOpen={isUserMenuOpen}
            setIsUserMenuOpen={setIsUserMenuOpen}
            settingsImport={settingsImport}
            historyImport={historyImport}
          />

          {/* Mobile Drawer */}
          <MobileDrawer
            isOpen={isMobileMenuOpen}
            onClose={() => setIsMobileMenuOpen(false)}
            activeView={activeView}
            setActiveView={(view) => {
              setActiveView(view);
              setIsMobileMenuOpen(false);
            }}
            user={user}
            userPlan={userPlan}
            isAdmin={isAdmin}
            onLogout={handleLogout}
            onOpenContact={() => {
              setShowContactUs(true);
              setIsMobileMenuOpen(false);
            }}
            isUserMenuOpen={isUserMenuOpen}
            setIsUserMenuOpen={setIsUserMenuOpen}
            settingsImport={settingsImport}
            historyImport={historyImport}
            onOpenSearch={() => {
              setActiveView("search");
              setIsMobileMenuOpen(false);
            }}
          />

          {/* Main Content Area */}
          <main id="main-content" tabIndex={-1} className="flex-1 flex flex-col min-h-screen min-w-0 relative overflow-x-hidden focus:outline-none">
            <div className="w-full flex-1 flex flex-col pt-2 sm:pt-4 pb-8">
              <Suspense
                fallback={
                  <div className="flex-1 w-full flex items-center justify-center min-h-[50vh]">
                    <div className="w-7 h-7 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  </div>
                }
              >
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeView}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
                  className="flex-1 w-full flex flex-col min-h-0"
                >
            {activeView === "categories" && (
              <CategoriesView
                categories={categories}
                products={products}
                siteSettings={siteSettings}
                onBack={() => setActiveView("home")}
                onSelectCategory={(cat) => {
                  setSelectedCategory(cat);
                }}
                onProductClick={(id) => {
                  setSelectedProductId(id);
                  setActiveView("product_detail");
                }}
              />
            )}
            {activeView === "category_products" && selectedCategory && (
              <CategoryProductsView
                category={selectedCategory}
                categories={categories}
                products={products}
                onBack={() => setActiveView("categories")}
                onProductClick={(id) => {
                  setSelectedProductId(id);
                  setActiveView("product_detail");
                }}
              />
            )}
            {activeView === "search" && (
              <SearchView
                products={products}
                onBack={() =>
                  window.history.length > 1
                    ? window.history.back()
                    : setActiveView("home")
                }
                onProductClick={(id) => {
                  setSelectedProductId(id);
                  setActiveView("product_detail");
                }}
              />
            )}
            {activeView === "home" && (
              <HomeView
                products={products}
                categories={categories}
                stats={siteStats}
                user={userPlan || user}
                siteSettings={siteSettings}
                purchaseHistory={purchaseHistory}
                setActiveView={setActiveView}
                onProductClick={(id) => {
                  setSelectedProductId(id);
                  setActiveView("product_detail");
                }}
                onSelectCategory={(cat) => {
                  setSelectedCategory(cat);
                  setActiveView("category_products");
                }}
              />
            )}
            {activeView === "product_detail" && selectedProductId && (
              <ProductDetailView
                product={products.find((p) => p.id === selectedProductId) as any}
                user={user}
                balance={userPlan?.balance}
                onBack={() => setActiveView("home")}
                handlePurchase={async (p, q) => {
                  await handlePurchase(p, q);
                }}
                setActiveView={setActiveView}
              />
            )}
            {activeView === "contact" && (
              <ContactView
                onBack={() => setActiveView("home")}
                facebookLink={
                  siteSettings?.facebook_link || siteSettings?.contact_line
                }
                discordLink={siteSettings?.discord_link}
                instagramLink={siteSettings?.instagram_link}
                contactEmail={siteSettings?.contact_email}
              />
            )}
            {activeView === "custom_page" && selectedPage && (
              <PageView
                page={selectedPage}
                onBack={() => setActiveView("home")}
              />
            )}
            {activeView === "profile" && (
              <ProfileView
                user={user}
                userPlan={userPlan}
                setUserPlan={setUserPlan}
                clientIp={clientIp}
                setActiveView={setActiveView}
                handleLogout={handleLogout}
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
              />
            )}
            {activeView === "logs" && (
              <HistoryLogsView
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
              />
            )}
            {activeView === "log_categories" && (
              <LogCategoriesView
                userPlan={userPlan}
                isAdmin={isAdmin}
                onNavigateAction={(action) =>
                  setActiveView(action as void | any)
                }
                filterType="all"
              />
            )}
            {activeView === "vip_logs" && (
              <LogCategoriesView
                userPlan={userPlan}
                isAdmin={isAdmin}
                onNavigateAction={(action) =>
                  setActiveView(action as void | any)
                }
                filterType="vip"
              />
            )}
            {activeView === "free_logs" && (
              <LogCategoriesView
                userPlan={userPlan}
                isAdmin={isAdmin}
                onNavigateAction={(action) =>
                  setActiveView(action as void | any)
                }
                filterType="free"
              />
            )}
            {activeView === "history" && (
              <HistoryView
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
              />
            )}
            {activeView === "order_history" && (
              <HistoryView
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
                defaultTab="normal_product"
              />
            )}
            {activeView === "random_history" && (
              <HistoryView
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
                defaultTab="special_product"
              />
            )}
            {activeView === "wallet_history" && (
              <HistoryView
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
                defaultTab="topup_gift"
              />
            )}
            {activeView === "settings" && (
              <SettingsView setActiveView={setActiveView} user={user} />
            )}
            {activeView === "wallet" && (
              <WalletView
                userPlan={userPlan}
                setUserPlan={setUserPlan}
                userId={user?.uid}
                siteSettings={siteSettings}
                topupHistory={topupHistory}
                setActiveView={setActiveView}
                onTopupSuccess={(entry) => {
                  setTopupHistory((prev) => [entry, ...prev]);
                  setSiteStats((prev) => ({
                    ...prev,
                    topups:
                      (prev.topups || 0) + (entry.amount || entry.money || 0),
                  }));
                }}
              />
            )}
            {activeView === "admin" && isAdmin && (
              <AdminDashboard
                licenseKeys={licenseKeys}
                usedKeysHistory={usedKeysHistory}
                blockedIPs={blockedIPs}
                adminTab={adminTab}
                setAdminTab={setAdminTab}
                isDBReady={isDBReady}
                dbErrorDetail={dbErrorDetail}
                adminUsername="Admin"
                setIsAdmin={setIsAdmin}
                addLicenseKey={addLicenseKey}
                blockIP={blockIP}
                deleteKey={deleteKey}
                bulkDeleteKeys={bulkDeleteKeys}
                unblockIP={unblockIP}
                products={products}
                setProducts={setProducts}
                siteStats={siteStats}
                setSiteStats={setSiteStats}
                customPages={customPages}
                setCustomPages={setCustomPages}
                categories={categories}
                setCategories={setCategories}
                usersList={usersList}
                purchaseHistory={purchaseHistory}
                topupHistory={topupHistory}
                onBackToStore={() => setActiveView("home")}
                onRefreshData={refreshAllSystemData}
                onOpenSupabaseConfig={() => setShowSupabaseModal(true)}
              />
            )}
            </motion.div>
          </AnimatePresence>
          </Suspense>
        </div>

        {/* Sleek Minimal Footer */}
        <DesignFooter
          setActiveView={setActiveView}
          siteSettings={siteSettings}
          onOpenTerms={() => setShowTerms(true)}
          onOpenPrivacy={() => setShowPrivacy(true)}
          onOpenContact={() => setShowContactUs(true)}
        />

        {/* Floating Support Button from exact-copy */}
        <button
          type="button"
          className="support-button cursor-pointer"
          onClick={() => setShowContactUs(true)}
          aria-label="ติดต่อสอบถาม แจ้งปัญหา"
        >
          <span>ติดต่อสอบถาม แจ้งปัญหา</span>
          <MessageCircle size={26} />
        </button>
      </main>
      </>
    )}

        {/* Modals */}
        <AnimatePresence>
          {showPrivacy && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-[100] font-sans"
              onClick={() => setShowPrivacy(false)}
            >
              <motion.div
                role="dialog"
                aria-modal="true"
                aria-labelledby="privacy-modal-title"
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-surface border border-separator p-6 sm:p-8 max-w-3xl w-full max-h-[90vh] flex flex-col relative rounded-3xl shadow-2xl backdrop-blur-xl text-label"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 id="privacy-modal-title" className="text-xl sm:text-2xl font-semibold text-label flex items-center gap-2">
                    <Shield className="w-6 h-6 shrink-0 text-accent" />{" "}
                    นโยบายความเป็นส่วนตัว (Privacy Policy)
                  </h2>
                  <button
                    type="button"
                    onClick={() => setShowPrivacy(false)}
                    aria-label="ปิดหน้าต่างนโยบายความเป็นส่วนตัว"
                    className="p-2 hover:bg-surface-2 transition-colors rounded-full text-label-3 hover:text-label cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="overflow-y-auto pr-2 sm:pr-4 space-y-6 text-xs sm:text-sm leading-relaxed text-label-2 scrollbar-thin scrollbar-thumb-surface-2 flex-1">
                  <p>
                    <strong>อัปเดตล่าสุด:</strong>{" "}
                    {new Date("2026-01-01").toLocaleDateString("th-TH", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </p>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      1. ข้อมูลที่เราเก็บรวบรวม
                    </h3>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>
                        <strong>ข้อมูลระบุตัวตนและบัญชี:</strong>{" "}
                        เมื่อคุณสมัครสมาชิก เราอาจจัดเก็บข้อมูลเช่น อีเมล
                        ชื่อผู้ใช้ รหัสผ่าน (ที่ถูกเข้ารหัสและทำแฮชอย่างแน่นหนา)
                        ข้อมูลสิทธิ์การใช้งาน (Role/VIP) และเครดิตคงเหลือของคุณ
                      </li>
                      <li>
                        <strong>ข้อมูลการทำธุรกรรม (Transaction Data):</strong>{" "}
                        หากมีการทำธุรกรรมเติมเงินซื้อสินค้า
                        เราจะเก็บข้อมูลบันทึกการทำธุรกรรม เช่น เวลา จำนวนเงิน
                        หมายเลขอ้างอิง เพื่อประเมิน วิเคราะห์
                        และป้องกันการหลอกลวง
                      </li>
                      <li>
                        <strong>ข้อมูล IP Address และ Log Files:</strong>{" "}
                        ตามข้อบังคับและเพื่อความปลอดภัย เรามีการเก็บบันทึก IP
                        Address, Browser Agent, เวลาเข้าระบบ
                        และพฤติกรรมการใช้งาน
                        เพื่อใช้เป็นหลักฐานและป้องกันเหตุโจมตีระบบ (DDoS/BotNet)
                      </li>
                      <li>
                        <strong>
                          ข้อมูลการเชื่อมต่อคู่ค้า (External API):
                        </strong>{" "}
                        หากคุณผูกบัญชีบริการภายนอก เช่น Discord หรือ Telegram
                        เรามีความจำเป็นต้องดึงข้อมูลสาธารณะหรือ Token
                        ที่คุณอนุญาตเพื่อใช้ทำงานบนแพลตฟอร์มของเรา
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      2. การปกป้องข้อมูลและความปลอดภัยของบัญชี
                    </h3>
                    <p className="mb-2">
                      ทางแพลตฟอร์มมุ่งเน้นการรักษาความมั่นคงปลอดภัยของข้อมูลบัญชีผู้ใช้งาน
                      และการทำธุรกรรมทางการเงินอย่างเข้มงวด
                    </p>
                    <p>
                      รหัสผ่านและคีย์สินค้าจะได้รับการเข้ารหัสและคุ้มครองอย่างปลอดภัย
                      โดยไม่มีการเปิดเผยข้อมูลสำคัญให้แก่บุคคลภายนอกโดยไม่ได้รับอนุญาต
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      3. การเปิดเผยข้อมูลแก่บุคคลที่สาม
                    </h3>
                    <p>
                      DekCode Shop จะไม่นำข้อมูลส่วนตัว อีเมล
                      หรือเงินคงเหลือของคุณไปเปิดเผย จำหน่าย
                      หรือแลกเปลี่ยนกับบุคคลที่สามโดยเด็ดขาด <em>เว้นแต่:</em>
                    </p>
                    <ul className="list-disc pl-5 space-y-1 mt-2">
                      <li>
                        ผู้ให้บริการประมวลผลที่จำเป็น (Cloud Hosting, Payment
                        Gateway) เฉพาะส่วนที่ต้องให้บริการ
                      </li>
                      <li>
                        เป็นไปเพื่อปฏิบัติตามกฎหมาย มีคำสั่งศาล
                        หรือคำสั่งของหน่วยงานที่มีอำนาจบังคับตามกฎหมาย
                      </li>
                      <li>
                        เพื่อใช้ป้องกันและรักษาความปลอดภัยต่อชีวิต
                        หรือปกป้องทรัพย์สินของ DekCode Shop{" "}
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      4. คุกกี้ (Cookies) และการจัดเก็บ Cache
                    </h3>
                    <p>
                      เราใช้คุกกี้ Session และ Local Storage
                      เพื่อช่วยจดจำการเข้าสู่ระบบ สถานะการทำงาน หรือตั้งค่าธีม
                      ลดภาระที่คุณต้องล็อกอินซ้ำ ไม่มีโฆษณาแทรกแซง ไม่มีการใช้
                      Tracking Pixels นำมาวิเคราะห์ขายต่อ หากคุณลบแคช
                      การเชื่อมต่อและการจดจำทั้งหมดที่คุณบันทึกไว้ในเบราว์เซอร์จะถูกล้างใหม่ทันที
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      5. สิทธิของเจ้าของข้อมูล (Data Subject Rights)
                    </h3>
                    <p>
                      ภายใต้กฎหมายที่มีผลบังคับ คุณมีสิทธิขอเข้าถึง แก้ไข
                      แจ้งขอสำเนา หรือลบข้อมูลบัญชีของตนเองได้บางส่วน ทั้งนี้
                      อาจมีข้อยกเว้นสำหรับประวัติการทำรายได้ ธุรกรรม
                      ข้อมูลล็อกที่ขัดกฎหมายการลบข้อมูล (Data Retention)
                      หากประสงค์ติดต่อเพื่อลบข้อมูล
                      สามารถขอความช่วยเหลือแอดมินได้ผ่านหน้าติดต่อ
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      6. การแก้ไขเปลี่ยนแปลงนโยบาย
                    </h3>
                    <p>
                      ระบบขอสงวนสิทธิ์ในการแก้ไขปรับปรุง
                      เปลี่ยนแปลงข้อความในนโยบายฉบับนี้โดยไม่ต้องแจ้งให้ผู้ใช้ทราบล่วงหน้า
                      โดยสามารถตรวจสอบวันได้ที่หน้าหัวข้อ “อัปเดตล่าสุด”
                      การเข้าถึงแพลตฟอร์มอย่างต่อเนื่องถือเป็นการยืนยันและการยอมรับข้อตกลงฉบับปรับปรุงแล้ว
                    </p>
                  </div>
                </div>
                <div className="pt-5 mt-5 border-t border-separator flex gap-3 flex-col sm:flex-row justify-end">
                  <button
                    type="button"
                    onClick={() => setShowPrivacy(false)}
                    className="bg-accent hover:bg-accent-hover text-white font-medium py-2.5 px-6 transition-colors w-full sm:w-auto rounded-full text-xs cursor-pointer shadow-sm active:scale-95"
                  >
                    ทำความเข้าใจและปิดหน้าต่าง
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}

          {showTerms && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[100] font-sans"
              onClick={() => setShowTerms(false)}
            >
              <motion.div
                role="dialog"
                aria-modal="true"
                aria-labelledby="terms-modal-title"
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-surface border border-separator p-6 sm:p-8 max-w-3xl w-full max-h-[90vh] flex flex-col relative rounded-3xl shadow-2xl backdrop-blur-xl text-label"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 id="terms-modal-title" className="text-xl sm:text-2xl font-semibold flex items-center gap-2 text-label">
                    <ListChecks className="w-6 h-6 shrink-0 text-accent" />{" "}
                    ข้อกำหนดการใช้งาน (Terms of Use)
                  </h2>
                  <button
                    type="button"
                    onClick={() => setShowTerms(false)}
                    aria-label="ปิดหน้าต่างข้อกำหนดการใช้งาน"
                    className="p-2 hover:bg-surface-2 transition-colors rounded-full text-label-3 hover:text-label cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="overflow-y-auto pr-2 sm:pr-4 space-y-6 text-xs sm:text-sm leading-relaxed text-label-2 scrollbar-thin scrollbar-thumb-surface-2 flex-1">
                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      1. การรับรองความยินยอมและผูกพัน
                    </h3>
                    <p>
                      การเข้าถึงและใช้งานบริการ เครื่องมือตรวจสอบ บอท
                      และผลิตภัณฑ์ของเรา
                      ถือเป็นการรับรองว่าท่านได้ทำความเข้าใจและตกลงยอมรับเงื่อนไขการใช้บริการของ{" "}
                      <strong>DekCode Shop</strong> อย่างครบถ้วนทุกประการ
                      หากคุณไม่เห็นด้วยกับกฎหมายและข้อบังคับเหล่านี้กรุณายุติการเข้าถึงและการใช้งานโดยทันที
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      2. ขอบเขตสิทธิ์ หน้าที่ และการใช้งานที่ยอมรับได้ (AUP)
                    </h3>
                    <p className="mb-2">
                      คุณตกลงที่จะใช้สิทธิ์ในการเข้าถึงที่เรารับรอง
                      เพื่อจุดประสงค์ส่วนตัวที่ถูกต้องตามกฎหมาย และยินยอมที่จะ{" "}
                      <strong>ไม่กระทำ</strong> สิ่งเหล่านี้ไม่ว่ากรณีใดๆ :
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>
                        <strong>
                          ห้ามวิศวกรรมย้อนกลับ (No Reverse Engineering):
                        </strong>{" "}
                        ห้ามดัดแปลง ชำแหละเจาะระบบ สแกนพอร์ต จำลอง API เถื่อน นำ
                        API ผิดกฎหมายหรือ Bypass
                        เข้าใช้บริการของเราโดยไม่ได้รับอนุญาต
                      </li>
                      <li>
                        <strong>
                          ห้ามกระทำละเมิดแพลตฟอร์มรุนแรง (Anti-DDoS, Spamming):
                        </strong>{" "}
                        ห้ามทดสอบความปลอดภัย ก่อความล่าช้า หรือกระหน่ำยิงแพ็กเกจ
                        (Flood Requests) เพื่อทำลายความเสถียรของเซิร์ฟเวอร์
                      </li>
                      <li>
                        <strong>ข้อพิพาทความเป็นเจ้าของข้อมูลส่วนบุคคล:</strong>{" "}
                        ผู้ใช้งานจะต้องเป็นเจ้าของข้อมูล พาสเวิร์ด คีย์ บัญชี
                        หรือมีสิทธิ์อนุญาตโดยชอบธรรมเท่านั้น
                        หากท่านนำไปใช้งานในทางละเมิดผู้อื่น สิทธิ
                        ความรับผิดชอบทางกฎหมายใดๆ
                        ถือเป็นความรับผิดชอบของตัวลูกค้า/ผู้ใช้งานโดยเพียงผู้เดียวเท่านั้น
                        ทางทีมงานจะไม่มีส่วนรู้เห็นในทุกกรณี
                      </li>
                      <li>
                        <strong>การบ่อนทำลาย/แอบอ้าง:</strong> ห้ามคัดลอก
                        ทำสำเนาเนื้อหา และผลิตภัณฑ์เพื่อไปชุบมือเปิบ แอบอ้าง
                        หรือขายนอกแพลตฟอร์มโดยไม่ได้รับอนุญาต
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      3. การชำระเงิน การเติมเงิน และนโยบายล้างบางเครดิต (No
                      Refund Policy)
                    </h3>
                    <p className="mb-2">
                      เมื่อคุณยืนยันเติมเครดิต ชำระคีย์ โอนเงินซื้อบัญชี
                      หรือสินค้าดิจิทัลใน DekCode Shop คำสั่งซื้อดังกล่าว{" "}
                      <strong>
                        ไม่สามารถคืนเป็นเงินสด (Non-Refundable) ในทุกกรณี
                      </strong>{" "}
                      เครดิตในรหัสไม่สามารถโยกย้ายข้ามผู้ใช้ได้
                      หากพบความผิดปกติของการเติมเงิน บัตรปลอม หรือการโกง
                      แอดมินมีสิทธิเต็มที่ในการเพิกถอนยอด ล็อคแบน
                      และยึดสินค้าทั้งหมดทันที
                    </p>
                    <p>
                      สินค้ารับประกันการใช้งาน
                      จะถูกอ้างอิงตามระยะเวลาประกันของสินค้าชิ้นนั้นๆ
                      หากเลยเงื่อนไขที่กำหนดไว้จะไม่รับผิดชอบทุกกรณี
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      4. ข้อยกเว้นและข้อจำกัดความรับผิดชอบ (Disclaimer)
                    </h3>
                    <p className="mb-2">
                      การทำธุรกรรมและเครื่องมือนี้ ทำงานในรูปแบบ "ตามสภาพ (As
                      is)" เราไม่รับประกัน 100% ว่าไม่มีข้อบกพร่อง การขัดข้อง
                      ล่าช้า หรือผลเช็คต่างๆ จะแม่นยำเสมอไป
                      ทั้งนี้เครื่องมือเราไร้สถานะ (No-Affiliation)
                      ต่อนายจ้างหรือบริษัทแม่ของช่องโซเชียลนั้นๆ
                    </p>
                    <p>
                      เราจะไม่รับผิดชอบจากความสูญเสีย โดนแบน ยอดวิวตก
                      หรือความเสียหายในทางอ้อม ทางการค้า
                      หรือทางปกครองที่เกิดจากการเข้าใช้บริการ ข้อมูลต่างๆ
                      สามารถเข้าถึงได้ขึ้นอยู่กับความเสี่ยงของตนเอง
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      5. สิทธิของการยุติการให้บริการ และ IP Ban
                    </h3>
                    <p>
                      ทีมงาน DekCode Shop ถือสิทธิเด็ดขาดสูงสุดในการเตะ
                      หรือถอดถอนผู้ใช้ ระงับบัญชี (Ban)
                      เปลี่ยนแปลงแก้ไขการใช้งาน และระงับช่องทางการเข้าถึง (IP
                      Blocking) โดยไม่ต้องแจ้งตักเตือนรวมถึงชดใช้ค่าเสียหายใดๆ
                      ให้แก่ผู้ใช้งาน หากพบการทุจริต หรือคุกคามเจ้าหน้าที่
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      ระบบและบริการของเรา
                    </h3>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>
                        <strong>Digital Marketplace & VIP Tiers:</strong>{" "}
                        ร้านค้าจำหน่ายผลิตภัณฑ์ซอฟต์แวร์ คีย์โปรแกรม
                        และบริการพรีเมียม ด้วยระบบจัดการคลังสินค้าอัตโนมัติ
                        ตัดยอดและส่งมอบสินค้าผ่านระบบที่ปลอดภัยตลอด 24 ชั่วโมง
                      </li>
                      <li>
                        <strong>Community & Support:</strong>{" "}
                        ระบบบริการลูกค้า สอบถามข้อมูล ยืนยันคำสั่งซื้อ
                        และสิทธิประโยชน์สำหรับสมาชิกคอมมูนิตี้
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      ความมุ่งมั่นด้านความปลอดภัย (Security Commitment)
                    </h3>
                    <p>
                      รากฐานของโปรเจ็กต์คือการเก็บรักษาข้อมูลให้เป็นความลับ
                      (Confidentiality) และความปลอดภัยสูงสุดของระบบการชำระเงิน
                      สถาปัตยกรรมเซิร์ฟเวอร์ของเรามีระบบการเข้ารหัสข้อมูลที่รัดกุม
                      การตรวจสอบสิทธิ์แบบหลายชั้น และการป้องกันการทำธุรกรรมซ้ำซ้อน
                      ทำให้ข้อมูลการสั่งซื้อของคุณได้รับการดูแลอย่างมืออาชีพ
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-label text-base mb-2">
                      ช่องทางติดต่อคอมมูนิตี้ (Contact & Community)
                    </h3>
                    <p className="mb-2">
                      เราไม่ได้มีแต่เว็บขายของ
                      แต่เราเติบโตด้วยแรงสุนทรีย์ของคอมมูนิตี้
                      หากคุณประสบปัญหาในการใช้งาน พบช่องโหว่
                      หรืออยากพูดคุยเสนอแนวทางใหม่ๆ:
                    </p>
                    <ul className="list-disc pl-5">
                      <li>
                        <strong>Discord Server:</strong> สถานที่เชื่อมสัมพันธ์
                        ร้องขอเครดิต หรือสอบถามการเซ็ตอัปบอท
                      </li>
                      <li>
                        <strong>Line Official:</strong> ทีม Support
                        โดยผู้ดูแลมืออาชีพ (ตอบกลับรวดเร็วที่สุด)
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="pt-5 mt-5 border-t border-separator flex justify-end w-full">
                  <button
                    type="button"
                    onClick={() => setShowTerms(false)}
                    className="bg-accent hover:bg-accent-hover text-white font-medium py-2.5 px-6 transition-colors w-full sm:w-auto rounded-full text-xs cursor-pointer shadow-sm active:scale-95"
                  >
                    ปิดหน้าต่างนี้
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}

          {showContactUs && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[100] font-sans"
              onClick={() => setShowContactUs(false)}
            >
              <motion.div
                role="dialog"
                aria-modal="true"
                aria-labelledby="contact-modal-title"
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-surface border border-separator p-6 sm:p-8 max-w-md w-full flex flex-col relative rounded-3xl shadow-2xl backdrop-blur-xl text-label"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 id="contact-modal-title" className="text-xl sm:text-2xl font-semibold flex items-center gap-2 text-label">
                    <Phone className="w-5 h-5 shrink-0 text-accent" />{" "}
                    ติดต่อเรา
                  </h2>
                  <button
                    type="button"
                    onClick={() => setShowContactUs(false)}
                    aria-label="ปิดหน้าต่างติดต่อเรา"
                    className="p-2 hover:bg-surface-2 transition-colors rounded-full text-label-3 hover:text-label cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3">
                  <a
                    href="https://discord.gg/EvFjgkSB4W"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 bg-surface-2 hover:bg-surface border border-separator text-label transition-all duration-200 group rounded-2xl"
                  >
                    <div className="w-11 h-11 bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform rounded-xl text-accent font-semibold text-lg">
                      D
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm text-label">Discord</h3>
                      <p className="text-label-2 text-xs mt-0.5">
                        เข้าร่วมเซิร์ฟเวอร์คอมมูนิตี้ของเรา
                      </p>
                    </div>
                  </a>

                  {siteSettings?.contact_email && (
                    <a
                      href={`mailto:${siteSettings.contact_email}`}
                      className="flex items-center gap-4 p-4 bg-surface-2 hover:bg-surface border border-separator text-label transition-all duration-200 group rounded-2xl"
                    >
                      <div className="w-11 h-11 bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform rounded-xl text-accent">
                        <Mail className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-label">Email</h3>
                        <p className="text-label-2 text-xs mt-0.5">
                          {siteSettings.contact_email}
                        </p>
                      </div>
                    </a>
                  )}
                </div>

                <div className="pt-5 mt-5 border-t border-separator flex justify-end w-full">
                  <button
                    type="button"
                    onClick={() => setShowContactUs(false)}
                    className="bg-surface-2 hover:bg-surface text-label font-medium py-2.5 px-6 transition-colors w-full sm:w-auto rounded-full text-xs cursor-pointer border border-separator"
                  >
                    ปิดหน้าต่างนี้
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Modals - Restricted strictly to authenticated admin */}
        <SupabaseConfigModal
          isOpen={Boolean(isAdmin && showSupabaseModal)}
          onClose={() => setShowSupabaseModal(false)}
          onSuccess={() => refreshAllSystemData()}
        />

        <Suspense fallback={null}>
          {purchasedItemReceipt && (
            <ReceiptModal
              selectedItem={purchasedItemReceipt}
              setSelectedItem={(item) => {
                setPurchasedItemReceipt(item);
                // When modal is manually closed
                if (!item) {
                  setActiveView("history");
                }
              }}
            />
          )}
        </Suspense>

      {/* Mobile Bottom Navigation Bar removed as per request */}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="*" element={<AppContent />} />
        </Routes>
      </BrowserRouter>
      <ToastContainer />
    </ErrorBoundary>
  );
}