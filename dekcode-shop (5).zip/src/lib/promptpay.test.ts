/**
 * Unit tests and test vectors for PromptPay EMVCo QR generator
 * Run with: npx tsx src/lib/promptpay.test.ts
 */

import { crc16, generatePromptPayPayload, generatePromptPayQrDataUrl, formatPromptPayTarget } from './promptpay';

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`✓ ${message}`);
}

async function runTests() {
  console.log('--- Testing PromptPay EMVCo Generator ---');

  // 1. Verify CRC16-CCITT standard test vector
  const crcTest = crc16('123456789');
  assert(crcTest === '29B1', `CRC16 vector '123456789' must equal 29B1 (got ${crcTest})`);

  // 2. Mobile phone formatting
  const phoneTarget = formatPromptPayTarget('081-234-5678');
  assert(phoneTarget.subTagId === '01', 'Phone target must use subtag 01');
  assert(phoneTarget.formattedTarget === '0066812345678', 'Phone target must be formatted as 0066812345678');

  // 3. Citizen ID formatting
  const idTarget = formatPromptPayTarget('1-2345-67890-12-3');
  assert(idTarget.subTagId === '02', '13-digit ID must use subtag 02');
  assert(idTarget.formattedTarget === '1234567890123', 'ID target must be 13 digits raw');

  // 4. Static PromptPay payload without amount
  const staticPayload = generatePromptPayPayload('0812345678');
  assert(staticPayload.startsWith('000201010211'), 'Static payload must start with format 01 and initiation method 11');
  assert(staticPayload.includes('29370016A00000067701011101130066812345678'), 'Static payload must include Tag 29 AID and phone');
  assert(!staticPayload.includes('540'), 'Static payload must NOT have Tag 54 amount');
  assert(staticPayload.includes('5802TH6304'), 'Payload must include TH country code and 6304 checksum tag');
  const staticCrc = staticPayload.slice(-4);
  const staticPayloadWithoutCrc = staticPayload.slice(0, -4);
  assert(crc16(staticPayloadWithoutCrc) === staticCrc, 'Static payload CRC must match re-calculated CRC');

  // 5. Dynamic PromptPay payload with amount
  const dynamicPayload = generatePromptPayPayload('0812345678', 150.50);
  assert(dynamicPayload.startsWith('000201010212'), 'Dynamic payload with amount must have initiation method 12');
  assert(dynamicPayload.includes('5406150.50'), 'Dynamic payload must include Tag 54 with amount 150.50');
  const dynamicCrc = dynamicPayload.slice(-4);
  const dynamicPayloadWithoutCrc = dynamicPayload.slice(0, -4);
  assert(crc16(dynamicPayloadWithoutCrc) === dynamicCrc, 'Dynamic payload CRC must match re-calculated CRC');

  // 6. Client-side QR DataURL generation
  const dataUrl = await generatePromptPayQrDataUrl('0812345678', 100);
  assert(dataUrl.startsWith('data:image/png;base64,'), 'QR generator must return standard base64 PNG data URL');

  console.log('--- All PromptPay tests passed successfully! ---');
}

runTests().catch((err) => {
  console.error('Test failed:', err);
  process.exit(1);
});
