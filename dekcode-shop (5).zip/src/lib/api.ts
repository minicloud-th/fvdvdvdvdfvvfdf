import axios from 'axios';
import axiosRetry from 'axios-retry';
import { auth } from './firebase';

let initialized = false;

export function setupApi(): void {
  if (initialized) return;
  initialized = true;

  // Retry only network errors and idempotent GET/HEAD requests
  try {
    axiosRetry(axios, {
      retries: 2,
      retryDelay: axiosRetry.exponentialDelay,
      retryCondition: (error) => {
        return axiosRetry.isNetworkOrIdempotentRequestError(error);
      },
    });
  } catch (e) {
    console.warn('[setupApi] axiosRetry init warning:', e);
  }

  // Request interceptor to attach Firebase ID token or demo auth token
  axios.interceptors.request.use(async (config) => {
    try {
      if (auth?.currentUser) {
        const token = await auth.currentUser.getIdToken();
        if (token) {
          config.headers = config.headers || {};
          config.headers.Authorization = `Bearer ${token}`;
          return config;
        }
      }
    } catch {
      // Ignore token refresh failure
    }

    // Fallback: check localStorage for cached token or demo token
    try {
      const storedToken = localStorage.getItem('astrax_auth_token') || localStorage.getItem('token');
      if (storedToken && (!config.headers || !config.headers.Authorization)) {
        config.headers = config.headers || {};
        config.headers.Authorization = `Bearer ${storedToken}`;
      }
    } catch {}

    return config;
  }, (error) => Promise.reject(error));

  // Response interceptor
  axios.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error?.response?.status === 403 && error?.response?.data?.code === 'IP_BLOCKED') {
        console.error('[API] IP Address is blocked by administrator:', error.response.data?.error);
      }
      return Promise.reject(error);
    }
  );
}

export function apiError(err: any, fallback = 'เกิดข้อผิดพลาดในการเชื่อมต่อ'): string {
  if (!err) return fallback;
  if (typeof err === 'string') return err;
  const data = err?.response?.data;
  if (data) {
    if (typeof data.error === 'string' && data.error.trim()) return data.error;
    if (typeof data.message === 'string' && data.message.trim()) return data.message;
  }
  if (typeof err?.message === 'string' && err.message.trim()) return err.message;
  return fallback;
}
