/**
 * PromptPay EMVCo QR Generator & CRC16-CCITT Utility
 * 
 * Generates official EMVCo compliant PromptPay QR Code payloads (BOT standard)
 * Supports:
 * - Mobile Phone (10 digits, formatted to international format 0066...)
 * - National ID / Tax ID (13 digits)
 * - e-Wallet ID (15 digits)
 * - Dynamic Amount (Tag 54) with 2 decimal precision
 * - CRC16-CCITT (poly 0x1021, init 0xFFFF, CCITT-FALSE) checksum calculation
 * - Client-side QR Code Data URL rendering (zero third-party API tracking)
 */

import QRCode from 'qrcode';

/**
 * Calculates standard CRC16-CCITT (polynomial 0x1021, initial value 0xFFFF)
 * Used by EMVCo Merchant-Presented Mode specifications (Annex B)
 */
export function crc16(data: string): string {
  let crc = 0xffff;
  for (let i = 0; i < data.length; i++) {
    crc ^= data.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) {
        crc = ((crc << 1) ^ 0x1021) & 0xffff;
      } else {
        crc = (crc << 1) & 0xffff;
      }
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

/**
 * Formats a single EMV TLV (Tag-Length-Value) chunk
 */
function formatTlv(tag: string, value: string): string {
  const length = value.length.toString().padStart(2, '0');
  return `${tag}${length}${value}`;
}

/**
 * Formats the PromptPay target account / phone / ID
 */
export function formatPromptPayTarget(target: string): { subTagId: string; formattedTarget: string } {
  const cleaned = target.replace(/[^0-9]/g, '');

  if (cleaned.length === 10 && cleaned.startsWith('0')) {
    // Mobile phone number: 08x-xxx-xxxx -> 00668xxxxxxxx (13 chars)
    return {
      subTagId: '01',
      formattedTarget: '0066' + cleaned.slice(1),
    };
  }

  if (cleaned.length === 13) {
    // National ID or Tax ID: 13 digits
    return {
      subTagId: '02',
      formattedTarget: cleaned,
    };
  }

  if (cleaned.length === 15) {
    // e-Wallet ID: 15 digits
    return {
      subTagId: '03',
      formattedTarget: cleaned,
    };
  }

  // Fallback for 9-digit phone without leading 0 or other bank identifiers
  if (cleaned.length === 9) {
    return {
      subTagId: '01',
      formattedTarget: '0066' + cleaned,
    };
  }

  // Generic fallback: format as mobile or account identifier
  return {
    subTagId: '01',
    formattedTarget: cleaned.startsWith('0') ? '0066' + cleaned.slice(1) : cleaned.padStart(13, '0'),
  };
}

/**
 * Generates an official EMVCo PromptPay QR payload string
 * 
 * @param target PromptPay target (mobile phone, citizen ID, or e-Wallet ID)
 * @param amount Optional transaction amount (THB). If provided and > 0, adds Tag 54 and sets initiation to dynamic (12)
 * @returns Fully formed EMVCo string including Tag 63 checksum
 */
export function generatePromptPayPayload(target: string, amount?: number | null): string {
  const { subTagId, formattedTarget } = formatPromptPayTarget(target);

  // Tag 00: Payload Format Indicator (Fixed "01")
  const tag00 = formatTlv('00', '01');

  // Tag 01: Point of Initiation Method
  // "11" for Static QR (amount chosen by user in banking app)
  // "12" for Dynamic QR (amount embedded in QR code)
  const hasAmount = typeof amount === 'number' && amount > 0;
  const tag01 = formatTlv('01', hasAmount ? '12' : '11');

  // Tag 29: Merchant Account Information - PromptPay
  // Sub-tag 00: AID "A000000677010111" (PromptPay AID)
  // Sub-tag 01 (Phone), 02 (National ID), or 03 (e-Wallet)
  const subTag00 = formatTlv('00', 'A000000677010111');
  const subTagTarget = formatTlv(subTagId, formattedTarget);
  const tag29 = formatTlv('29', subTag00 + subTagTarget);

  // Tag 53: Transaction Currency (764 = THB)
  const tag53 = formatTlv('53', '764');

  // Tag 54: Transaction Amount (2 decimal places)
  let tag54 = '';
  if (hasAmount) {
    const formattedAmount = amount.toFixed(2);
    tag54 = formatTlv('54', formattedAmount);
  }

  // Tag 58: Country Code ("TH")
  const tag58 = formatTlv('58', 'TH');

  // Assemble preliminary payload ending with Tag 63 (Checksum tag with length '04')
  const preliminary = `${tag00}${tag01}${tag29}${tag53}${tag54}${tag58}6304`;

  // Calculate CRC16-CCITT checksum over preliminary string
  const checksum = crc16(preliminary);

  return `${preliminary}${checksum}`;
}

/**
 * Generates a client-side Data URL for the PromptPay QR code
 * Renders in browser using HTML5 Canvas / SVG without making any network requests
 */
export async function generatePromptPayQrDataUrl(
  target: string,
  amount?: number | null,
  options?: { width?: number; margin?: number }
): Promise<string> {
  const payload = generatePromptPayPayload(target, amount);
  return QRCode.toDataURL(payload, {
    width: options?.width || 280,
    margin: options?.margin ?? 2,
    errorCorrectionLevel: 'M',
    color: {
      dark: '#000000',
      light: '#ffffff',
    },
  });
}
