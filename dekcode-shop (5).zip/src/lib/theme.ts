import { useState, useEffect } from "react";

export type Theme = "dark" | "light";

export const DEKCODE_LOGO_DARK_URL = "https://i.postimg.cc/nr2sqWr5/dekcode-white-transparent.png";
export const DEKCODE_LOGO_LIGHT_URL = "https://i.postimg.cc/SNZ2sHwD/dekcode-black-transparent.png";

const THEME_STORAGE_KEY = "dekcode_theme";

export function getStoredTheme(): Theme {
  try {
    if (typeof localStorage !== "undefined") {
      const saved = localStorage.getItem(THEME_STORAGE_KEY) || localStorage.getItem("astrax_theme");
      if (saved === "light" || saved === "dark") {
        return saved;
      }
    }
    if (typeof window !== "undefined" && window.matchMedia) {
      return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
  } catch {}
  return "dark"; // Default to dark
}

export function applyTheme(theme: Theme) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  if (theme === "light") {
    root.classList.remove("dark");
    root.classList.add("light");
    root.dataset.theme = "light";
    root.style.colorScheme = "light";
  } else {
    root.classList.remove("light");
    root.classList.add("dark");
    root.dataset.theme = "dark";
    root.style.colorScheme = "dark";
  }
}

export function setStoredTheme(theme: Theme) {
  try {
    if (typeof localStorage !== "undefined") {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
      localStorage.setItem("astrax_theme", theme);
    }
  } catch {}
  applyTheme(theme);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("dekcode-theme-change", { detail: theme }));
    window.dispatchEvent(new CustomEvent("astrax-theme-change", { detail: theme }));
  }
}

/**
 * Toggles theme with a buttery-smooth GPU-composited crossfade
 * Uses modern View Transition API when available for 60-120fps smoothness,
 * or immediate clean transition without blocking or freezing the DOM.
 */
export function toggleThemeWithTransition(
  currentTheme: Theme,
  onThemeChanged: (next: Theme) => void,
  _event?: React.MouseEvent | MouseEvent
) {
  const nextTheme: Theme = currentTheme === "dark" ? "light" : "dark";

  const prefersReducedMotion =
    typeof window !== "undefined" &&
    window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

  if (typeof document !== "undefined" && "startViewTransition" in document && !prefersReducedMotion) {
    (document as any).startViewTransition(() => {
      setStoredTheme(nextTheme);
      onThemeChanged(nextTheme);
    });
    return;
  }

  setStoredTheme(nextTheme);
  onThemeChanged(nextTheme);
}

export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(getStoredTheme);

  useEffect(() => {
    // Sync DOM with current theme
    applyTheme(theme);

    const handleThemeChange = (e: Event) => {
      const customEvent = e as CustomEvent<Theme>;
      if (customEvent.detail) {
        setThemeState(customEvent.detail);
      } else {
        setThemeState(getStoredTheme());
      }
    };

    window.addEventListener("dekcode-theme-change", handleThemeChange);
    window.addEventListener("astrax-theme-change", handleThemeChange);
    return () => {
      window.removeEventListener("dekcode-theme-change", handleThemeChange);
      window.removeEventListener("astrax-theme-change", handleThemeChange);
    };
  }, [theme]);

  const toggleTheme = (e?: React.MouseEvent | MouseEvent) => {
    toggleThemeWithTransition(theme, setThemeState, e);
  };

  const logoUrl = theme === "light" ? DEKCODE_LOGO_LIGHT_URL : DEKCODE_LOGO_DARK_URL;

  return { theme, toggleTheme, setTheme: setStoredTheme, logoUrl };
}
