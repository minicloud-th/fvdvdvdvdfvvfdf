export const SUPABASE_SQL_SCHEMA = `-- =========================================================================
-- ASTRAX STORE - SUPABASE DATABASE SCHEMA & SECURE RLS POLICIES
-- วิธีใช้: คัดลอกคำสั่ง SQL ทั้งหมดนี้ไปวางในเมนู SQL Editor ใน Supabase Dashboard แล้วกด Run
-- =========================================================================

-- 1. สร้างตาราง PROFILES (ข้อมูลสมาชิก ยอดเงิน และบทบาท)
CREATE TABLE IF NOT EXISTS public.profiles (
    id TEXT PRIMARY KEY,
    email TEXT,
    username TEXT,
    full_name TEXT,
    role TEXT DEFAULT 'user',
    rank TEXT DEFAULT 'user',
    balance NUMERIC DEFAULT 0 CHECK (balance >= 0),
    is_premium BOOLEAN DEFAULT false,
    avatar_url TEXT,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active';
CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_uidx ON public.profiles (lower(username));

-- 2. สร้างตาราง CATEGORIES (หมวดหมู่สินค้า)
CREATE TABLE IF NOT EXISTS public.categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    title TEXT,
    subtitle TEXT,
    banner_url TEXT,
    image_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. สร้างตาราง PRODUCTS (รายการสินค้าและสต็อก)
CREATE TABLE IF NOT EXISTS public.products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL DEFAULT 0 CHECK (price >= 0),
    original_price NUMERIC,
    category TEXT,
    image_url TEXT,
    stock INTEGER DEFAULT 0 CHECK (stock >= 0),
    stock_data JSONB DEFAULT '[]'::jsonb,
    sold_count INTEGER DEFAULT 0,
    is_popular BOOLEAN DEFAULT false,
    tag TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. สร้างตาราง ORDERS (ประวัติคำสั่งซื้อและการส่งมอบสินค้า)
CREATE TABLE IF NOT EXISTS public.orders (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    username TEXT,
    product_id TEXT,
    product_name TEXT,
    price NUMERIC DEFAULT 0,
    amount NUMERIC DEFAULT 0,
    quantity INTEGER DEFAULT 1,
    item_data TEXT,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. สร้างตาราง TOPUPS (ประวัติการเติมเงิน)
CREATE TABLE IF NOT EXISTS public.topups (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    username TEXT,
    type TEXT DEFAULT 'promptpay',
    amount NUMERIC DEFAULT 0 CHECK (amount >= 0),
    reference_no TEXT,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. สร้างตาราง LICENSE_KEYS (โค้ดคีย์เติมเงิน / โปรโมชัน)
CREATE TABLE IF NOT EXISTS public.license_keys (
    id TEXT PRIMARY KEY,
    key TEXT UNIQUE NOT NULL,
    type TEXT DEFAULT 'balance',
    value NUMERIC NOT NULL DEFAULT 0 CHECK (value >= 0),
    description TEXT,
    is_used BOOLEAN DEFAULT false,
    used_by TEXT,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. สร้างตาราง SITE_SETTINGS (การตั้งค่าร้านค้า)
CREATE TABLE IF NOT EXISTS public.site_settings (
    id TEXT PRIMARY KEY DEFAULT 'default',
    site_name TEXT DEFAULT 'Astrax',
    announcement_text TEXT,
    contact_line TEXT,
    discord_link TEXT,
    facebook_link TEXT,
    promptpay_number TEXT,
    promptpay_name TEXT,
    truewallet_phone TEXT,
    banners JSONB DEFAULT '[]'::jsonb,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS quantity INTEGER DEFAULT 1;
ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS instagram_link TEXT,
  ADD COLUMN IF NOT EXISTS contact_email TEXT,
  ADD COLUMN IF NOT EXISTS popup_enabled BOOLEAN DEFAULT true,
  ADD COLUMN IF NOT EXISTS popup_img_url TEXT,
  ADD COLUMN IF NOT EXISTS popup_link TEXT,
  ADD COLUMN IF NOT EXISTS stats_users_offset NUMERIC DEFAULT 0,
  ADD COLUMN IF NOT EXISTS stats_sales_offset NUMERIC DEFAULT 0,
  ADD COLUMN IF NOT EXISTS spotify_url TEXT,
  ADD COLUMN IF NOT EXISTS spotify_autoplay BOOLEAN DEFAULT false;

-- 8. สร้างตาราง VERIFIED_SLIPS (ป้องกันการใช้สลิปซ้ำถาวร)
CREATE TABLE IF NOT EXISTS public.verified_slips (
    trans_ref TEXT PRIMARY KEY,
    amount NUMERIC NOT NULL,
    user_id TEXT NOT NULL,
    verified_at TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

-- แทรกค่าเริ่มต้นของการตั้งค่าร้านค้า (ถ้ายังไม่มี)
INSERT INTO public.site_settings (id, site_name, announcement_text)
VALUES ('default', 'Astrax', 'ยินดีต้อนรับสู่ Astrax ศูนย์รวมสินค้าและบริการดิจิทัลชั้นนำ')
ON CONFLICT (id) DO NOTHING;

-- =========================================================================
-- SECURITY DEFINER HELPER FUNCTIONS
-- =========================================================================

-- ฟังก์ชันตรวจสอบว่าผู้ใช้งานปัจจุบันมีสิทธิ์ Admin หรือไม่
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean AS $$
BEGIN
  -- อนุญาต service_role เสมอ
  IF (COALESCE(current_setting('request.jwt.claims', true)::jsonb ->> 'role', '') = 'service_role') THEN
    RETURN true;
  END IF;

  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid()::text AND (role = 'admin' OR role = 'Admin')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public, pg_temp;

-- Trigger ป้องกันผู้ใช้ทั่วไปแก้ไข role, balance, rank, is_premium ใน profiles ด้วยตนเอง
CREATE OR REPLACE FUNCTION public.prevent_profile_sensitive_update()
RETURNS TRIGGER AS $$
BEGIN
  -- ถ้าเป็น service_role หรือ admin สามารถแก้ไขได้
  IF (COALESCE(current_setting('request.jwt.claims', true)::jsonb ->> 'role', '') = 'service_role') OR public.is_admin() THEN
    RETURN NEW;
  END IF;

  -- สำหรับผู้ใช้ทั่วไป ไม่อนุญาตให้แก้ไขข้อมูลสำคัญ
  IF NEW.role IS DISTINCT FROM OLD.role THEN
    RAISE EXCEPTION 'ไม่อนุญาตให้แก้ไขสิทธิ์บัญชี (role) ด้วยตนเอง';
  END IF;
  IF NEW.balance IS DISTINCT FROM OLD.balance THEN
    RAISE EXCEPTION 'ไม่อนุญาตให้แก้ไขยอดเงินคงเหลือ (balance) ด้วยตนเอง';
  END IF;
  IF NEW.rank IS DISTINCT FROM OLD.rank THEN
    RAISE EXCEPTION 'ไม่อนุญาตให้แก้ไขระดับผู้ใช้ (rank) ด้วยตนเอง';
  END IF;
  IF NEW.is_premium IS DISTINCT FROM OLD.is_premium THEN
    RAISE EXCEPTION 'ไม่อนุญาตให้แก้ไขสถานะพรีเมียม (is_premium) ด้วยตนเอง';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

DROP TRIGGER IF EXISTS trg_prevent_profile_sensitive_update ON public.profiles;
CREATE TRIGGER trg_prevent_profile_sensitive_update
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.prevent_profile_sensitive_update();

-- ฟังก์ชันสำหรับ Redeem License Key แบบปลอดภัย (SECURITY DEFINER)
CREATE OR REPLACE FUNCTION public.redeem_license_key(input_key TEXT)
RETURNS jsonb AS $$
DECLARE
  v_user_id TEXT;
  v_key_record RECORD;
  v_new_balance NUMERIC;
BEGIN
  v_user_id := auth.uid()::text;
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'กรุณาเข้าสู่ระบบก่อนใช้งานคีย์';
  END IF;

  -- ค้นหาและ Lock แถวของ key ไว้ป้องกัน Race Condition
  SELECT * INTO v_key_record
  FROM public.license_keys
  WHERE key = input_key AND is_used = false
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'คีย์ไม่ถูกต้อง หรือถูกใช้งานไปแล้ว';
  END IF;

  -- อัปเดตสถานะของ key
  UPDATE public.license_keys
  SET is_used = true,
      used_by = v_user_id,
      used_at = NOW()
  WHERE id = v_key_record.id;

  -- เพิ่มเงินเข้าบัญชีของผู้ใช้
  UPDATE public.profiles
  SET balance = balance + v_key_record.value,
      updated_at = NOW()
  WHERE id = v_user_id
  RETURNING balance INTO v_new_balance;

  RETURN jsonb_build_object(
    'success', true,
    'message', 'ใช้งานคีย์สำเร็จ',
    'value', v_key_record.value,
    'new_balance', v_new_balance
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ฟังก์ชัน Redeem สำหรับเซิร์ฟเวอร์ (เรียกด้วย service_role เท่านั้น) — ทำงานแบบ atomic
-- (ฟังก์ชันเดิมใช้ auth.uid() ซึ่งเป็น NULL เมื่อเรียกจากเซิร์ฟเวอร์ จึงใช้งานไม่ได้)
CREATE OR REPLACE FUNCTION public.redeem_license_key_for_user(input_key TEXT, p_user_id TEXT)
RETURNS jsonb AS $$
DECLARE
  v_key RECORD;
  v_new_balance NUMERIC;
BEGIN
  SELECT * INTO v_key FROM public.license_keys
  WHERE key = upper(trim(input_key)) AND is_used = false
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'คีย์ไม่ถูกต้อง หรือถูกใช้งานไปแล้ว';
  END IF;

  UPDATE public.license_keys
  SET is_used = true, used_by = p_user_id, used_at = NOW()
  WHERE id = v_key.id;

  UPDATE public.profiles
  SET balance = balance + CASE WHEN v_key.type = 'balance' THEN v_key.value ELSE 0 END,
      rank = CASE WHEN v_key.type = 'rank_premium' THEN 'premium' ELSE rank END,
      is_premium = CASE WHEN v_key.type = 'rank_premium' THEN true ELSE is_premium END,
      updated_at = NOW()
  WHERE id = p_user_id
  RETURNING balance INTO v_new_balance;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'ไม่พบผู้ใช้งาน';
  END IF;

  RETURN jsonb_build_object('success', true, 'value', v_key.value, 'type', v_key.type, 'new_balance', v_new_balance);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

REVOKE ALL ON FUNCTION public.redeem_license_key_for_user(TEXT, TEXT) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.redeem_license_key_for_user(TEXT, TEXT) TO service_role;
REVOKE ALL ON FUNCTION public.redeem_license_key(TEXT) FROM PUBLIC, anon;

-- =========================================================================
-- ปกป้องคีย์สินค้า: stock_data ห้ามถูกอ่านผ่าน anon/authenticated (อ่านได้เฉพาะ service_role ของเซิร์ฟเวอร์)
-- =========================================================================
REVOKE SELECT ON public.products FROM anon, authenticated;
GRANT SELECT (id, name, description, price, original_price, category, image_url, stock, sold_count, is_popular, tag, created_at)
  ON public.products TO anon, authenticated;

-- =========================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- =========================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.topups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.license_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.verified_slips ENABLE ROW LEVEL SECURITY;

-- ลบ Policies เก่าออกทั้งหมด
DROP POLICY IF EXISTS "Public Read Categories" ON public.categories;
DROP POLICY IF EXISTS "Public Read Products" ON public.products;
DROP POLICY IF EXISTS "Public Read Settings" ON public.site_settings;
DROP POLICY IF EXISTS "Allow All Profiles" ON public.profiles;
DROP POLICY IF EXISTS "Allow All Categories" ON public.categories;
DROP POLICY IF EXISTS "Allow All Products" ON public.products;
DROP POLICY IF EXISTS "Allow All Orders" ON public.orders;
DROP POLICY IF EXISTS "Allow All Topups" ON public.topups;
DROP POLICY IF EXISTS "Allow All Keys" ON public.license_keys;
DROP POLICY IF EXISTS "Allow All Settings" ON public.site_settings;

DROP POLICY IF EXISTS "Profiles select own or admin" ON public.profiles;
DROP POLICY IF EXISTS "Profiles insert own" ON public.profiles;
DROP POLICY IF EXISTS "Profiles update own or admin" ON public.profiles;
DROP POLICY IF EXISTS "Profiles delete admin only" ON public.profiles;

DROP POLICY IF EXISTS "Categories public select" ON public.categories;
DROP POLICY IF EXISTS "Categories admin write" ON public.categories;

DROP POLICY IF EXISTS "Products public select" ON public.products;
DROP POLICY IF EXISTS "Products admin write" ON public.products;

DROP POLICY IF EXISTS "Settings public select" ON public.site_settings;
DROP POLICY IF EXISTS "Settings admin write" ON public.site_settings;

DROP POLICY IF EXISTS "Orders select own or admin" ON public.orders;
DROP POLICY IF EXISTS "Orders insert own pending only" ON public.orders;
DROP POLICY IF EXISTS "Orders update admin only" ON public.orders;
DROP POLICY IF EXISTS "Orders delete admin only" ON public.orders;

DROP POLICY IF EXISTS "Topups select own or admin" ON public.topups;
DROP POLICY IF EXISTS "Topups insert own pending only" ON public.topups;
DROP POLICY IF EXISTS "Topups update admin only" ON public.topups;
DROP POLICY IF EXISTS "Topups delete admin only" ON public.topups;

DROP POLICY IF EXISTS "Keys select redeemed or admin" ON public.license_keys;
DROP POLICY IF EXISTS "Keys admin write" ON public.license_keys;

DROP POLICY IF EXISTS "Slips admin only" ON public.verified_slips;

-- 1. PROFILES POLICIES
-- ผู้ใช้สามารถดูข้อมูลโปรไฟล์ของตัวเองได้ หรือ Admin สามารถดูได้ทุกคน
CREATE POLICY "Profiles select own or admin" ON public.profiles
FOR SELECT USING (auth.uid()::text = id OR public.is_admin());

-- ผู้ใช้สร้างแถวโปรไฟล์ของตัวเองตอนสมัคร (เริ่มต้น balance 0, role user)
CREATE POLICY "Profiles insert own" ON public.profiles
FOR INSERT WITH CHECK (
  (auth.uid()::text = id) AND
  (role = 'user' OR role IS NULL) AND
  (balance = 0 OR balance IS NULL) AND
  (is_premium = false OR is_premium IS NULL)
);

-- ผู้ใช้แก้ไขโปรไฟล์ตัวเอง (ชื่อ, avatar) หรือ Admin แก้ไขได้ทั้งหมด (ห้ามแก้ role/balance/rank/is_premium โดยตรง)
CREATE POLICY "Profiles update own or admin" ON public.profiles
FOR UPDATE USING (auth.uid()::text = id OR public.is_admin())
WITH CHECK (auth.uid()::text = id OR public.is_admin());

-- มีเพียง Admin เท่านั้นที่สามารถลบโปรไฟล์ได้
CREATE POLICY "Profiles delete admin only" ON public.profiles
FOR DELETE USING (public.is_admin());

-- 2. CATEGORIES POLICIES
-- ทุกคนสามารถอ่านหมวดหมู่สินค้าได้
CREATE POLICY "Categories public select" ON public.categories
FOR SELECT USING (true);

-- เฉพาะ Admin เท่านั้นที่สามารถเพิ่ม แก้ไข หรือลบหมวดหมู่สินค้าได้
CREATE POLICY "Categories admin write" ON public.categories
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- 3. PRODUCTS POLICIES
-- ทุกคนสามารถดูรายการสินค้าได้
CREATE POLICY "Products public select" ON public.products
FOR SELECT USING (true);

-- เฉพาะ Admin เท่านั้นที่สามารถเพิ่ม แก้ไข หรือลบสินค้าและสต็อกได้
CREATE POLICY "Products admin write" ON public.products
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- 4. SITE SETTINGS POLICIES
-- ทุกคนสามารถอ่านการตั้งค่าหน้าร้านได้
CREATE POLICY "Settings public select" ON public.site_settings
FOR SELECT USING (true);

-- เฉพาะ Admin เท่านั้นที่สามารถแก้ไขการตั้งค่าหน้าร้านได้
CREATE POLICY "Settings admin write" ON public.site_settings
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- 5. ORDERS POLICIES
-- ผู้ใช้ดูได้เฉพาะออเดอร์ของตัวเอง หรือ Admin ดูได้ทั้งหมด
CREATE POLICY "Orders select own or admin" ON public.orders
FOR SELECT USING (auth.uid()::text = user_id OR public.is_admin());

-- ผู้ใช้สร้างออเดอร์ได้เฉพาะของตนเอง และห้ามกำหนดสถานะเป็น completed/success โดยตรง (ต้องเป็น pending)
CREATE POLICY "Orders insert own pending only" ON public.orders
FOR INSERT WITH CHECK (
  (auth.uid()::text = user_id AND status = 'pending') OR
  public.is_admin()
);

-- เฉพาะ Admin หรือ Backend Service Role เท่านั้นที่เปลี่ยนสถานะออเดอร์ได้
CREATE POLICY "Orders update admin only" ON public.orders
FOR UPDATE USING (public.is_admin()) WITH CHECK (public.is_admin());

-- เฉพาะ Admin เท่านั้นที่สามารถลบออเดอร์ได้
CREATE POLICY "Orders delete admin only" ON public.orders
FOR DELETE USING (public.is_admin());

-- 6. TOPUPS POLICIES
-- ผู้ใช้ดูได้เฉพาะประวัติการเติมเงินของตนเอง หรือ Admin ดูได้ทั้งหมด
CREATE POLICY "Topups select own or admin" ON public.topups
FOR SELECT USING (auth.uid()::text = user_id OR public.is_admin());

-- ผู้ใช้สร้างรายการเติมเงินได้เฉพาะของตนเอง และห้ามกำหนดสถานะเป็น approved/success โดยตรง (ต้องเป็น pending)
CREATE POLICY "Topups insert own pending only" ON public.topups
FOR INSERT WITH CHECK (
  (auth.uid()::text = user_id AND status = 'pending') OR
  public.is_admin()
);

-- เฉพาะ Admin หรือ Backend Service Role เท่านั้นที่อนุมัติการเติมเงินได้
CREATE POLICY "Topups update admin only" ON public.topups
FOR UPDATE USING (public.is_admin()) WITH CHECK (public.is_admin());

-- เฉพาะ Admin เท่านั้นที่สามารถลบประวัติการเติมเงินได้
CREATE POLICY "Topups delete admin only" ON public.topups
FOR DELETE USING (public.is_admin());

-- 7. LICENSE KEYS POLICIES
-- ห้าม Anon หรือ User ทั่วไปมองเห็นคีย์ที่ยังไม่ถูกใช้ (ดูได้เฉพาะคีย์ที่ตัวเองเคย redeem แล้ว หรือเป็น Admin)
CREATE POLICY "Keys select redeemed or admin" ON public.license_keys
FOR SELECT USING (
  (used_by = auth.uid()::text) OR
  public.is_admin()
);

-- มีเพียง Admin เท่านั้นที่สามารถเพิ่ม แก้ไข หรือลบคีย์ได้
CREATE POLICY "Keys admin write" ON public.license_keys
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- 8. VERIFIED SLIPS POLICIES
-- มีเพียง Admin หรือ Service Role เท่านั้นที่เข้าถึงตารางบันทึกสลิปได้
CREATE POLICY "Slips admin only" ON public.verified_slips
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());
`;