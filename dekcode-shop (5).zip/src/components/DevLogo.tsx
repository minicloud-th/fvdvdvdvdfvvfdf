import React, { useState } from 'react';
import { useTheme, DEKCODE_LOGO_DARK_URL, DEKCODE_LOGO_LIGHT_URL } from '../lib/theme';

interface DevLogoProps {
  className?: string;
  height?: number | string;
  width?: number | string;
  variant?: 'svg' | 'image';
  withText?: boolean;
  forcedTheme?: 'dark' | 'light';
}

// Export logo constants with DekCode branding
export { DEKCODE_LOGO_DARK_URL, DEKCODE_LOGO_LIGHT_URL };
export const DEKCODE_LOGO_URL = DEKCODE_LOGO_DARK_URL;
// Legacy compatibility aliases
export const ASTRAX_LOGO_DARK_URL = DEKCODE_LOGO_DARK_URL;
export const ASTRAX_LOGO_LIGHT_URL = DEKCODE_LOGO_LIGHT_URL;
export const ASTRAX_LOGO_URL = DEKCODE_LOGO_DARK_URL;
export const ZENONE_LOGO_URL = DEKCODE_LOGO_DARK_URL;

export const DevLogo: React.FC<DevLogoProps> = ({
  className = "h-9 w-auto",
  height,
  width,
  withText = false,
  forcedTheme,
}) => {
  const { theme } = useTheme();
  const [imgError, setImgError] = useState(false);

  // If forcedTheme is provided, render only that theme's logo
  if (forcedTheme) {
    const src = forcedTheme === 'light' ? DEKCODE_LOGO_LIGHT_URL : DEKCODE_LOGO_DARK_URL;
    return (
      <div className={`flex items-center gap-2.5 select-none ${className}`}>
        {!imgError ? (
          <img
            src={src}
            alt="DekCode Shop Logo"
            className="h-full w-auto object-contain drop-shadow-sm transition-transform duration-200 group-hover:scale-105"
            style={{ height, width }}
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="h-9 px-3.5 rounded-lg bg-gradient-to-r from-sky-500 to-cyan-500 flex items-center justify-center font-black text-white text-sm shadow-md tracking-wider border border-sky-400/30">
            DEKCODE
          </div>
        )}
        {withText && (
          <span className="font-bold text-lg tracking-tight text-label font-sans">
            DekCode <span className="text-sky-500 font-medium">Shop</span>
          </span>
        )}
      </div>
    );
  }

  // Active theme logo URL from theme context
  const activeLogoSrc = theme === 'light' ? DEKCODE_LOGO_LIGHT_URL : DEKCODE_LOGO_DARK_URL;

  return (
    <div className={`flex items-center gap-2 select-none shrink-0 ${className}`}>
      {!imgError ? (
        <div className="relative flex items-center justify-center h-full">
          {/* Dual image rendering with CSS classes for zero-FOUC instant CSS theme switching */}
          <img
            src={DEKCODE_LOGO_DARK_URL}
            alt="DekCode Shop Logo (Dark Mode)"
            className="dekcode-logo-dark astrax-logo-dark h-full w-auto object-contain drop-shadow-sm transition-transform duration-200 group-hover:scale-105"
            style={{ height, width }}
            onError={() => setImgError(true)}
          />
          <img
            src={DEKCODE_LOGO_LIGHT_URL}
            alt="DekCode Shop Logo (Light Mode)"
            className="dekcode-logo-light astrax-logo-light h-full w-auto object-contain drop-shadow-sm transition-transform duration-200 group-hover:scale-105"
            style={{ height, width }}
            onError={() => setImgError(true)}
          />
        </div>
      ) : (
        <div className="h-8 px-3 rounded-lg bg-gradient-to-r from-sky-500 to-cyan-500 flex items-center justify-center font-bold text-white text-xs shadow-md tracking-wider border border-sky-400/30">
          DEKCODE
        </div>
      )}
      {withText && (
        <span className="font-bold text-base tracking-tight text-label font-sans">
          DekCode <span className="text-sky-500 font-medium">Shop</span>
        </span>
      )}
    </div>
  );
};

export const DekCodeLogo = DevLogo;
export const AstraxLogo = DevLogo;
export const ZenoneLogo = DevLogo;
export default DevLogo;
