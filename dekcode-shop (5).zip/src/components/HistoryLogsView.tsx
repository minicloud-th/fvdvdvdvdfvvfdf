import React, { useState } from 'react';
import { History, Key, Activity, ArrowRight, Clock, Monitor, Wallet, ShoppingCart, Copy, Check, Package, Crown, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HistoryLogsViewProps {
  usedKeysHistory?: any[];
  purchaseHistory?: any[];
  topupHistory?: any[];
  hasMorePurchases?: boolean;
  isLoadingMore?: boolean;
  onLoadMorePurchases?: () => void;
}

export const HistoryLogsView: React.FC<HistoryLogsViewProps> = ({ 
  usedKeysHistory = [], 
  purchaseHistory = [], 
  topupHistory = [],
  hasMorePurchases = false,
  isLoadingMore = false,
  onLoadMorePurchases
}) => {
  const [filter, setFilter] = useState<'key_purchase' | 'keys' | 'topup' | 'general_purchase' | 'special_purchase'>('key_purchase');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedItem, setSelectedItem] = useState<{details: any, type: string} | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const keyPurchases = purchaseHistory.filter(p => (p.productName || '').includes('คีย์'));
  const specialPurchases = purchaseHistory.filter(p => !(p.productName || '').includes('คีย์') && (p.price || 0) >= 500);
  const generalPurchases = purchaseHistory.filter(p => !(p.productName || '').includes('คีย์') && (p.price || 0) < 500);

  const StatusBadge = ({ status = 'SUCCESS' }: { status?: string }) => (
    <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${ status === 'SUCCESS' ? 'text-success bg-success/15 border border-success/25' : 'text-label-2 bg-surface-2 border border-separator' }`}>
      {status === 'SUCCESS' ? 'สำเร็จ' : status}
    </span>
  );

  const CopyBox = ({ text, id }: { text: string, id: string }) => (
    <div className="flex items-center justify-between gap-3 bg-surface-2 border border-separator py-2 px-3 w-full max-w-xs rounded-xl">
      <span className="font-sans tabular-nums text-label-2 font-medium text-xs truncate">
        {text}
      </span>
      <button 
        onClick={() => handleCopy(text, id)}
        className="text-label-2 hover:text-label transition-colors shrink-0"
        title="คัดลอก"
      >
        {copiedId === id ? <Check className="w-3.5 h-3.5 text-success"/> : <Copy className="w-3.5 h-3.5"/>}
      </button>
    </div>
  );

  const DetailsModal = () => {
    const [showSecret, setShowSecret] = useState(false);
    if (!selectedItem) return null;
    const { details: item, type } = selectedItem;
    const isPurchase = ['key_purchase', 'general_purchase', 'special_purchase'].includes(type);

    if (isPurchase) {
      return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={() => setSelectedItem(null)}>
          <div className="bg-surface border border-separator w-full max-w-md overflow-hidden relative rounded-3xl shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="p-6 pb-4 relative">
              <button onClick={() => setSelectedItem(null)} className="absolute top-4 right-4 p-2 rounded-full bg-surface-2 text-label-2 hover:text-label transition-colors">
                <X className="w-5 h-5" />
              </button>
              <h3 className="text-xl font-semibold text-label mb-1">รายละเอียดการซื้อ</h3>
              <p className="text-label-2 text-xs font-normal">หมายเลขบิล: <span className="font-sans tabular-nums text-label bg-surface-2 px-2 py-0.5 rounded-md border border-separator">BILL-{item.id?.toUpperCase()}</span></p>
            </div>

            <div className="px-6 space-y-4">
              <div className="bg-surface-2 border border-separator rounded-2xl p-4">
                <div className="flex justify-between items-center mb-2.5">
                  <span className="text-xs text-label-2">วันที่ซื้อ</span>
                  <span className="text-xs font-medium text-label">{new Date(item.timestamp || item.usedAt || item.date).toLocaleString('th-TH')}</span>
                </div>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-xs text-label-2">จำนวนรายการ</span>
                  <span className="text-xs font-medium text-label">1 รายการ</span>
                </div>
                <div className="h-px bg-separator mb-3"></div>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-medium text-label-2">ราคารวม</span>
                  <span className="text-lg font-semibold text-label font-sans tabular-nums">฿{item.price?.toLocaleString() || 0}</span>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-label text-sm mb-3">รายการสินค้า</h4>
                <div className="bg-surface-2 border border-separator p-4 flex flex-col gap-3 rounded-2xl">
                  <div className="flex gap-3 items-center">
                    <div className="w-12 h-12 bg-surface rounded-xl border border-separator flex items-center justify-center shrink-0 text-label-2">
                      <Package className="w-6 h-6 text-link" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="font-semibold text-label text-sm truncate">{item.productName}</h5>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-label-2 font-normal bg-surface px-2 py-0.5 rounded-md border border-separator">จำนวน 1 ชิ้น</span>
                        <span className="text-xs font-semibold text-label font-sans tabular-nums">฿{item.price?.toLocaleString() || 0}</span>
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowSecret(!showSecret)}
                    className="w-full py-2 bg-surface hover:bg-surface-2 border border-separator text-label text-xs font-medium transition-all rounded-xl"
                  >
                    {showSecret ? 'ซ่อนรายละเอียด' : 'ดูรายละเอียด'}
                  </button>
                  {showSecret && item.secretData && (
                    <div className="mt-2 animate-in fade-in duration-200 pt-2 border-t border-separator">
                       <span className="text-xs font-medium text-label-2 mb-2 block">โค้ด / ข้อมูลสินค้า</span>
                       <CopyBox text={item.secretData} id={item.id} />
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="p-6">
              <button 
                onClick={() => setSelectedItem(null)}
                className="w-full py-3 bg-surface-2 hover:bg-surface border border-separator text-label rounded-full text-sm font-medium transition-all"
              >
                ปิด
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={() => setSelectedItem(null)}>
        <div className="bg-surface border border-separator w-full max-w-md overflow-hidden relative rounded-3xl shadow-2xl" onClick={e => e.stopPropagation()}>
          <div className="flex justify-between items-center p-6 border-b border-separator">
            <h3 className="font-semibold text-base text-label">รายละเอียดรายการ</h3>
            <button onClick={() => setSelectedItem(null)} className="p-2 rounded-full bg-surface-2 text-label-2 hover:text-label transition-colors">
              <X className="w-4 h-4"/>
            </button>
          </div>
          <div className="p-6 flex flex-col gap-3">
            <div className="flex justify-between items-center">
              <span className="text-label-2 text-xs">หมายเลขบิล</span>
              <span className="font-sans tabular-nums font-medium text-xs bg-surface-2 px-2 py-0.5 rounded-md text-label border border-separator">BILL-{item.id?.toUpperCase()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-label-2 text-xs">วันที่และเวลา</span>
              <span className="text-xs font-medium text-label">{new Date(item.timestamp || item.usedAt || item.date).toLocaleString('th-TH')}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-label-2 text-xs">สถานะรายการ</span>
              <StatusBadge status="SUCCESS" />
            </div>
            
            <div className="h-px bg-separator my-2 w-full"></div>

            {type === 'topup' && (
              <>
                <div className="flex justify-between items-center">
                  <span className="text-label-2 text-xs">ประเภทรายการ</span>
                  <span className="text-xs font-medium text-label">เติมเงินเข้าระบบ ({item.type || 'ผ่านระบบ'})</span>
                </div>
                <div className="flex justify-between items-center mt-2">
                   <span className="text-label-2 text-xs">จำนวนเงิน</span>
                   <span className="text-base font-semibold text-success font-sans tabular-nums">+{item.amount?.toLocaleString() || 0} ฿</span>
                </div>
              </>
            )}

            {type === 'key_use' && (
              <>
                <div className="flex justify-between items-center">
                  <span className="text-label-2 text-xs">ประเภทรายการ</span>
                  <span className="text-xs font-medium text-label">ใช้งานคีย์ (Redeem)</span>
                </div>
                <div className="flex flex-col gap-2 pt-3 border-t border-separator mt-2">
                   <span className="text-label-2 text-xs">รายละเอียดคีย์</span>
                   <CopyBox text={item.key} id={item.id} />
                </div>
              </>
            )}

          </div>
          <div className="p-4 bg-surface-2 border-t border-separator flex justify-end">
             <button 
               onClick={() => setSelectedItem(null)}
               className="px-6 py-2.5 bg-surface hover:bg-surface-2 border border-separator text-label text-xs font-medium transition-colors w-full rounded-full"
             >
               ปิดหน้าต่าง
             </button>
          </div>
        </div>
      </div>
    );
  };

  const renderCard = (item: any, type: string) => {
    let title = "";
    let amountNode = null;
    let dateStr = new Date(item.timestamp || item.usedAt).toLocaleString('th-TH');
    let displayId = item.id.toUpperCase();

    if (type === 'topup') {
      title = `เติมเงินเข้าระบบ (${item.type || 'ผ่านระบบ'})`;
      amountNode = <span className="font-semibold text-success text-sm sm:text-base font-sans tabular-nums">+{(item.amount || 0).toLocaleString()} ฿</span>;
    } else if (type === 'key_use') {
      title = "ใช้งานคีย์ (Redeem)";
      amountNode = <span className="font-semibold text-label-2 text-sm sm:text-base">-</span>;
      displayId = item.id.substring(0,8).toUpperCase();
    } else {
      title = item.productName;
      amountNode = <span className="font-semibold text-danger text-sm sm:text-base font-sans tabular-nums">-{(item.price || 0).toLocaleString()} ฿</span>;
    }

    return (
      <div key={item.id} className="bg-surface border border-separator p-4 sm:p-5 hover:border-separator/80 rounded-2xl transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 group shadow-sm">
        <div className="flex flex-col gap-1.5 flex-1">
          <div className="flex items-center gap-3">
             <span className="font-semibold text-label text-sm sm:text-base">{title}</span>
             <StatusBadge status="SUCCESS" />
          </div>
          <div className="flex items-center gap-3 text-xs text-label-2 font-normal">
            <span className="font-sans tabular-nums bg-surface-2 px-2 py-0.5 rounded-md border border-separator text-label-2"># BILL-{displayId}</span>
            <span>{dateStr}</span>
          </div>
        </div>
        
        <div className="flex flex-row items-center justify-between md:justify-end gap-4 border-t md:border-t-0 border-separator pt-3 md:pt-0">
          <div className="flex flex-col items-start md:items-end">
            <span className="text-xs text-label-3 mb-0.5 md:hidden">จำนวนเงิน</span>
            {amountNode}
          </div>
          <button 
            onClick={() => setSelectedItem({ details: item, type })}
            className="px-4 py-2 bg-surface-2 hover:bg-surface border border-separator text-label text-xs font-medium transition-all rounded-full cursor-pointer active:scale-95 shadow-sm"
          >
            ดูรายละเอียด
          </button>
        </div>
      </div>
    );
  };

  const renderPurchaseList = (list: any[], type: string, emptyMessage: string) => {
    if (list.length === 0) {
      return (
        <div className="py-16 flex flex-col items-center justify-center text-label-2 border border-dashed border-separator bg-surface rounded-2xl">
          <ShoppingCart className="w-8 h-8 mb-3 text-label-3" />
          <p className="font-normal text-xs">{emptyMessage}</p>
        </div>
      );
    }
    return (
      <div className="flex flex-col gap-3">
        {list.map((item) => renderCard(item, type))}
        {hasMorePurchases && onLoadMorePurchases && (
          <div className="pt-4 flex justify-center">
            <button
              onClick={onLoadMorePurchases}
              disabled={isLoadingMore}
              className="px-5 py-2 rounded-full bg-accent hover:bg-accent-hover text-white text-xs font-medium transition-all disabled:opacity-50 cursor-pointer flex items-center gap-2"
            >
              {isLoadingMore ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>กำลังโหลดข้อมูลเพิ่มเติม...</span>
                </>
              ) : (
                <span>โหลดประวัติเพิ่มเติม</span>
              )}
            </button>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-6 lg:p-8 font-sans text-label pb-20">
      {/* Header */}
      <div className="mb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-separator text-link text-xs font-medium mb-2">
          <History className="w-3.5 h-3.5" />
          <span>Activity Log</span>
        </div>
        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-label tracking-tight">
          ประวัติสั่งซื้อ
        </h1>
        <p className="text-xs sm:text-sm font-normal text-label-2 mt-1">
          ประวัติการทำรายการต่างๆ ของคุณในระบบ
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="overflow-x-auto pb-4 mb-4 scrollbar-none w-full">
        <div className="inline-flex bg-surface-2 p-1 rounded-full border border-separator gap-1">
          {[
            { id: 'key_purchase', label: 'ซื้อสินค้า', icon: ShoppingCart },
            { id: 'topup', label: 'เติมเงิน', icon: Wallet },
            { id: 'general_purchase', label: 'สินค้าทั่วไป', icon: Package },
            { id: 'special_purchase', label: 'สินค้าพิเศษ', icon: Crown }
          ].map(tab => {
            const active = filter === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-full font-medium text-xs transition-all cursor-pointer ${ active ? 'bg-surface text-label shadow-sm border border-separator' : 'text-label-2 hover:text-label' }`}
              >
                <tab.icon className="w-3.5 h-3.5 shrink-0" />
                {tab.label}
              </button>
            )
          })}
        </div>
      </div>

      <div className="mt-2">
        {filter === 'topup' && (
          <div className="flex flex-col gap-4">
            <h2 className="text-base sm:text-lg font-semibold flex items-center gap-2 text-label mb-1">
              <Wallet className="w-4 h-4 text-link" /> ประวัติการเติมเงิน
            </h2>
            {topupHistory.length === 0 ? (
              <div className="py-16 flex flex-col items-center justify-center text-label-2 border border-dashed border-separator bg-surface rounded-2xl">
                <Wallet className="w-8 h-8 mb-3 text-label-3" />
                <p className="font-normal text-xs">ยังไม่มีประวัติการเติมเงิน</p>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {topupHistory.map((item) => renderCard(item, 'topup'))}
              </div>
            )}
          </div>
        )}

        {filter === 'key_purchase' && (
          <div className="flex flex-col gap-4">
            <h2 className="text-base sm:text-lg font-semibold flex items-center gap-2 text-label mb-1">
              <ShoppingCart className="w-4 h-4 text-link" /> ประวัติการซื้อคีย์
            </h2>
            {renderPurchaseList(keyPurchases, 'key_purchase', 'ยังไม่มีประวัติการซื้อคีย์')}
          </div>
        )}

        {filter === 'general_purchase' && (
          <div className="flex flex-col gap-4">
            <h2 className="text-base sm:text-lg font-semibold flex items-center gap-2 text-label mb-1">
              <Package className="w-4 h-4 text-link" /> ประวัติการซื้อสินค้าทั่วไป
            </h2>
            {renderPurchaseList(generalPurchases, 'general_purchase', 'ยังไม่มีประวัติการซื้อสินค้าทั่วไป')}
          </div>
        )}

        {filter === 'special_purchase' && (
          <div className="flex flex-col gap-4">
            <h2 className="text-base sm:text-lg font-semibold flex items-center gap-2 text-label mb-1">
              <Crown className="w-4 h-4 text-warning" /> ประวัติการซื้อสินค้าพิเศษ
            </h2>
            {renderPurchaseList(specialPurchases, 'special_purchase', 'ยังไม่มีประวัติการซื้อสินค้าพิเศษ')}
          </div>
        )}
      </div>

      <DetailsModal />
    </div>
  );
};


