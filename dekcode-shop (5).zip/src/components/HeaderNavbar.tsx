import React, { useState, useEffect, useRef } from "react";
import {
  Search,
  Menu,
  X,
  Wallet,
  ShieldCheck,
  User,
  ShoppingBag,
  CreditCard,
  LogOut,
  ChevronDown,
  LogIn,
  Sun,
  Moon,
} from "lucide-react";
import { useTheme } from "../lib/theme";

interface HeaderNavbarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  user: any;
  userPlan: any;
  isAdmin: boolean;
  onLogout: () => void;
  onOpenSearch: () => void;
  onOpenContact: () => void;
  onOpenSupabaseConfig?: () => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
  isDesktopUserMenuOpen?: boolean;
  setIsDesktopUserMenuOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  isUserMenuOpen?: boolean;
  setIsUserMenuOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  settingsImport?: () => void;
  historyImport?: () => void;
}

export const HeaderNavbar: React.FC<HeaderNavbarProps> = ({
  activeView,
  setActiveView,
  user,
  userPlan,
  isAdmin,
  onLogout,
  onOpenSearch,
  onOpenContact,
  isMobileMenuOpen,
  setIsMobileMenuOpen,
  isDesktopUserMenuOpen,
  setIsDesktopUserMenuOpen,
}) => {
  const { theme, toggleTheme } = useTheme();
  const [internalUserMenuOpen, setInternalUserMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchInputValue, setSearchInputValue] = useState("");
  const userMenuRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const isUserDropdownOpen =
    isDesktopUserMenuOpen !== undefined ? isDesktopUserMenuOpen : internalUserMenuOpen;
  const setUserDropdownOpen = (open: boolean) => {
    if (setIsDesktopUserMenuOpen) {
      setIsDesktopUserMenuOpen(open);
    } else {
      setInternalUserMenuOpen(open);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key === "/" &&
        !["INPUT", "TEXTAREA"].includes((e.target as HTMLElement)?.tagName)
      ) {
        e.preventDefault();
        setSearchOpen(true);
        setTimeout(() => searchInputRef.current?.focus(), 50);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserDropdownOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (isUserDropdownOpen) setUserDropdownOpen(false);
        if (searchOpen) setSearchOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isUserDropdownOpen, searchOpen]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInputValue.trim()) {
      setActiveView("search");
      onOpenSearch();
    }
  };

  const username =
    userPlan?.username || user?.name || user?.email?.split("@")[0] || "ผู้ใช้งาน";
  const userEmail = user?.email || "";
  const initialChar = (username.charAt(0) || "K").toUpperCase();
  const balance =
    userPlan?.balance !== undefined
      ? Math.floor(userPlan.balance)
      : user?.balance !== undefined
      ? Math.floor(user.balance)
      : 0;

  return (
    <nav
      id="site-nav"
      className="sticky top-0 left-0 z-50 w-full border-b border-line bg-bg/95 backdrop-blur-sm select-none"
    >
      <div className="flex h-12 items-stretch justify-between max-w-[1440px] mx-auto">
        {/* Left Side: Brand Logo + Nav Links */}
        <div className="flex min-w-0 items-stretch">
          {/* Brand Logo */}
          <button
            type="button"
            onClick={() => {
              setActiveView("home");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            className="flex items-center border-r border-line px-4 hover:opacity-80 sm:px-5 cursor-pointer transition-opacity"
            aria-label="KODDYKUB หน้าแรก"
          >
            <img
              alt="KODDYKUB"
              className="themed-logo h-6 w-auto"
              src="/assets/artcraft-icon.svg"
            />
            <span className="ml-2 font-mono font-bold tracking-wider text-xs hidden sm:inline-block text-ink-strong">
              KODDYKUB
            </span>
          </button>

          {/* Desktop Navigation */}
          <div className="hidden min-w-0 items-stretch lg:flex">
            <ul className="flex h-full items-stretch" dir="ltr">
              {/* Home */}
              <li className="flex items-stretch">
                <button
                  type="button"
                  onClick={() => {
                    setActiveView("home");
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className={`group flex h-full items-center px-2.5 hud-label whitespace-nowrap cursor-pointer ${
                    activeView === "home" ? "text-ink" : "text-muted hover:text-ink"
                  }`}
                >
                  <span
                    className={`flex items-center gap-1.5 px-1.5 py-0.5 group-hover:bg-invert-bg group-hover:text-invert-fg transition-colors ${
                      activeView === "home" ? "bg-invert-bg text-invert-fg" : ""
                    }`}
                  >
                    หน้าแรก
                  </span>
                </button>
              </li>

              {/* Game Accounts */}
              <li className="flex items-stretch">
                <button
                  type="button"
                  onClick={() => {
                    if (activeView === "home") {
                      document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                    } else {
                      setActiveView("home");
                      setTimeout(() => {
                        document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                      }, 100);
                    }
                  }}
                  className="group flex h-full items-center px-2.5 hud-label whitespace-nowrap text-muted hover:text-ink cursor-pointer"
                >
                  <span className="flex items-center gap-1.5 px-1.5 py-0.5 group-hover:bg-invert-bg group-hover:text-invert-fg transition-colors">
                    ไอดีเกม
                  </span>
                </button>
              </li>

              {/* Source Code */}
              <li className="flex items-stretch">
                <button
                  type="button"
                  onClick={() => {
                    if (activeView === "home") {
                      document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                    } else {
                      setActiveView("home");
                      setTimeout(() => {
                        document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                      }, 100);
                    }
                  }}
                  className="group flex h-full items-center px-2.5 hud-label whitespace-nowrap text-muted hover:text-ink cursor-pointer"
                >
                  <span className="flex items-center gap-1.5 px-1.5 py-0.5 group-hover:bg-invert-bg group-hover:text-invert-fg transition-colors">
                    ซอร์สโค้ด
                  </span>
                </button>
              </li>

              {/* Categories */}
              <li className="flex items-stretch">
                <button
                  type="button"
                  onClick={() => {
                    if (activeView === "home") {
                      document.getElementById("features")?.scrollIntoView({ behavior: "smooth" });
                    } else {
                      setActiveView("categories");
                    }
                  }}
                  className="group flex h-full items-center px-2.5 hud-label whitespace-nowrap text-muted hover:text-ink cursor-pointer"
                >
                  <span className="flex items-center gap-1.5 px-1.5 py-0.5 group-hover:bg-invert-bg group-hover:text-invert-fg transition-colors">
                    หมวดสินค้า
                  </span>
                </button>
              </li>

              {/* How to Order */}
              <li className="flex items-stretch">
                <button
                  type="button"
                  onClick={() => {
                    if (activeView === "home") {
                      document.getElementById("ownership")?.scrollIntoView({ behavior: "smooth" });
                    } else {
                      setActiveView("home");
                      setTimeout(() => {
                        document.getElementById("ownership")?.scrollIntoView({ behavior: "smooth" });
                      }, 100);
                    }
                  }}
                  className="group flex h-full items-center px-2.5 hud-label whitespace-nowrap text-muted hover:text-ink cursor-pointer"
                >
                  <span className="flex items-center gap-1.5 px-1.5 py-0.5 group-hover:bg-invert-bg group-hover:text-invert-fg transition-colors">
                    วิธีสั่งซื้อ
                  </span>
                </button>
              </li>

              {/* Contact Us */}
              <li className="flex items-stretch">
                <button
                  type="button"
                  onClick={onOpenContact}
                  className="group flex h-full items-center px-2.5 hud-label whitespace-nowrap text-muted hover:text-ink cursor-pointer"
                >
                  <span className="flex items-center gap-1.5 px-1.5 py-0.5 group-hover:bg-invert-bg group-hover:text-invert-fg transition-colors">
                    ติดต่อร้าน
                  </span>
                </button>
              </li>

              {/* Admin Dashboard */}
              {isAdmin && (
                <li className="flex items-stretch ml-1.5 border-l border-line pl-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveView("admin");
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="group flex h-full items-center px-2.5 hud-label whitespace-nowrap text-amber-400 hover:text-amber-300 cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5 px-1.5 py-0.5 bg-amber-500/10 border border-amber-500/20 group-hover:bg-amber-500 group-hover:text-black transition-colors font-bold">
                      <ShieldCheck className="w-3 h-3" />
                      ADMIN
                    </span>
                  </button>
                </li>
              )}
            </ul>
          </div>
        </div>

        {/* Right Side: Tools, Search, Discord, Theme & Auth */}
        <div className="flex shrink-0 items-stretch">
          {/* Search Trigger */}
          <button
            type="button"
            onClick={() => {
              setSearchOpen(!searchOpen);
              if (!searchOpen) {
                setTimeout(() => searchInputRef.current?.focus(), 50);
              }
            }}
            className="flex w-10 sm:w-11 items-center justify-center border-l border-line text-muted hover:bg-invert-bg hover:text-invert-fg transition-colors cursor-pointer"
            aria-label="ค้นหา (กด /)"
            title="ค้นหา (กด /)"
          >
            <Search className="w-3.5 h-3.5" />
          </button>

          {/* Discord Community Link */}
          <a
            aria-label="Discord KODDYKUB"
            className="hidden sm:flex w-11 items-center justify-center border-l border-line text-muted hover:bg-invert-bg hover:text-invert-fg transition-colors"
            href="https://discord.gg/artcraft"
            rel="noopener noreferrer"
            target="_blank"
            title="Discord ชุมชน"
          >
            <svg aria-hidden="true" className="h-3.5 w-3.5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0-.372-.292.074.074 0 0 1-.077-.01c3.929-1.205 5.485-3.082 5.485-3.082a.077.077 0 0 0-.012-.137 19.294 19.294 0 0 0-3.805-1.296.075.075 0 0 0-.08.036c-.167.301-.35.68-.48 1.01a17.487 17.487 0 0 0-5.18 0 12.06 12.06 0 0 0-.49-1.01.076.076 0 0 0-.08-.036 19.345 19.345 0 0 0-3.805 1.296.077.077 0 0 0-.012.137s1.536 1.848 5.426 3.067a.075.075 0 0 1-.077.011 10.334 10.334 0 0 0-.372.292.077.077 0 0 1-.008.128 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
            </svg>
          </a>

          {/* Theme Toggle Button */}
          <button
            type="button"
            onClick={toggleTheme}
            className="flex w-10 sm:w-11 items-center justify-center border-l border-line text-muted hover:bg-invert-bg hover:text-invert-fg transition-colors cursor-pointer"
            aria-label="สลับธีม"
            title="สลับโหมดมืด/สว่าง"
          >
            {theme === "dark" ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          </button>

          {/* User Wallet / Balance if logged in */}
          {user && (
            <button
              type="button"
              onClick={() => setActiveView("wallet")}
              className="hidden sm:flex items-center gap-1.5 border-l border-line px-3 text-xs font-mono text-emerald-400 hover:bg-invert-bg transition-colors cursor-pointer"
              title="กระเป๋าเงินของคุณ"
            >
              <CreditCard className="w-3 h-3 text-emerald-400" />
              <span className="font-bold">{balance.toLocaleString()}</span>
              <span className="text-[10px] text-muted">฿</span>
            </button>
          )}

          {/* User Dropdown or Login Button */}
          {user ? (
            <div className="relative border-l border-line" ref={userMenuRef}>
              <button
                type="button"
                onClick={() => setUserDropdownOpen(!isUserDropdownOpen)}
                className="flex h-full items-center gap-2 px-3 sm:px-4 text-xs font-mono text-ink hover:bg-invert-bg hover:text-invert-fg transition-colors cursor-pointer"
              >
                <div className="w-6 h-6 rounded bg-neutral-800 border border-line flex items-center justify-center font-bold text-[11px] text-white">
                  {initialChar}
                </div>
                <span className="hidden md:inline-block max-w-[90px] truncate">{username}</span>
                <ChevronDown className="w-3 h-3 text-muted" />
              </button>

              {/* Dropdown Menu */}
              {isUserDropdownOpen && (
                <div className="absolute right-0 top-full mt-px w-52 bg-bg border border-line shadow-2xl py-1.5 z-50 text-xs font-mono">
                  <div className="px-4 py-2 border-b border-line mb-1">
                    <p className="font-bold text-ink-strong truncate">{username}</p>
                    <p className="text-[10px] text-muted truncate">{userEmail}</p>
                    <p className="text-[10px] text-emerald-400 mt-1 font-bold">
                      ยอดเงิน: {balance.toLocaleString()} ฿
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveView("profile");
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-invert-bg hover:text-invert-fg flex items-center gap-2 text-muted"
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>ข้อมูลส่วนตัว</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveView("history");
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-invert-bg hover:text-invert-fg flex items-center gap-2 text-muted"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>ประวัติการสั่งซื้อ</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveView("wallet");
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-invert-bg hover:text-invert-fg flex items-center gap-2 text-muted"
                  >
                    <Wallet className="w-3.5 h-3.5" />
                    <span>เติมเงิน / วอลเล็ท</span>
                  </button>
                  <div className="border-t border-line my-1" />
                  <button
                    type="button"
                    onClick={() => {
                      onLogout();
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 text-red-400 hover:bg-red-500/10 flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>ออกจากระบบ</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setActiveView("auth")}
              className="flex items-center gap-2 border-l border-line px-3.5 sm:px-5 hud-label text-xs font-bold uppercase tracking-wider bg-invert-bg text-invert-fg hover:opacity-85 transition-opacity cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>เข้าสู่ระบบ</span>
            </button>
          )}

          {/* Mobile Menu Toggle Button */}
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="flex w-11 items-center justify-center border-l border-line text-muted hover:bg-invert-bg hover:text-invert-fg transition-colors lg:hidden cursor-pointer"
            aria-label="เปิดเมนูมือถือ"
          >
            {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Search Input Bar (Dropdown) */}
      {searchOpen && (
        <div className="border-t border-line bg-bg px-4 py-2.5 transition-all">
          <form onSubmit={handleSearchSubmit} className="max-w-[1280px] mx-auto flex items-center gap-3">
            <Search className="w-4 h-4 text-muted" />
            <input
              ref={searchInputRef}
              type="text"
              placeholder="ค้นหาไอดีเกม, ซอร์สโค้ด, สคริปต์ (กด Enter เพื่อค้นหา)..."
              value={searchInputValue}
              onChange={(e) => setSearchInputValue(e.target.value)}
              className="w-full bg-transparent text-xs sm:text-sm text-ink placeholder-muted focus:outline-none font-mono"
            />
            <button
              type="button"
              onClick={() => setSearchOpen(false)}
              className="text-xs font-mono text-muted hover:text-ink px-2 py-1"
            >
              ESC ปิด
            </button>
          </form>
        </div>
      )}

    </nav>
  );
};
