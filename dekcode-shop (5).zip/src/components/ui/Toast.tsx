import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X, ShoppingBag } from 'lucide-react';
import { useToastStore, Toast as ToastType } from '../../lib/toastStore';

const Toast: React.FC<{ toast: ToastType; onClose: (id: string) => void }> = ({ toast, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose(toast.id);
    }, toast.duration || 4000);
    return () => clearTimeout(timer);
  }, [toast, onClose]);

  const icons = {
    success: <CheckCircle2 className="w-4 h-4 text-success" />,
    error: <AlertCircle className="w-4 h-4 text-danger" />,
    warning: <AlertTriangle className="w-4 h-4 text-warning" />,
    info: <Info className="w-4 h-4 text-link" />,
    payment: <ShoppingBag className="w-4 h-4 text-link" />
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -10, scale: 0.95 }}
      transition={{ duration: 0.2 }}
      className="relative flex items-center min-w-[280px] max-w-sm gap-3.5 p-3.5 pr-9 rounded-2xl bg-surface/95 backdrop-blur-2xl border border-separator shadow-2xl text-label select-none"
    >
      <div className="shrink-0">
        {icons[toast.type]}
      </div>
      <div className="flex flex-col flex-1 min-w-0">
        {toast.title && <span className="text-xs font-semibold text-label leading-snug">{toast.title}</span>}
        <p className="text-label-2 text-xs font-normal leading-relaxed">{toast.message}</p>
      </div>
      <button 
        onClick={() => onClose(toast.id)}
        className="absolute right-3 top-3.5 text-label-3 hover:text-label transition-colors cursor-pointer"
        aria-label="ปิดการแจ้งเตือน"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </motion.div>
  );
};

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useToastStore();

  return (
    <div className="fixed top-6 right-6 z-[200] flex flex-col gap-3 pointer-events-none">
      <div className="flex flex-col gap-3 pointer-events-auto">
        <AnimatePresence mode="popLayout">
          {toasts.map((toast) => (
            <Toast key={toast.id} toast={toast} onClose={removeToast} />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};
