import React, { useState } from 'react';
import { ImageIcon } from 'lucide-react';

interface ImageWithFallbackProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackSrc?: string;
  fallbackIcon?: React.ReactNode;
}

export const ImageWithFallback: React.FC<ImageWithFallbackProps> = ({
  src,
  alt,
  fallbackSrc,
  fallbackIcon,
  className = '',
  loading = 'lazy',
  ...props
}) => {
  const [error, setError] = useState(false);
  const [loaded, setLoaded] = useState(false);

  if (error || !src) {
    if (fallbackIcon) {
      return (
        <div className={`flex items-center justify-center bg-surface-2 border border-separator text-label-3 ${className}`}>
          {fallbackIcon}
        </div>
      );
    }
    if (fallbackSrc) {
      return (
        <img
          src={fallbackSrc}
          alt={alt || 'Fallback image'}
          className={className}
          loading={loading}
          {...props}
        />
      );
    }
    return (
      <div className={`flex flex-col items-center justify-center bg-surface-2 border border-separator text-label-3 p-2 text-center ${className}`}>
        <ImageIcon className="w-6 h-6 opacity-40 mb-1" />
        <span className="text-13 font-medium opacity-60">DEKCODE</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt || ''}
      className={`${className} ${!loaded ? 'opacity-80' : 'opacity-100'} transition-opacity duration-300`}
      loading={loading}
      onLoad={() => setLoaded(true)}
      onError={() => setError(true)}
      {...props}
    />
  );
};

export default ImageWithFallback;
