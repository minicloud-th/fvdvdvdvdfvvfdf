import React, { useEffect, useState } from 'react';
import { Product } from '../types';
import { ArrowLeft, CheckCircle2, Minus, PackageX, Plus, ShoppingCart, ShieldCheck, Zap } from 'lucide-react';
import Swal from 'sweetalert2';
import { escapeHtml, formatBaht } from '../lib/security';

const MAX_QTY = 50;

interface ProductDetailViewProps {
  product?: Product;
  user: any;
  /** Current wallet balance, used to confirm the purchase before it happens */
  balance?: number;
  onBack: () => void;
  handlePurchase: (product: Product, quantity: number) => Promise<void>;
  setActiveView: (view: any) => void;
}

export const ProductDetailView: React.FC<ProductDetailViewProps> = ({
  product,
  user,
  balance,
  onBack,
  handlePurchase,
  setActiveView,
}) => {
  const [purchaseQuantity, setPurchaseQuantity] = useState(1);
  const [isPurchasing, setIsPurchasing] = useState(false);

  const maxQty = Math.max(1, Math.min(MAX_QTY, product?.stock || 1));

  // Keep quantity valid when stock changes (e.g. after a refresh or another buyer)
  useEffect(() => {
    setPurchaseQuantity((q) => Math.min(Math.max(1, q), maxQty));
  }, [maxQty]);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [product?.id]);

  // Deep link to a product that doesn't exist (or was removed)
  if (!product) {
    return (
      <div className="w-full max-w-lg mx-auto px-6 py-24 text-center">
        <div className="mx-auto mb-6 w-16 h-16 rounded-full bg-surface-2 flex items-center justify-center">
          <PackageX className="w-8 h-8 text-label-3" aria-hidden="true" />
        </div>
        <h1 className="text-xl font-semibold text-label mb-2">ไม่พบสินค้านี้</h1>
        <p className="text-sm text-label-2 mb-8">สินค้าอาจถูกนำออกจากร้าน หรือลิงก์ไม่ถูกต้อง</p>
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-6 h-11 rounded-full bg-accent hover:bg-accent-hover text-white text-sm font-medium transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          กลับไปเลือกสินค้า
        </button>
      </div>
    );
  }

  const discount =
    product.originalPrice && product.price && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null;
  const isAvailable = (product.stock || 0) > 0;
  const totalPrice = Math.round((product.price || 0) * purchaseQuantity * 100) / 100;
  const lowStock = isAvailable && product.stock <= 5;

  const goLogin = () =>
    Swal.fire({
      icon: 'info',
      title: 'เข้าสู่ระบบก่อนสั่งซื้อ',
      text: 'ประวัติและคีย์สินค้าของคุณจะถูกเก็บไว้ในบัญชีเพื่อเรียกดูย้อนหลังได้',
      showCancelButton: true,
      confirmButtonText: 'เข้าสู่ระบบ',
      cancelButtonText: 'ไว้ทีหลัง',
      confirmButtonColor: '#0071E3',
      background: '#161618',
      color: '#fff',
    }).then((res) => {
      if (res.isConfirmed) setActiveView('login');
    });

  const onConfirmBuy = async () => {
    if (!user) return goLogin();

    // Confirm BEFORE money moves: show exactly what will be charged
    const known = typeof balance === 'number';
    if (known && balance! < totalPrice) {
      const res = await Swal.fire({
        icon: 'warning',
        title: 'ยอดเงินไม่พอ',
        html: `ต้องการ <b>${escapeHtml(formatBaht(totalPrice))}</b> แต่มี <b>${escapeHtml(formatBaht(balance))}</b><br/>ขาดอีก <b>${escapeHtml(formatBaht(totalPrice - balance!))}</b>`,
        showCancelButton: true,
        confirmButtonText: 'เติมเงิน',
        cancelButtonText: 'ปิด',
        confirmButtonColor: '#0071E3',
        background: '#161618',
        color: '#fff',
      });
      if (res.isConfirmed) setActiveView('wallet');
      return;
    }

    const confirm = await Swal.fire({
      title: 'ยืนยันการสั่งซื้อ',
      html: `<div style="text-align:left;line-height:1.7">
        <div><b>${escapeHtml(product.name)}</b> × ${purchaseQuantity}</div>
        <div>ยอดชำระ: <b>${escapeHtml(formatBaht(totalPrice))}</b></div>
        ${known ? `<div>คงเหลือหลังซื้อ: <b>${escapeHtml(formatBaht(balance! - totalPrice))}</b></div>` : ''}
      </div>`,
      showCancelButton: true,
      confirmButtonText: 'ยืนยันและชำระเงิน',
      cancelButtonText: 'ยกเลิก',
      confirmButtonColor: '#0071E3',
      focusCancel: true,
      background: '#161618',
      color: '#fff',
    });
    if (!confirm.isConfirmed) return;

    setIsPurchasing(true);
    try {
      await handlePurchase(product, purchaseQuantity);
    } finally {
      setIsPurchasing(false);
    }
  };

  const stepBtn =
    'w-11 h-11 flex items-center justify-center rounded-full bg-surface hover:bg-surface-2 text-label transition-colors cursor-pointer active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed';

  return (
    <div className="w-full max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 font-sans text-label">
      <nav aria-label="เส้นทางหน้า" className="flex items-center gap-2 mb-6 text-sm">
        <button
          type="button"
          onClick={onBack}
          aria-label="ย้อนกลับ"
          className="w-10 h-10 rounded-full bg-surface-2 hover:bg-surface flex items-center justify-center text-label-2 hover:text-label transition-all cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
        </button>
        <span className="text-label-3" aria-hidden="true">/</span>
        <button type="button" onClick={onBack} className="text-label-2 hover:text-label transition-colors cursor-pointer">
          ร้านค้า
        </button>
        <span className="text-label-3" aria-hidden="true">/</span>
        <span aria-current="page" className="text-label font-medium truncate max-w-[200px] sm:max-w-md">
          {product.name}
        </span>
      </nav>

      <div className="rounded-3xl border border-separator bg-surface overflow-hidden flex flex-col md:flex-row shadow-2xl">
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex items-center justify-center bg-bg border-b md:border-b-0 md:border-r border-separator">
          <div className="w-full aspect-square relative rounded-2xl overflow-hidden bg-surface-2 border border-separator p-4 flex items-center justify-center">
            {product.imageUrl ? (
              <img
                src={product.imageUrl}
                alt={product.name}
                width={600}
                height={600}
                decoding="async"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            ) : (
              <div className="text-label-3 font-semibold text-sm">DEKCODE</div>
            )}
            {discount && (
              <span className="absolute top-3 left-3 bg-danger text-white font-semibold px-2.5 py-0.5 rounded-full text-xs">
                ลด {discount}%
              </span>
            )}
          </div>
        </div>

        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between gap-6">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${
                  isAvailable ? 'bg-success/15 text-success border border-success/25' : 'bg-surface-2 text-label-2'
                }`}
              >
                <CheckCircle2 className="w-3 h-3" aria-hidden="true" />
                {isAvailable ? (lowStock ? `เหลือ ${product.stock} ชิ้นสุดท้าย` : `มีสินค้า ${product.stock.toLocaleString()} ชิ้น`) : 'สินค้าหมด'}
              </span>
              {product.tag && (
                <span className="px-3 py-1 rounded-full text-xs font-medium bg-surface-2 text-label-2 border border-separator">
                  {product.tag}
                </span>
              )}
            </div>

            <h1 className="text-xl sm:text-2xl font-semibold text-label tracking-tight leading-snug">{product.name}</h1>

            <div className="flex items-baseline gap-2.5">
              <span className="text-3xl font-semibold text-label tabular-nums tracking-tight">{formatBaht(product.price)}</span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-sm text-label-2 line-through tabular-nums">
                  <span className="sr-only">ราคาเดิม </span>
                  {formatBaht(product.originalPrice)}
                </span>
              )}
            </div>

            <p className="pt-3 text-label-2 text-sm leading-relaxed border-t border-separator max-w-prose whitespace-pre-line">
              {product.description || 'สินค้าคุณภาพ ส่งมอบทันทีผ่านระบบอัตโนมัติ'}
            </p>

            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 text-xs text-label-2">
              <li className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-link shrink-0" aria-hidden="true" />
                ได้รับสินค้าทันทีหลังชำระเงิน
              </li>
              <li className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-success shrink-0" aria-hidden="true" />
                มีทีมดูแลหากใช้งานไม่ได้
              </li>
            </ul>
          </div>

          <div className="space-y-4 pt-4 border-t border-separator">
            {isAvailable && (
              <div className="flex items-center justify-between">
                <span id="qty-label" className="text-sm font-medium text-label-2">จำนวน</span>
                <div role="group" aria-labelledby="qty-label" className="flex items-center gap-1 bg-surface-2 border border-separator rounded-full p-0.5">
                  <button
                    type="button"
                    aria-label="ลดจำนวน"
                    disabled={purchaseQuantity <= 1}
                    onClick={() => setPurchaseQuantity((q) => Math.max(1, q - 1))}
                    className={stepBtn}
                  >
                    <Minus className="w-4 h-4" aria-hidden="true" />
                  </button>
                  <output aria-live="polite" className="w-8 text-center text-sm font-semibold text-label tabular-nums">
                    {purchaseQuantity}
                  </output>
                  <button
                    type="button"
                    aria-label="เพิ่มจำนวน"
                    disabled={purchaseQuantity >= maxQty}
                    onClick={() => setPurchaseQuantity((q) => Math.min(maxQty, q + 1))}
                    className={stepBtn}
                  >
                    <Plus className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={onConfirmBuy}
              disabled={!isAvailable || isPurchasing}
              aria-busy={isPurchasing}
              className={`w-full h-12 px-5 rounded-full text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                isAvailable ? 'bg-accent hover:bg-accent-hover text-white disabled:opacity-70' : 'bg-surface-2 text-label-3 cursor-not-allowed'
              }`}
            >
              {isPurchasing ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" aria-hidden="true" />
                  <span>กำลังดำเนินการ…</span>
                </>
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4" aria-hidden="true" />
                  <span>{isAvailable ? `ซื้อเลย · ${formatBaht(totalPrice)}` : 'สินค้าหมดชั่วคราว'}</span>
                </>
              )}
            </button>
            {!user && isAvailable && (
              <p className="text-xs text-label-2 text-center">เข้าสู่ระบบเพื่อชำระเงินด้วยยอดคงเหลือในบัญชี</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailView;