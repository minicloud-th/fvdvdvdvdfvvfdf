import React, { useState, useMemo, useRef, useEffect } from "react";
import { Product, SiteStats, Category } from "../types";
import { ProductCard } from "./ProductCard";
import { TiltedGridHero, type TiltedGridImage, type TiltedGridVideo } from "./ui/tilted-grid-hero";
import {
  Search,
  Users,
  ShoppingBag,
  Sparkles,
  Gamepad2,
  Code2,
  Bot,
  ShieldCheck,
  Zap,
  ArrowRight,
  X,
  QrCode,
  Package,
} from "lucide-react";

interface HomeViewProps {
  products: Product[];
  categories: Category[];
  stats: SiteStats;
  user?: any;
  siteSettings?: any;
  purchaseHistory?: any[];
  isLoading?: boolean;
  setActiveView: (view: any) => void;
  onProductClick: (id: string) => void;
  onSelectCategory?: (categoryId: string) => void;
}

const fallbackImages: TiltedGridImage[] = [
  { src: "/assets/game-world-fantasy.jpg", alt: "Fantasy Game World" },
  { src: "/assets/game-world-action.jpg", alt: "Action Game World" },
  { src: "/assets/game-world-arena.jpg", alt: "Arena Battle World" },
  { src: "/assets/game-world-battle.jpg", alt: "RPG Adventure World" },
  { src: "/assets/game-world-voxel.jpg", alt: "Sandbox Voxel World" },
];

export const HomeView: React.FC<HomeViewProps> = ({
  products = [],
  stats,
  setActiveView,
  onProductClick,
  onSelectCategory,
}) => {
  const [selectedTab, setSelectedTab] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showHowToModal, setShowHowToModal] = useState<boolean>(false);
  const [heroVideos, setHeroVideos] = useState<TiltedGridVideo[]>([]);
  const [activeSection, setActiveSection] = useState<string>("hero");
  const [scrollProgress, setScrollProgress] = useState<number>(0);

  // Fetch local game video clips manifest
  useEffect(() => {
    let active = true;
    fetch("/assets/game-videos.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then((data) => {
        if (active && Array.isArray(data?.videos)) {
          setHeroVideos(data.videos);
        }
      })
      .catch(() => {
        if (active) {
          setHeroVideos([
            { src: "/assets/game-videos/magic-room.mp4", title: "Magic Room" },
            { src: "/assets/game-videos/alien-planet.mp4", title: "Alien Planet" },
            { src: "/assets/game-videos/light-waves-fantasy.mp4", title: "Fantasy Lights" },
            { src: "/assets/game-videos/warrior-sword.mp4", title: "Warrior Sword" },
            { src: "/assets/game-videos/mushroom-glow.mp4", title: "Glowing Mushroom" },
          ]);
        }
      });
    return () => {
      active = false;
    };
  }, []);

  // Track active section and scroll progress for right-side HUD navigation
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = docHeight > 0 ? Math.min(1, Math.max(0, scrollY / docHeight)) : 0;
      setScrollProgress(progress);

      const sectionIds = ["hero", "features", "ownership", "made-with", "start"];
      const threshold = window.innerHeight * 0.45;
      let current = "hero";

      for (const id of sectionIds) {
        const el = document.getElementById(id);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= threshold) {
            current = id;
          }
        }
      }
      setActiveSection(current);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const filterTabs = [
    { id: "all", label: "ทั้งหมด", icon: Sparkles },
    { id: "game_accounts", label: "ไอดีเกม", icon: Gamepad2 },
    { id: "source_code", label: "ซอร์สโค้ด", icon: Code2 },
    { id: "scripts", label: "บอท & สคริปต์", icon: Bot },
  ];

  // Clean filtered products
  const filteredProducts = useMemo(() => {
    let list = products;

    if (selectedTab === "game_accounts") {
      list = list.filter(
        (p) =>
          p.category === "game_accounts" ||
          p.productType === "game_account" ||
          p.name.toLowerCase().includes("valorant") ||
          p.name.toLowerCase().includes("roblox") ||
          p.name.toLowerCase().includes("steam") ||
          p.name.toLowerCase().includes("genshin") ||
          p.name.toLowerCase().includes("wuthering")
      );
    } else if (selectedTab === "source_code") {
      list = list.filter(
        (p) =>
          p.category === "source_code" ||
          p.productType === "source_code" ||
          p.name.toLowerCase().includes("code") ||
          p.name.toLowerCase().includes("react") ||
          p.name.toLowerCase().includes("next.js") ||
          p.name.toLowerCase().includes("website")
      );
    } else if (selectedTab === "scripts") {
      list = list.filter(
        (p) =>
          p.category === "game_scripts" ||
          p.category === "automation_bots" ||
          p.name.toLowerCase().includes("bot") ||
          p.name.toLowerCase().includes("script") ||
          p.name.toLowerCase().includes("fivem") ||
          p.name.toLowerCase().includes("discord")
      );
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.description && p.description.toLowerCase().includes(q))
      );
    }

    return list;
  }, [products, selectedTab, searchQuery]);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="relative w-full min-h-screen bg-bg text-ink select-none overflow-x-hidden">
      {/* ──────────────────────────────────────────────────────────
          RIGHT-SIDE FLOATING SCROLL NAVIGATION (KODDYKUB HUD)
          ────────────────────────────────────────────────────────── */}
      <aside aria-label="Page sections" className="scroll-navigation hidden xl:block">
        <div className={`section-queue ${activeSection === "hero" ? "at-home" : ""}`}>
          <a
            data-section="hero"
            href="#hero"
            onClick={(e) => {
              e.preventDefault();
              scrollTo("hero");
            }}
            className={activeSection === "hero" ? "active" : ""}
          >
            KODDYKUB
          </a>
          <a
            data-section="features"
            href="#features"
            onClick={(e) => {
              e.preventDefault();
              scrollTo("features");
            }}
            className={activeSection === "features" ? "active" : ""}
          >
            หมวดสินค้า
          </a>
          <a
            data-section="ownership"
            href="#ownership"
            onClick={(e) => {
              e.preventDefault();
              scrollTo("ownership");
            }}
            className={activeSection === "ownership" ? "active" : ""}
          >
            วิธีสั่งซื้อ
          </a>
          <a
            data-section="made-with"
            href="#made-with"
            onClick={(e) => {
              e.preventDefault();
              scrollTo("made-with");
            }}
            className={activeSection === "made-with" ? "active" : ""}
          >
            สถิติระบบ
          </a>
          <a
            data-section="start"
            href="#start"
            onClick={(e) => {
              e.preventDefault();
              scrollTo("start");
            }}
            className={activeSection === "start" ? "active" : ""}
          >
            เลือกสินค้า
          </a>
        </div>
        <div className="scroll-progress" role="progressbar" aria-label="ความคืบหน้าการเลื่อน">
          <span
            className="scroll-progress__fill"
            style={{ transform: `scaleY(${scrollProgress})` }}
          />
        </div>
      </aside>

      {/* ──────────────────────────────────────────────────────────
          1. KODDYKUB HERO SECTION (Hero V2 with 3D Tilted Grid & Orbits)
          ────────────────────────────────────────────────────────── */}
      <section className="hero-v2" id="hero">
        {/* Tilted Grid 3D Background Band */}
        <div id="tilted-grid-hero-root" className="tilted-grid-hero-root" aria-hidden="true">
          <TiltedGridHero
            images={fallbackImages}
            videos={heroVideos}
            speed={4.5}
            tileHeight={27}
            aspectRatio={16 / 9}
            gap={6}
            axis={55}
            curve={78}
            fade={14}
            className="tgh-fill"
          />
        </div>

        {/* Ambient Orbiting Rings */}
        <div className="hero-v2__scene" aria-hidden="true">
          <div className="hero-v2__glow" />
          <div className="hero-v2__orbit hero-v2__orbit--blue" />
          <div className="hero-v2__orbit hero-v2__orbit--green" />
          <div className="hero-v2__orbit hero-v2__orbit--violet" />
          <div className="hero-v2__orbit hero-v2__orbit--red" />
        </div>

        {/* Technical Blueprint Linework */}
        <svg
          className="hero-v2__linework"
          viewBox="0 0 1440 900"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <line x1="80" y1="120" x2="1360" y2="120" className="hero-v2__wire hero-v2__wire--neutral" />
          <line x1="220" y1="0" x2="220" y2="900" className="hero-v2__wire hero-v2__wire--neutral" />
          <line x1="1220" y1="0" x2="1220" y2="900" className="hero-v2__wire hero-v2__wire--neutral" />
          <circle cx="220" cy="120" r="3" className="hero-v2__node hero-v2__node--blue" />
          <circle cx="1220" cy="120" r="3" className="hero-v2__node hero-v2__node--green" />
        </svg>

        {/* Hero Content */}
        <div className="hero-v2__content">
          <div className="hero-v2__wordmark" aria-label="KODDYKUB" role="img">
            <span className="hero-v2__a">
              <img
                src="/assets/artcraft-icon.svg"
                alt=""
                className="inline-block h-[0.7em] w-auto mr-3 align-baseline"
              />
            </span>
            <span className="hero-v2__letters font-mono tracking-tight font-extrabold text-white">
              KODDYKUB
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white mt-8 leading-tight">
            ไอดีเกม{" "}
            <em className="font-serif italic font-normal text-[#a3a3a3]">
              และซอร์สโค้ด
            </em>
          </h1>

          <p className="mt-5 max-w-lg text-sm sm:text-base text-neutral-400 leading-relaxed font-sans">
            ร้านสินค้าดิจิทัลสำหรับเกมเมอร์และนักพัฒนา เลือกไอดีเกมหรือซอร์สโค้ด
            พร้อมตรวจรายละเอียดก่อนตัดสินใจ
          </p>

          <div className="hero-v2__actions mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => scrollTo("start")}
              className="hero-v2__button hero-v2__button--solid cursor-pointer font-bold px-7 h-12 rounded-none tracking-wider uppercase text-xs transition-all"
            >
              ดูสินค้า
            </button>
            <button
              type="button"
              onClick={() => setShowHowToModal(true)}
              className="hero-v2__button cursor-pointer font-bold px-7 h-12 rounded-none tracking-wider uppercase text-xs border border-line bg-bg text-ink hover:border-transparent transition-all"
            >
              วิธีสั่งซื้อ
            </button>
          </div>

          <div className="hero-v2__meta mt-8 flex flex-wrap items-center justify-center gap-4 text-[10px] font-mono uppercase tracking-widest text-neutral-400">
            <span className="hover:text-white cursor-pointer" onClick={() => scrollTo("start")}>
              สินค้าดิจิทัล
            </span>
            <span>·</span>
            <span className="hover:text-white cursor-pointer" onClick={() => scrollTo("start")}>
              ไอดีเกม · ซอร์สโค้ด
            </span>
            <span>·</span>
            <span>ตรวจรายละเอียดก่อนซื้อ</span>
          </div>
        </div>
      </section>

      {/* ──────────────────────────────────────────────────────────
          2. SECTION 01: หมวดสินค้า (#features)
          ────────────────────────────────────────────────────────── */}
      <section className="relative" data-choreo="true" id="features">
        <span
          aria-hidden="true"
          className="absolute inset-x-0 top-0 h-px origin-left bg-line"
          data-draw-rule="true"
        />
        <div className="relative mx-auto max-w-[1280px] border-x border-line">
          <span
            aria-hidden="true"
            className="tick tick-half z-[31] -top-[5px] -left-[6px]"
            data-draw-tick="true"
          />
          <span
            aria-hidden="true"
            className="tick tick-half z-[31] -top-[5px] -right-[5px]"
            data-draw-tick="true"
          />

          {/* Sticky Eyebrow */}
          <div
            className="sticky top-12 z-30 border-y border-line bg-bg/90 backdrop-blur-md"
            data-draw-eyebrow="true"
          >
            <div className="flex items-center justify-between gap-4 px-6 py-3 md:px-10">
              <p className="hud-label text-muted">
                <span className="text-faint">01</span>
                <span aria-hidden="true" className="mx-2 text-faint">
                  /
                </span>
                หมวดสินค้า
              </p>
              <p className="hud-label hidden text-faint sm:block">
                สำหรับเกมเมอร์และนักพัฒนา
              </p>
            </div>
          </div>

          {/* Section Heading */}
          <div className="px-6 py-14 md:px-10 md:py-20">
            <h2
              className="max-w-3xl font-display text-4xl font-medium leading-[1.02] tracking-[-0.035em] text-ink-strong sm:text-5xl md:text-6xl"
              data-reveal="true"
            >
              เลือกสินค้าดิจิทัล{" "}
              <span className="font-serif italic font-normal text-muted">
                ที่ใช่
              </span>{" "}
              สำหรับคุณ
            </h2>
            <p
              className="mt-5 max-w-xl text-lg leading-relaxed text-muted"
              data-reveal="true"
            >
              เลือกดูไอดีเกมและซอร์สโค้ด อ่านรายละเอียดและเงื่อนไขของแต่ละรายการก่อนสั่งซื้อ
            </p>
          </div>

          {/* 4 Cards Grid */}
          <div className="grid gap-px border-t border-line bg-line md:grid-cols-2" data-reveal-group="true">
            {/* Card 1: Game Accounts */}
            <article className="bg-bg" data-reveal="true">
              <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-2.5 md:px-8">
                <p className="hud-label text-muted">ไอดีเกม</p>
                <p className="hud-label text-faint">01</p>
              </div>
              <div className="relative aspect-video w-full overflow-hidden bg-bg-sunken">
                <video
                  aria-label="ไอดีเกมพร้อมเล่น"
                  className="absolute inset-0 h-full w-full object-cover"
                  loop
                  muted
                  playsInline
                  autoPlay
                  poster="/assets/WorldLabs_Demo_2.jpg"
                  preload="metadata"
                  src="/assets/WorldLabs_Demo_2.webm"
                />
              </div>
              <div className="px-6 py-6 md:px-8">
                <h3 className="font-display text-2xl font-medium tracking-[-0.02em] text-ink-strong">
                  ไอดีเกมพร้อมเล่น
                </h3>
                <p className="mt-2 max-w-xl leading-relaxed text-muted text-sm">
                  ตรวจข้อมูลเกม แพลตฟอร์ม และรายละเอียดไอดีของแต่ละรายการก่อนเลือกซื้อ
                  เปลี่ยนข้อมูลได้ สะอาด ปลอดภัย 100%
                </p>
              </div>
            </article>

            {/* Card 2: Genshin & Wuthering */}
            <article className="bg-bg" data-reveal="true">
              <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-2.5 md:px-8">
                <p className="hud-label text-muted">เกมยอดนิยม</p>
                <p className="hud-label text-faint">02</p>
              </div>
              <div className="relative aspect-video w-full overflow-hidden bg-bg-sunken">
                <video
                  aria-label="เกมยอดนิยม"
                  className="absolute inset-0 h-full w-full object-cover"
                  loop
                  muted
                  playsInline
                  autoPlay
                  poster="/assets/Character-Pose.jpg"
                  preload="metadata"
                  src="/assets/Character-Pose.webm"
                />
              </div>
              <div className="px-6 py-6 md:px-8">
                <h3 className="font-display text-2xl font-medium tracking-[-0.02em] text-ink-strong">
                  Genshin Impact &amp; Wuthering Waves
                </h3>
                <p className="mt-2 max-w-xl leading-relaxed text-muted text-sm">
                  ไอดีตัวละครระดับ 5 ดาว ไอดีเริ่มต้น และไอดีพร้อมเล่นสำหรับคอเกมผจญภัย
                  จัดส่งรหัสผ่านทันทีหลังชำระเงิน
                </p>
              </div>
            </article>

            {/* Card 3: Source Code & Bots */}
            <article className="bg-bg" data-reveal="true">
              <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-2.5 md:px-8">
                <p className="hud-label text-muted">ซอร์สโค้ด</p>
                <p className="hud-label text-faint">03</p>
              </div>
              <div className="relative aspect-video w-full overflow-hidden bg-bg-sunken">
                <video
                  aria-label="ซอร์สโค้ดระดับโปร"
                  className="absolute inset-0 h-full w-full object-cover"
                  loop
                  muted
                  playsInline
                  autoPlay
                  poster="/assets/Editor.jpg"
                  preload="metadata"
                  src="/assets/Editor.webm"
                />
              </div>
              <div className="px-6 py-6 md:px-8">
                <h3 className="font-display text-2xl font-medium tracking-[-0.02em] text-ink-strong">
                  ซอร์สโค้ดและสคริปต์อัตโนมัติ
                </h3>
                <p className="mt-2 max-w-xl leading-relaxed text-muted text-sm">
                  ซอร์สโค้ดเว็บขายของ เว็บบริการ บอท Discord และสคริปต์จัดการระบบ
                  เขียนด้วย React, TypeScript, Node.js พร้อมคู่มือ
                </p>
              </div>
            </article>

            {/* Card 4: Warranty & Delivery */}
            <article className="bg-bg" data-reveal="true">
              <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-2.5 md:px-8">
                <p className="hud-label text-muted">ระบบอัตโนมัติ</p>
                <p className="hud-label text-faint">04</p>
              </div>
              <div className="relative aspect-video w-full overflow-hidden bg-bg-sunken">
                <video
                  aria-label="ระบบอัตโนมัติ"
                  className="absolute inset-0 h-full w-full object-cover"
                  loop
                  muted
                  playsInline
                  autoPlay
                  poster="/assets/Mixed.jpg"
                  preload="metadata"
                  src="/assets/Mixed.webm"
                />
              </div>
              <div className="px-6 py-6 md:px-8">
                <h3 className="font-display text-2xl font-medium tracking-[-0.02em] text-ink-strong">
                  สแกนจ่าย PromptPay ส่งมอบทันที
                </h3>
                <p className="mt-2 max-w-xl leading-relaxed text-muted text-sm">
                  ระบบตรวจสอบยอดเงินผ่าน PromptPay QR อัตโนมัติใน 1.2 วินาที
                  รับรหัสผ่านและไฟล์ทันที พร้อมประกันสินค้า 100%
                </p>
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* ──────────────────────────────────────────────────────────
          3. SECTION 02: วิธีสั่งซื้อ (#ownership)
          ────────────────────────────────────────────────────────── */}
      <section className="relative" data-choreo="true" id="ownership">
        <span
          aria-hidden="true"
          className="absolute inset-x-0 top-0 h-px origin-left bg-line"
          data-draw-rule="true"
        />
        <div className="relative mx-auto max-w-[1280px] border-x border-line">
          <span
            aria-hidden="true"
            className="tick tick-half z-[31] -top-[5px] -left-[6px]"
            data-draw-tick="true"
          />
          <span
            aria-hidden="true"
            className="tick tick-half z-[31] -top-[5px] -right-[5px]"
            data-draw-tick="true"
          />

          {/* Sticky Eyebrow */}
          <div
            className="sticky top-12 z-30 border-y border-line bg-bg/90 backdrop-blur-md"
            data-draw-eyebrow="true"
          >
            <div className="flex items-center justify-between gap-4 px-6 py-3 md:px-10">
              <p className="hud-label text-muted">
                <span className="text-faint">02</span>
                <span aria-hidden="true" className="mx-2 text-faint">
                  /
                </span>
                วิธีสั่งซื้อ
              </p>
              <p className="hud-label hidden text-faint sm:block">ขั้นตอนก่อนซื้อ</p>
            </div>
          </div>

          {/* Section Heading */}
          <div className="px-6 py-14 md:px-10 md:py-20">
            <h2
              className="max-w-3xl font-display text-4xl font-medium leading-[1.02] tracking-[-0.035em] text-ink-strong sm:text-5xl md:text-6xl"
              data-reveal="true"
            >
              เลือก{" "}
              <span className="font-serif italic font-normal text-muted">
                สินค้า
              </span>{" "}
              อย่างมั่นใจ
            </h2>
            <p
              className="mt-5 max-w-xl text-lg leading-relaxed text-muted"
              data-reveal="true"
            >
              อ่านรายละเอียดสินค้า ราคา และเงื่อนไขก่อนตัดสินใจ หากต้องการข้อมูลเพิ่มเติมให้ติดต่อร้านก่อนสั่งซื้อ
            </p>
          </div>

          {/* 3 Columns */}
          <div className="grid gap-px border-t border-line bg-line md:grid-cols-3" data-reveal-group="true">
            <article className="bg-bg p-6 md:p-8" data-reveal="true">
              <p className="hud-label text-faint">A</p>
              <h3 className="mt-4 font-display text-2xl font-medium tracking-[-0.02em] text-ink-strong">
                เลือกสินค้าและตรวจรายละเอียด
              </h3>
              <p className="mt-3 leading-relaxed text-muted text-sm font-sans">
                ดูหมวดหมู่สินค้า ข้อมูลตัวละคร แพลตฟอร์ม หรือฟีเจอร์ของซอร์สโค้ดให้ครบถ้วนก่อนกดสั่งซื้อ
              </p>
            </article>

            <article className="bg-bg p-6 md:p-8" data-reveal="true">
              <p className="hud-label text-faint">B</p>
              <h3 className="mt-4 font-display text-2xl font-medium tracking-[-0.02em] text-ink-strong">
                สแกนจ่ายผ่าน PromptPay QR
              </h3>
              <p className="mt-3 leading-relaxed text-muted text-sm font-sans">
                ชำระเงินผ่าน QR Code ด้วยแอปธนาคารใดก็ได้ ระบบตรวจยอดเงินอัตโนมัติ ไม่ต้องรอยืนยันสลิป
              </p>
            </article>

            <article className="bg-bg p-6 md:p-8" data-reveal="true">
              <p className="hud-label text-faint">C</p>
              <h3 className="mt-4 font-display text-2xl font-medium tracking-[-0.02em] text-ink-strong">
                รับรหัสหรือไฟล์ทันที 24 ชม.
              </h3>
              <p className="mt-3 leading-relaxed text-muted text-sm font-sans">
                รับข้อมูลล็อกอินหรือลิงก์ดาวน์โหลดทันทีบนหน้าจอ พร้อมเก็บประวัติการซื้อในบัญชีอย่างปลอดภัย
              </p>
            </article>
          </div>
        </div>
      </section>

      {/* ──────────────────────────────────────────────────────────
          4. SECTION 03: สถิติและไฮไลท์ (#made-with)
          ────────────────────────────────────────────────────────── */}
      <section className="relative" data-choreo="true" id="made-with">
        <span
          aria-hidden="true"
          className="absolute inset-x-0 top-0 h-px origin-left bg-line"
          data-draw-rule="true"
        />
        <div className="relative mx-auto max-w-[1280px] border-x border-line">
          <span
            aria-hidden="true"
            className="tick tick-half z-[31] -top-[5px] -left-[6px]"
            data-draw-tick="true"
          />
          <span
            aria-hidden="true"
            className="tick tick-half z-[31] -top-[5px] -right-[5px]"
            data-draw-tick="true"
          />

          {/* Sticky Eyebrow */}
          <div
            className="sticky top-12 z-30 border-y border-line bg-bg/90 backdrop-blur-md"
            data-draw-eyebrow="true"
          >
            <div className="flex items-center justify-between gap-4 px-6 py-3 md:px-10">
              <p className="hud-label text-muted">
                <span className="text-faint">03</span>
                <span aria-hidden="true" className="mx-2 text-faint">
                  /
                </span>
                สถิติระบบ
              </p>
              <p className="hud-label hidden text-faint sm:block">
                ไอดีเกมและซอร์สโค้ด
              </p>
            </div>
          </div>

          <div className="px-6 py-14 md:px-10 md:py-20">
            <h2
              className="max-w-3xl font-display text-4xl font-medium leading-[1.02] tracking-[-0.035em] text-ink-strong sm:text-5xl md:text-6xl"
              data-reveal="true"
            >
              สินค้า{" "}
              <span className="font-serif italic font-normal text-muted">
                และ
              </span>{" "}
              KODDYKUB.
            </h2>
          </div>

          {/* 3 Interactive Highlight Figures */}
          <div className="grid gap-px border-t border-line bg-line md:grid-cols-3" data-reveal-group="true">
            <figure className="bg-bg" data-reveal="true">
              <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-2.5">
                <figcaption className="hud-label text-muted">สมาชิกในระบบ</figcaption>
                <p className="hud-label text-faint">01</p>
              </div>
              <div className="p-8">
                <div className="font-display text-4xl sm:text-5xl font-bold text-ink-strong tracking-tight">
                  {(stats?.users || 12932).toLocaleString()}+
                </div>
                <p className="mt-3 text-sm text-muted leading-relaxed font-sans">
                  ผู้ใช้งานที่ไว้วางใจเลือกซื้อไอดีเกมและซอร์สโค้ดกับ KODDYKUB อย่างต่อเนื่อง
                </p>
              </div>
            </figure>

            <figure className="bg-bg" data-reveal="true">
              <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-2.5">
                <figcaption className="hud-label text-muted">คำสั่งซื้อสำเร็จ</figcaption>
                <p className="hud-label text-faint">02</p>
              </div>
              <div className="p-8">
                <div className="font-display text-4xl sm:text-5xl font-bold text-ink-strong tracking-tight">
                  {(stats?.totalOrders || stats?.sales || 12365).toLocaleString()}+
                </div>
                <p className="mt-3 text-sm text-muted leading-relaxed font-sans">
                  รายการจัดส่งสินค้าผ่านระบบอัตโนมัติ รวดเร็ว ภายในไม่เกิน 1-2 วินาที
                </p>
              </div>
            </figure>

            <figure className="bg-bg" data-reveal="true">
              <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-2.5">
                <figcaption className="hud-label text-muted">การรับประกัน</figcaption>
                <p className="hud-label text-faint">03</p>
              </div>
              <div className="p-8">
                <div className="font-display text-4xl sm:text-5xl font-bold text-emerald-400 tracking-tight">
                  100% ปลอดภัย
                </div>
                <p className="mt-3 text-sm text-muted leading-relaxed font-sans">
                  รับประกันความถูกต้องของสินค้า มีทีมงานแอดมินคอยดูแลและให้คำปรึกษาตลอด 24 ชม.
                </p>
              </div>
            </figure>
          </div>
        </div>
      </section>

      {/* ──────────────────────────────────────────────────────────
          5. SECTION 04: รายการสินค้าทั้งหมด (#start / #catalog)
          ────────────────────────────────────────────────────────── */}
      <section className="relative" data-choreo="true" id="start">
        <span
          aria-hidden="true"
          className="absolute inset-x-0 top-0 h-px origin-left bg-line"
          data-draw-rule="true"
        />
        <div className="relative mx-auto max-w-[1280px] border-x border-line">
          <span
            aria-hidden="true"
            className="tick tick-half z-[31] -top-[5px] -left-[6px]"
            data-draw-tick="true"
          />
          <span
            aria-hidden="true"
            className="tick tick-half z-[31] -top-[5px] -right-[5px]"
            data-draw-tick="true"
          />

          <div id="catalog" className="flex flex-col items-center px-6 py-16 text-center md:py-24">
            <p className="hud-label text-faint">KODDYKUB · สินค้าดิจิทัล</p>
            <h2
              className="mt-6 max-w-4xl font-display text-5xl font-medium leading-[0.98] tracking-[-0.04em] text-ink-strong sm:text-6xl md:text-7xl"
              data-reveal="true"
            >
              เลือก{" "}
              <span className="font-serif italic font-normal text-muted">
                สินค้า
              </span>
              .
            </h2>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-muted">
              เลือกหมวดไอดีเกมหรือซอร์สโค้ด แล้วตรวจสอบข้อมูลของสินค้าแต่ละรายการก่อนสั่งซื้อ
            </p>

            {/* Filter Tabs & Search Bar */}
            <div className="mt-10 w-full max-w-4xl flex flex-col md:flex-row items-center justify-between gap-4">
              {/* Filter Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none font-mono text-xs w-full md:w-auto">
                {filterTabs.map((tab) => {
                  const isActive = selectedTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setSelectedTab(tab.id)}
                      className={`inline-flex items-center gap-1.5 px-3 py-2 font-mono font-bold uppercase tracking-wider text-[11px] transition-colors cursor-pointer ${
                        isActive
                          ? "bg-invert-bg text-invert-fg border border-line"
                          : "border border-line bg-bg text-muted hover:text-ink hover:border-line-strong"
                      }`}
                    >
                      <tab.icon className="w-3 h-3" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Real-time Search Box */}
              <div className="relative w-full md:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted" />
                <input
                  type="text"
                  placeholder="ค้นหาชื่อสินค้า..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-10 pl-9 pr-8 bg-bg border border-line text-xs font-mono text-ink placeholder-muted focus:outline-none focus:border-line-strong"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted hover:text-ink text-xs"
                  >
                    ×
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Product Grid */}
          <div className="border-t border-line p-6 md:p-10">
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onClick={onProductClick}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 px-4">
                <Package className="w-10 h-10 text-muted mx-auto mb-3" />
                <h3 className="text-base font-bold text-ink">ไม่พบสินค้าที่ค้นหา</h3>
                <p className="text-xs text-muted mt-1">
                  กรุณาตรวจสอบคำค้นหาหรือลองเลือกหมวดหมู่อื่น
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedTab("all");
                    setSearchQuery("");
                  }}
                  className="mt-4 px-4 py-2 border border-line bg-bg text-xs font-mono uppercase tracking-wider text-ink hover:bg-invert-bg hover:text-invert-fg transition-colors"
                >
                  ล้างตัวกรอง
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ──────────────────────────────────────────────────────────
          HOW TO ORDER MODAL (Exact Clean Step Dialog)
          ────────────────────────────────────────────────────────── */}
      {showHowToModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          onClick={() => setShowHowToModal(false)}
        >
          <div
            className="dialog-inner relative w-full max-w-lg bg-bg border border-line-strong p-6 sm:p-8 text-left text-ink shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setShowHowToModal(false)}
              className="dialog-close absolute top-3 right-4 text-muted hover:text-ink text-2xl"
              aria-label="ปิด"
            >
              ×
            </button>

            <h2 className="font-display text-2xl sm:text-3xl font-medium tracking-tight text-ink-strong">
              ขั้นตอนการสั่งซื้อสินค้า
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-muted leading-relaxed font-sans">
              ระบบของ KODDYKUB ทำงานแบบอัตโนมัติ 24 ชม. สะดวกและรวดเร็ว
            </p>

            <div className="mt-6 space-y-4">
              <div className="border border-line p-4 bg-bg-sunken">
                <div className="flex items-center gap-2 font-mono text-xs font-bold text-ink-strong">
                  <span className="w-5 h-5 rounded-none bg-invert-bg text-invert-fg flex items-center justify-center text-[10px]">
                    1
                  </span>
                  <span>เลือกสินค้าที่ต้องการ</span>
                </div>
                <p className="mt-1.5 text-xs text-muted leading-relaxed pl-7">
                  เลือกไอดีเกม ซอร์สโค้ด หรือสคริปต์ แล้วตรวจสอบรายละเอียดและเงื่อนไข
                </p>
              </div>

              <div className="border border-line p-4 bg-bg-sunken">
                <div className="flex items-center gap-2 font-mono text-xs font-bold text-ink-strong">
                  <span className="w-5 h-5 rounded-none bg-invert-bg text-invert-fg flex items-center justify-center text-[10px]">
                    2
                  </span>
                  <span>สแกนชำระผ่าน PromptPay QR</span>
                </div>
                <p className="mt-1.5 text-xs text-muted leading-relaxed pl-7">
                  ระบบสร้าง QR Code พร้อมยอดเงินที่ถูกต้อง เปิดแอปธนาคารใดก็ได้แล้วสแกนชำระทันที
                </p>
              </div>

              <div className="border border-line p-4 bg-bg-sunken">
                <div className="flex items-center gap-2 font-mono text-xs font-bold text-ink-strong">
                  <span className="w-5 h-5 rounded-none bg-invert-bg text-invert-fg flex items-center justify-center text-[10px]">
                    3
                  </span>
                  <span>รับรหัสผ่านหรือไฟล์ดาวน์โหลด</span>
                </div>
                <p className="mt-1.5 text-xs text-muted leading-relaxed pl-7">
                  เมื่อระบบตรวจสอบยอดเงินเรียบร้อย จะส่งมอบข้อมูลทันทีบนหน้าจอและบันทึกในบัญชีของคุณ
                </p>
              </div>
            </div>

            <div className="mt-8 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setShowHowToModal(false);
                  scrollTo("start");
                }}
                className="px-6 py-2.5 bg-invert-bg text-invert-fg font-mono text-xs font-bold uppercase tracking-wider hover:opacity-85 transition-opacity"
              >
                ดูสินค้าทั้งหมด
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
