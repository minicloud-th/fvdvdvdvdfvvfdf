import React from "react";
import { Product } from "../types";
import { ImageWithFallback } from "./ui/ImageWithFallback";

interface ProductCardProps {
  product: Product;
  onClick: (id: string) => void;
  className?: string;
  categoryName?: string;
  showCategory?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onClick,
  className = "",
  categoryName,
  showCategory = true,
}) => {
  const isAvailable = (product.stock ?? 0) > 0;
  const isDelivery = Boolean(product.delivery || isAvailable);

  const displayCategory =
    categoryName ||
    (typeof product.category === "string"
      ? product.category === "game_accounts"
        ? "ไอดีเกม"
        : product.category === "source_code"
        ? "ซอร์สโค้ด"
        : product.category === "automation_bots"
        ? "บอท & สคริปต์"
        : product.category === "game_scripts"
        ? "สคริปต์"
        : product.category === "developer_services" || product.category === "digital_services"
        ? "บริการดิจิทัล"
        : product.category
      : "สินค้าดิจิทัล");

  return (
    <button
      type="button"
      className={`product-card ${className}`}
      onClick={() => onClick(product.id)}
      aria-label={product.name}
    >
      <div className="product-image">
        <ImageWithFallback
          src={product.imageUrl}
          alt={product.name}
          width={280}
          height={280}
          loading="lazy"
          className="w-full h-full object-cover"
        />
        {(product.isPopular || product.tag) && (
          <span className="hot-badge">{product.tag || "HOT"}</span>
        )}
      </div>

      <h3 title={product.name}>{product.name}</h3>

      {showCategory && (
        <div className="product-category">
          <small>หมวดหมู่:</small>
          <span>{displayCategory}</span>
        </div>
      )}

      <div className="product-bottom">
        <span>
          {isAvailable
            ? isDelivery
              ? "สินค้าพร้อมส่ง"
              : `คงเหลือ ${product.stock} ชิ้น`
            : "สินค้าหมด"}
        </span>
        <strong>
          {(product.price || 0).toLocaleString()} <b>฿</b>
        </strong>
      </div>
    </button>
  );
};

export default ProductCard;
