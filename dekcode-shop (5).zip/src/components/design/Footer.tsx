import React from "react";

interface FooterProps {
  setActiveView: (view: string) => void;
  siteSettings?: any;
  onOpenPrivacy?: () => void;
  onOpenTerms?: () => void;
  onOpenContact?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  setActiveView,
  onOpenPrivacy,
  onOpenTerms,
  onOpenContact,
}) => {
  return (
    <footer className="border-t border-line select-none bg-bg text-ink">
      <div className="mx-auto max-w-[1280px] border-x border-line">
        <div className="grid gap-px bg-line md:grid-cols-4 lg:grid-cols-[2fr_1fr_1fr_1fr_1fr]">
          {/* Brand Info Column */}
          <div className="bg-bg p-6 md:col-span-4 md:p-10 lg:col-span-1">
            <div className="flex items-center gap-2.5">
              <img
                alt="KODDYKUB"
                className="themed-logo h-8 w-auto"
                src="/assets/artcraft-icon.svg"
              />
              <span className="font-mono font-bold tracking-widest text-sm text-ink-strong">
                KODDYKUB
              </span>
            </div>
            <p className="mt-4 max-w-xs leading-relaxed text-muted text-xs font-sans">
              ร้านสินค้าดิจิทัลสำหรับเกมเมอร์และนักพัฒนา: ศูนย์รวมไอดีเกมแท้และซอร์สโค้ดคุณภาพ
            </p>
            <button
              type="button"
              onClick={onOpenContact}
              className="hud-label mt-6 inline-block text-faint hover:text-ink text-xs cursor-pointer"
            >
              ติดต่อร้าน KODDYKUB →
            </button>
          </div>

          {/* Nav: Product */}
          <nav aria-label="Product" className="bg-bg p-6 md:p-8">
            <p className="hud-label text-faint">สินค้า</p>
            <ul className="mt-4 flex flex-col gap-2.5 text-xs font-sans">
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  เลือกสินค้า
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  รายการสินค้า
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("features")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  หมวดสินค้า
                </button>
              </li>
            </ul>
          </nav>

          {/* Nav: Categories */}
          <nav aria-label="Categories" className="bg-bg p-6 md:p-8">
            <p className="hud-label text-faint">หมวดสินค้า</p>
            <ul className="mt-4 flex flex-col gap-2.5 text-xs font-sans">
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  ไอดีเกม
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  ซอร์สโค้ด
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  Wuthering Waves
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  Genshin Impact
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  Roblox &amp; Steam
                </button>
              </li>
            </ul>
          </nav>

          {/* Nav: Resources */}
          <nav aria-label="Resources" className="bg-bg p-6 md:p-8">
            <p className="hud-label text-faint">ข้อมูล &amp; บริการ</p>
            <ul className="mt-4 flex flex-col gap-2.5 text-xs font-sans">
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("ownership")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  วิธีสั่งซื้อ
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    document.getElementById("features")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  การรับประกัน
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenTerms}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  เงื่อนไขการใช้งาน
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenPrivacy}
                  className="text-muted hover:text-ink cursor-pointer text-left"
                >
                  นโยบายความเป็นส่วนตัว
                </button>
              </li>
            </ul>
          </nav>

          {/* Nav: Community */}
          <nav aria-label="Community" className="bg-bg p-6 md:p-8">
            <p className="hud-label text-faint">ติดตามร้าน</p>
            <ul className="mt-4 flex flex-col gap-2.5 text-xs font-sans">
              <li>
                <a
                  className="text-muted hover:text-ink"
                  href="https://discord.gg/artcraft"
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  Discord
                </a>
              </li>
              <li>
                <a
                  className="text-muted hover:text-ink"
                  href="https://github.com/storytold/artcraft"
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  GitHub
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenContact}
                  className="text-muted hover:text-ink text-left cursor-pointer"
                >
                  ติดต่อแอดมิน
                </button>
              </li>
            </ul>
          </nav>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col gap-2 border-t border-line px-6 py-4 md:flex-row md:items-center md:justify-between md:px-10 text-xs">
          <p className="hud-label text-faint">© 2026 KODDYKUB</p>
          <p className="hud-label text-faint">สินค้าดิจิทัลสำหรับเกมเมอร์และนักพัฒนา</p>
          <a
            className="hud-label text-faint hover:text-ink"
            href="/hero-video-credits.html"
            target="_blank"
            rel="noopener noreferrer"
          >
            เครดิตสื่อ
          </a>
        </div>
      </div>
    </footer>
  );
};
