import React from "react";
import { motion } from "motion/react";
import {
  ArrowRight,
  Terminal,
  Gamepad2,
  Code2,
  Bot,
  Zap,
  ShieldCheck,
  Sparkles,
  Layers,
  ChevronRight,
} from "lucide-react";

interface ComposioHeroProps {
  onExplore: () => void;
  onOpenStore: () => void;
}

export const ComposioHero: React.FC<ComposioHeroProps> = ({
  onExplore,
  onOpenStore,
}) => {
  return (
    <section className="relative w-full bg-[#000000] text-white overflow-hidden pt-12 pb-20 sm:pt-20 sm:pb-28 border-b border-[#1A1A1A]">
      {/* ──────────────────────────────────────────────────────────
          1. COMPOSIO ANIMATED SIDE SLIT-WAVE MESH (Left & Right)
          ────────────────────────────────────────────────────────── */}
      {/* Left Slit Wave */}
      <div
        className="absolute left-0 top-0 bottom-0 w-36 sm:w-64 pointer-events-none opacity-40 sm:opacity-70 overflow-hidden flex items-center"
        aria-hidden="true"
      >
        <div className="flex gap-1.5 sm:gap-2 h-full items-center pl-2">
          {Array.from({ length: 18 }).map((_, i) => {
            const height = 40 + Math.sin(i * 0.45) * 35 + (i % 3) * 12;
            return (
              <motion.div
                key={`left-bar-${i}`}
                className="w-1 sm:w-1.5 rounded-full"
                style={{
                  background:
                    i % 2 === 0
                      ? "linear-gradient(180deg, transparent, #1515F5 45%, #00D2FF 75%, transparent)"
                      : "linear-gradient(180deg, transparent, #1D4ED8 30%, #0099FF 70%, transparent)",
                }}
                animate={{
                  height: [`${height}%`, `${Math.min(95, height + 25)}%`, `${height}%`],
                  opacity: [0.35, 0.9, 0.35],
                }}
                transition={{
                  duration: 2.4 + (i % 4) * 0.4,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: i * 0.12,
                }}
              />
            );
          })}
        </div>
      </div>

      {/* Right Slit Wave */}
      <div
        className="absolute right-0 top-0 bottom-0 w-36 sm:w-64 pointer-events-none opacity-40 sm:opacity-70 overflow-hidden flex items-center justify-end"
        aria-hidden="true"
      >
        <div className="flex gap-1.5 sm:gap-2 h-full items-center pr-2">
          {Array.from({ length: 18 }).map((_, i) => {
            const height = 45 + Math.cos(i * 0.4) * 35 + (i % 3) * 10;
            return (
              <motion.div
                key={`right-bar-${i}`}
                className="w-1 sm:w-1.5 rounded-full"
                style={{
                  background:
                    i % 2 === 0
                      ? "linear-gradient(180deg, transparent, #00D2FF 35%, #1515F5 75%, transparent)"
                      : "linear-gradient(180deg, transparent, #0099FF 40%, #1D4ED8 80%, transparent)",
                }}
                animate={{
                  height: [`${height}%`, `${Math.min(95, height + 25)}%`, `${height}%`],
                  opacity: [0.35, 0.9, 0.35],
                }}
                transition={{
                  duration: 2.6 + (i % 4) * 0.4,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: i * 0.15,
                }}
              />
            );
          })}
        </div>
      </div>

      {/* ──────────────────────────────────────────────────────────
          2. HERO CONTENT (Composio Signature Style)
          ────────────────────────────────────────────────────────── */}
      <div className="relative z-10 max-w-[1100px] mx-auto px-4 sm:px-6 flex flex-col items-center text-center">
        {/* Top Eyebrow Pill: WORKS WITH + Brand Logos */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-3 px-3.5 py-1.5 rounded-full border border-[#282828] bg-[#0A0A0A]/80 backdrop-blur-md text-[11px] font-mono text-[#A3A3A3] mb-8 select-none"
        >
          <span className="tracking-wider uppercase text-[#737373] font-semibold text-[10px]">
            WORKS WITH
          </span>
          <div className="h-3 w-px bg-[#262626]" />
          <div className="flex items-center gap-2.5 text-white">
            <span title="Valorant" className="text-xs hover:text-blue-400 transition-colors">VALORANT</span>
            <span className="text-[#444]">·</span>
            <span title="Roblox" className="text-xs hover:text-blue-400 transition-colors">ROBLOX</span>
            <span className="text-[#444]">·</span>
            <span title="Steam" className="text-xs hover:text-blue-400 transition-colors">STEAM</span>
            <span className="text-[#444]">·</span>
            <span title="React / Next.js" className="text-xs hover:text-blue-400 transition-colors">REACT / NEXT.JS</span>
            <span className="text-[#444]">·</span>
            <span title="Discord Bots" className="text-xs hover:text-blue-400 transition-colors">DISCORD</span>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-[#737373]" />
        </motion.div>

        {/* Composio Signature Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-3xl sm:text-5xl md:text-6xl lg:text-[68px] font-bold tracking-tight text-white leading-[1.12] max-w-4xl"
        >
          Give your project secure access
          <br className="hidden sm:inline" />
          <span className="sm:inline"> to top accounts &amp; code </span>
          <span className="inline-block bg-[#1515F5] text-white px-2.5 sm:px-4 py-0.5 sm:py-1 rounded-sm shadow-[0_0_30px_rgba(21,21,245,0.5)] mt-1.5 sm:mt-0">
            in minutes
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 text-sm sm:text-base md:text-lg text-[#888888] max-w-2xl font-normal leading-relaxed"
        >
          ศูนย์รวมไอดีเกมแท้ ซอร์สโค้ด Full-stack และสคริปต์อัตโนมัติคุณภาพสูง
          <br className="hidden sm:inline" />
          ระบบส่งมอบข้อมูลรหัสผ่านและคู่มือใช้งานทันทีหลังชำระเงิน ตลอด 24 ชั่วโมง
        </motion.p>

        {/* Dual CTA Buttons (Composio High-Contrast Style) */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-9 flex flex-col sm:flex-row items-center gap-3 sm:gap-4 w-full sm:w-auto"
        >
          <button
            type="button"
            onClick={onOpenStore}
            className="w-full sm:w-auto px-7 py-3.5 rounded-sm bg-white hover:bg-[#E5E5E5] text-[#050505] font-mono text-xs font-bold tracking-wider uppercase transition-all duration-150 cursor-pointer shadow-lg hover:shadow-white/20 active:scale-98 flex items-center justify-center gap-2"
          >
            <span>GET STARTED FOR FREE</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onExplore}
            className="w-full sm:w-auto px-7 py-3.5 rounded-sm bg-transparent hover:bg-[#121212] border border-[#333333] hover:border-[#666666] text-white font-mono text-xs font-semibold tracking-wider uppercase transition-all duration-150 cursor-pointer active:scale-98 flex items-center justify-center gap-2"
          >
            <span>EXPLORE FEATURES</span>
          </button>
        </motion.div>

        {/* Social Proof Sub-caption */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-7 text-xs font-mono text-[#555555] tracking-wide"
        >
          12,000+ orders completed · 100% verified authentic accounts
        </motion.div>
      </div>
    </section>
  );
};

export default ComposioHero;
