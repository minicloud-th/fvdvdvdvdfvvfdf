import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Check,
  Search,
  Terminal,
  ShieldCheck,
  Zap,
  Code2,
  Cpu,
  Layers,
  ArrowRight,
  Sparkles,
} from "lucide-react";

interface TabItem {
  id: string;
  num: string;
  label: string;
  title: string;
  description: string;
  bullets: string[];
  mockup: {
    searchQuery: string;
    itemsCount: string;
    actions: Array<{ name: string; desc: string; badge?: string; badgeColor?: string }>;
    plan: string[];
    warnings: string[];
  };
}

const TABS: TabItem[] = [
  {
    id: "instant-delivery",
    num: "01",
    label: "NO CONTEXT BLOAT",
    title: "The right actions, without the context bloat",
    description:
      "Every action your AI knows about takes up context. Composio searches the full catalogue and loads only what your task needs, then suggests a plan and adds guardrails.",
    bullets: [
      "Match actions & tools to what the task requires",
      "Load credentials on-demand without security exposure",
      "Automatic failover and zero manual waiting time",
    ],
    mockup: {
      searchQuery: "list sentry errors and create linear...",
      itemsCount: "3 found",
      actions: [
        {
          name: "SENTRY_LIST_ISSUES",
          desc: "List unresolved issues in a project",
          badge: "MATCH",
          badgeColor: "bg-[#1515F5] text-white",
        },
        {
          name: "SENTRY_GET_EVENT",
          desc: "Get error event details and stack trace",
          badge: "MATCH",
          badgeColor: "bg-[#1515F5] text-white",
        },
        {
          name: "LINEAR_CREATE_ISSUE",
          desc: "Create a new issue in Linear roadmap",
        },
      ],
      plan: ["1 Fetch all open Sentry issues", "2 Classify severity and stack trace", "3 Create Linear issue with labels"],
      warnings: ["! Sentry project slug required", "! Linear team ID verified"],
    },
  },
  {
    id: "better-every-time",
    num: "02",
    label: "BETTER EVERY TIME",
    title: "Self-healing tools and continuous verification",
    description:
      "When APIs shift or endpoints update, connections adapt automatically. Built-in telemetry monitors authentication states and refreshes tokens before requests fail.",
    bullets: [
      "Smart schema normalization across diverse third-party APIs",
      "Automated health checks and real-time credential rotation",
      "99.98% uptime with automated retries and idempotency keys",
    ],
    mockup: {
      searchQuery: "validate auth credentials and refresh token...",
      itemsCount: "2 checked",
      actions: [
        {
          name: "OAUTH_TOKEN_VERIFY",
          desc: "Verify JWT signature & expiry timestamp",
          badge: "ACTIVE",
          badgeColor: "bg-emerald-500 text-black",
        },
        {
          name: "SESSION_REFRESH_HANDLER",
          desc: "Rotate bearer tokens without user logout",
          badge: "ROTATED",
          badgeColor: "bg-cyan-400 text-black",
        },
      ],
      plan: ["1 Verify current session TTL", "2 Trigger background rotation", "3 Persist encrypted refresh token"],
      warnings: ["! Safe rotation window: < 5 mins remaining"],
    },
  },
  {
    id: "one-click-connections",
    num: "03",
    label: "ONE-CLICK CONNECTIONS",
    title: "Instant authentication with 1,500+ ecosystem apps",
    description:
      "Eliminate OAuth setup hurdles. Users authenticate directly through secure popups, while secrets and access tokens remain encrypted in zero-knowledge vaults.",
    bullets: [
      "Pre-configured OAuth consent for Google, GitHub, Discord & Slack",
      "Scoped permissions preventing privilege escalation",
      "Instant disconnect and audit trail per workspace member",
    ],
    mockup: {
      searchQuery: "connect github repo and discord webhook...",
      itemsCount: "Connected",
      actions: [
        {
          name: "GITHUB_SYNC_REPO",
          desc: "Link repository webhooks & pull request triggers",
          badge: "LINKED",
          badgeColor: "bg-[#1515F5] text-white",
        },
        {
          name: "DISCORD_POST_MESSAGE",
          desc: "Send release broadcast to #announcements",
          badge: "ONLINE",
          badgeColor: "bg-emerald-400 text-black",
        },
      ],
      plan: ["1 Authorize OAuth token with repo scope", "2 Validate channel webhook destination"],
      warnings: ["! Webhook secret HMAC verified"],
    },
  },
  {
    id: "agent-runtime",
    num: "04",
    label: "AGENT RUNTIME",
    title: "Autonomous execution with real-time guardrails",
    description:
      "Run complex multi-step workflows safely. Built-in rate limits, budget enforcement, and human-in-the-loop triggers keep your autonomous systems reliable and compliant.",
    bullets: [
      "Dynamic prompt injection shields and sandboxed execution",
      "Granular cost-per-action caps and spending alerts",
      "Full replayable request logs with latency telemetry",
    ],
    mockup: {
      searchQuery: "execute automated pipeline with guardrails...",
      itemsCount: "Sandbox OK",
      actions: [
        {
          name: "SANDBOX_RUNTIME_INIT",
          desc: "Isolate process memory and network ingress",
          badge: "GUARDED",
          badgeColor: "bg-[#1515F5] text-white",
        },
        {
          name: "DISPATCH_ACTION_QUEUE",
          desc: "Execute queued tasks with circuit breaker",
          badge: "RUNNING",
          badgeColor: "bg-amber-400 text-black",
        },
      ],
      plan: ["1 Allocate isolated sandbox container", "2 Inject vetted action definitions", "3 Stream execution logs"],
      warnings: ["! Rate limit: 120 req/min enforced"],
    },
  },
];

export const ComposioShowcase: React.FC = () => {
  const [activeTabIdx, setActiveTabIdx] = useState(0);
  const activeTab = TABS[activeTabIdx];

  // Auto-cycle tabs every 8 seconds if user doesn't click
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTabIdx((prev) => (prev + 1) % TABS.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative w-full bg-[#000000] text-white py-20 sm:py-28 border-b border-[#1A1A1A] overflow-hidden">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        
        {/* ──────────────────────────────────────────────────────────
            1. SECTION TITLE & INTRO
            ────────────────────────────────────────────────────────── */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl sm:text-5xl font-bold tracking-tight text-white leading-tight"
          >
            Everything between the ask and the result, handled
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="mt-4 text-sm sm:text-base text-[#888888] leading-relaxed max-w-2xl mx-auto"
          >
            Give your AI &amp; agent a task. Composio finds the right actions across 1,500+ apps, connects each app in a click, and keeps connections working as those apps change.
          </motion.p>
        </div>

        {/* ──────────────────────────────────────────────────────────
            2. THREE-COLUMN INTERACTIVE SHOWCASE (Composio Screenshot 1)
            ────────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-8 items-center">
          
          {/* Column 1: Numbered Navigation Tabs (Cols 1-3) */}
          <div className="lg:col-span-3 flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0 scrollbar-none font-mono text-xs">
            {TABS.map((tab, idx) => {
              const isActive = activeTabIdx === idx;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTabIdx(idx)}
                  className={`w-full text-left px-4 py-3.5 rounded-sm transition-all duration-200 cursor-pointer select-none flex items-center gap-3 shrink-0 ${
                    isActive
                      ? "border border-[#1515F5] bg-[#1515F5]/10 text-white font-bold shadow-[0_0_20px_rgba(21,21,245,0.2)]"
                      : "border border-transparent text-[#737373] hover:text-white hover:bg-[#0E0E0E]"
                  }`}
                >
                  <span
                    className={`text-[11px] font-bold ${
                      isActive ? "text-[#1515F5]" : "text-[#555555]"
                    }`}
                  >
                    {tab.num}
                  </span>
                  <span className="tracking-wider uppercase truncate">
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Column 2: Center Interactive Visual Card (Cols 4-8) */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            {/* 3D Cyan / Cobalt Glow Backdrop (Exact match to Composio Screenshot 1) */}
            <div
              className="absolute -inset-4 sm:-inset-6 rounded-2xl opacity-60 filter blur-2xl pointer-events-none transition-all duration-700"
              style={{
                background:
                  activeTabIdx === 0
                    ? "radial-gradient(circle at center, #00D2FF 0%, #1515F5 60%, transparent 80%)"
                    : activeTabIdx === 1
                    ? "radial-gradient(circle at center, #10B981 0%, #0088FF 60%, transparent 80%)"
                    : activeTabIdx === 2
                    ? "radial-gradient(circle at center, #8B5CF6 0%, #1515F5 60%, transparent 80%)"
                    : "radial-gradient(circle at center, #F59E0B 0%, #1515F5 60%, transparent 80%)",
              }}
            />

            {/* Glowing 3D Glass Accent Block Behind Card */}
            <div
              className="absolute -right-4 -bottom-4 w-3/4 h-3/4 rounded-xl border border-white/20 bg-gradient-to-br from-[#00D2FF]/40 to-[#1515F5]/40 backdrop-blur-md pointer-events-none hidden sm:block"
              style={{
                transform: "translate3d(12px, 12px, 0)",
              }}
            />

            {/* Main Terminal Frame */}
            <div className="relative z-10 w-full rounded-xl bg-[#0B0D13]/95 border border-[#222838] shadow-2xl p-4 sm:p-5 font-mono text-xs overflow-hidden backdrop-blur-xl">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-4"
                >
                  {/* Top Search / Command Line */}
                  <div className="flex items-center justify-between gap-2 px-3 py-2 rounded bg-[#07080C] border border-[#1C2030] text-[#737373]">
                    <div className="flex items-center gap-2 min-w-0">
                      <Search className="w-3.5 h-3.5 text-[#555555] shrink-0" />
                      <span className="text-[#A3A3A3] truncate text-[11px]">
                        {activeTab.mockup.searchQuery}
                      </span>
                    </div>
                    <span className="text-[10px] text-[#555555] shrink-0">
                      {activeTab.mockup.itemsCount}
                    </span>
                  </div>

                  {/* Actions List with Status Pills */}
                  <div className="space-y-2">
                    {activeTab.mockup.actions.map((act, i) => (
                      <motion.div
                        key={act.name}
                        initial={{ opacity: 0, x: -6 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.08 }}
                        className="flex items-center justify-between p-2.5 rounded bg-[#111420] border border-[#1F2538] hover:border-[#323D5C] transition-colors"
                      >
                        <div className="min-w-0 pr-2">
                          <div className="text-white font-bold text-[11px] truncate">
                            {act.name}
                          </div>
                          <div className="text-[10px] text-[#737373] truncate">
                            {act.desc}
                          </div>
                        </div>
                        {act.badge && (
                          <span
                            className={`px-2 py-0.5 rounded text-[9px] font-bold tracking-wider shrink-0 ${
                              act.badgeColor || "bg-[#1515F5] text-white"
                            }`}
                          >
                            {act.badge}
                          </span>
                        )}
                      </motion.div>
                    ))}
                  </div>

                  {/* Lower Execution Plan & Warnings */}
                  <div className="pt-2 border-t border-[#1C2030] grid grid-cols-1 sm:grid-cols-2 gap-3 text-[10px]">
                    <div>
                      <div className="text-[#555555] uppercase tracking-wider font-semibold mb-1">
                        PLAN
                      </div>
                      <div className="space-y-0.5 text-[#888888]">
                        {activeTab.mockup.plan.map((step, idx) => (
                          <div key={idx} className="truncate">
                            {step}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="text-[#555555] uppercase tracking-wider font-semibold mb-1">
                        WARNINGS
                      </div>
                      <div className="space-y-0.5 text-amber-400/90 font-medium">
                        {activeTab.mockup.warnings.map((warn, idx) => (
                          <div key={idx} className="truncate">
                            {warn}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          {/* Column 3: Feature Details (Cols 9-12) */}
          <div className="lg:col-span-4 pl-0 lg:pl-4 space-y-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab.id}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.25 }}
                className="space-y-4"
              >
                {/* Number Badge */}
                <div className="font-mono text-xs text-[#1515F5] font-bold">
                  {activeTab.num}
                </div>

                {/* Bold Headline */}
                <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight leading-snug">
                  {activeTab.title}
                </h3>

                {/* Paragraph Description */}
                <p className="text-xs sm:text-sm text-[#888888] leading-relaxed">
                  {activeTab.description}
                </p>

                {/* Checklist with Accent Bar */}
                <div className="pt-2 space-y-2.5">
                  {activeTab.bullets.map((bullet, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 text-xs text-[#A3A3A3]"
                    >
                      <span className="text-[#1515F5] font-mono select-none">|</span>
                      <span>{bullet}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

        </div>
      </div>
    </section>
  );
};

export default ComposioShowcase;
