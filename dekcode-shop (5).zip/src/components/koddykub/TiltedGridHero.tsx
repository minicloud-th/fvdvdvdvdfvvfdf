import * as React from "react";

const cn = (...classes: (string | boolean | undefined | null)[]) =>
  classes.filter(Boolean).join(" ");

const SLICES = 16;
const CAMERA = 1.6;

function arc(bend: number) {
  return (CAMERA - 1 + Math.cos(bend)) / (2 * CAMERA * Math.sin(bend));
}

const MAX_WIDTH = 55;

function measure(
  width: number,
  height: number,
  tile: number,
  aspect: number,
  gap: number,
  bend: number,
) {
  const h = Math.min(
    (tile / 100) * height,
    ((MAX_WIDTH / 100) * width) / aspect,
  );
  const radius = width * arc(bend);
  if (!(h > 0) || !(radius > 0))
    return { columns: 2, sweep: 0, unit: 0, limit: 0 };
  const deg = (rad: number) => (rad * 180) / Math.PI;
  const unit = deg(h / radius);
  const pitch = (aspect + gap / 100) * unit;
  const limit = deg(bend) + (aspect * unit) / 2;
  const columns = Math.min(60, Math.max(2, Math.ceil((2 * limit) / pitch)));
  const round = (n: number) => +n.toFixed(4);
  const sweep = round((columns * pitch) / 2);
  return {
    columns,
    sweep,
    unit: round(unit),
    limit: round(Math.min(sweep, limit)),
  };
}

export type TiltedGridImage = {
  src: string;
  alt?: string;
};

export type TiltedGridVideo = {
  src: string;
  title: string;
};

export type TiltedGridHeroProps = {
  images: TiltedGridImage[];
  videos?: TiltedGridVideo[];
  speed?: number;
  tileHeight?: number;
  aspectRatio?: number;
  gap?: number;
  axis?: number;
  curve?: number;
  fade?: number;
  children?: React.ReactNode;
  className?: string;
};

export function TiltedGridHero({
  images,
  videos = [],
  speed = 4,
  tileHeight = 26,
  aspectRatio = 16 / 9,
  gap = 6,
  axis = 56,
  curve = 80,
  fade = 12,
  children,
  className,
  ...props
}: React.ComponentProps<"div"> & TiltedGridHeroProps) {
  const ref = React.useRef<HTMLDivElement>(null);
  const id = React.useId().replace(/[^a-zA-Z0-9]/g, "");
  const orbit = `tgh-o-${id}`;
  const tile = `tgh-t-${id}`;
  const bend = (Math.min(85, Math.max(5, curve)) * Math.PI) / 180;

  const [layout, setLayout] = React.useState<ReturnType<typeof measure> | null>(
    null,
  );
  const [shown, setShown] = React.useState<Record<number, number>>({});

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      const next = measure(width, height, tileHeight, aspectRatio, gap, bend);
      setLayout((prev) =>
        prev?.columns === next.columns &&
        prev.sweep === next.sweep &&
        prev.unit === next.unit
          ? prev
          : next,
      );
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [tileHeight, aspectRatio, gap, bend]);

  React.useEffect(() => {
    const el = ref.current;
    if (!el || !("IntersectionObserver" in window)) return;
    let heroVisible = false;

    const videoObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const video = entry.target as HTMLVideoElement;
          if (heroVisible && entry.isIntersecting) {
            video.play().catch(() => {});
          } else {
            video.pause();
          }
        });
      },
      { rootMargin: "0px" },
    );

    const observeVideos = () => {
      el.querySelectorAll("video:not([data-visibility-observed])").forEach(
        (video) => {
          video.setAttribute("data-visibility-observed", "");
          videoObserver.observe(video);
          if (heroVisible) (video as HTMLVideoElement).play().catch(() => {});
        },
      );
    };

    const mutationObserver = new MutationObserver(observeVideos);
    mutationObserver.observe(el, { childList: true, subtree: true });
    observeVideos();

    const heroObserver = new IntersectionObserver(
      ([entry]) => {
        heroVisible = entry.isIntersecting;
        el.dataset.pauseMotion = String(!heroVisible);
        if (!heroVisible) {
          el.querySelectorAll("video").forEach((video) =>
            (video as HTMLVideoElement).pause(),
          );
        } else {
          observeVideos();
          el.querySelectorAll("video").forEach((video) =>
            (video as HTMLVideoElement).play().catch(() => {}),
          );
        }
      },
      { rootMargin: "0px" },
    );

    heroObserver.observe(el);

    return () => {
      mutationObserver.disconnect();
      heroObserver.disconnect();
      videoObserver.disconnect();
      el.querySelectorAll("video").forEach((video) =>
        (video as HTMLVideoElement).pause(),
      );
    };
  }, []);

  React.useEffect(() => {
    if (!videos.length) {
      for (const { src } of images) {
        const img = new Image();
        img.src = src;
      }
    }
  }, [images, videos]);

  const { columns, sweep, unit, limit } =
    layout ?? measure(1200, 560, tileHeight, aspectRatio, gap, bend);

  const u = (n: number) =>
    `calc(${+n.toFixed(4)} * min(${tileHeight}cqh, ${+(
      MAX_WIDTH / aspectRatio
    ).toFixed(4)}cqw))`;
  const r = 100 * arc(bend);
  const radius = `${+r.toFixed(3)}cqw`;

  const turn = (deg: number) =>
    `translateZ(${radius}) rotateY(${+deg.toFixed(4)}deg) translateZ(-${radius})`;

  const hide = +(((sweep - limit) / (2 * sweep || 1)) * 100).toFixed(4);
  const css =
    `@keyframes ${orbit}{` +
    `from{transform:${turn(-sweep)}}to{transform:${turn(sweep)}}` +
    `0%,${hide}%,${100 - hide}%,100%{visibility:hidden}` +
    `${hide + 0.001}%,${100 - hide - 0.001}%{visibility:visible}}` +
    `@media(prefers-reduced-motion:reduce){.${tile}{animation-play-state:paused}}`;

  const share = aspectRatio / SLICES;
  const duration = columns * speed;
  const mask = `linear-gradient(90deg,transparent,#000 ${fade}%,#000 ${
    100 - fade
  }%,transparent)`;

  return (
    <div
      ref={ref}
      className={cn("tgh-root", className)}
      {...props}
      style={{ containerType: "size", ...props.style }}
    >
      <style>{css}</style>
      <div
        aria-hidden={true}
        className="tgh-band"
        style={{
          opacity: layout ? 1 : 0,
          pointerEvents: "none",
          perspective: `${+(r * CAMERA).toFixed(3)}cqw`,
          perspectiveOrigin: `50% ${axis}%`,
          maskImage: mask,
          WebkitMaskImage: mask,
        }}
      >
        {Array.from({ length: columns }, (_, t) => {
          const first = columns - 1 - t;
          const img = images[(shown[t] ?? first) % Math.max(images.length, 1)];
          const video = videos[(shown[t] ?? first) % Math.max(videos.length, 1)];

          return (
            <div
              key={t}
              className={cn(tile, "tgh-tile")}
              style={{
                left: `calc(50% - ${u(aspectRatio / 2)})`,
                top: `calc(${axis}% - ${u(0.5)})`,
                width: u(aspectRatio),
                height: u(1),
                transformStyle: "preserve-3d",
                animation: `${orbit} ${duration}s linear ${-t * speed}s infinite`,
              }}
              onAnimationIteration={(e) => {
                const lap = Math.round(e.elapsedTime / duration);
                setShown((prev) => {
                  const next = lap * columns + first;
                  return prev[t] === next ? prev : { ...prev, [t]: next };
                });
              }}
            >
              {video ? (
                <video
                  key={`${t}-${video.src}`}
                  src={video.src}
                  aria-label={video.title}
                  muted
                  loop
                  playsInline
                  preload="none"
                  className="tgh-local-video"
                />
              ) : (
                <>
                  {Array.from({ length: SLICES }, (_, k) => (
                    <div
                      key={k}
                      className={cn(
                        "tgh-slice",
                        k === 0 && "tgh-slice--first",
                        k === SLICES - 1 && "tgh-slice--last",
                      )}
                      style={{
                        left: u((aspectRatio - share) / 2),
                        width:
                          k === SLICES - 1 ? u(share) : `calc(${u(share)} + 1px)`,
                        height: u(1),
                        transform: turn(
                          (aspectRatio / 2 - (k + 0.5) * share) * unit,
                        ),
                      }}
                    >
                      {img ? (
                        <img
                          src={img.src}
                          alt={k === 0 ? (img.alt ?? "") : ""}
                          draggable={false}
                          className="tgh-image"
                          style={{
                            left: u(-k * share),
                            width: u(aspectRatio),
                            height: u(1),
                          }}
                        />
                      ) : null}
                    </div>
                  ))}
                </>
              )}
            </div>
          );
        })}
      </div>
      {children}
    </div>
  );
}

export default TiltedGridHero;
