import React, { useState, useEffect } from "react";
import { TiltedGridHero, TiltedGridVideo, TiltedGridImage } from "./TiltedGridHero";
import { ArrowRight, ChevronDown, Sparkles } from "lucide-react";

interface KoddykubHeroProps {
  onOpenCatalog: () => void;
  onOpenHowTo: () => void;
}

const fallbackImages: TiltedGridImage[] = [
  { src: "/assets/game-world-fantasy.jpg", alt: "Fantasy Game World" },
  { src: "/assets/game-world-action.jpg", alt: "Action Game World" },
  { src: "/assets/game-world-arena.jpg", alt: "Arena Game World" },
  { src: "/assets/game-world-battle.jpg", alt: "Battle Game World" },
  { src: "/assets/game-world-voxel.jpg", alt: "Voxel Game World" },
];

export const KoddykubHero: React.FC<KoddykubHeroProps> = ({
  onOpenCatalog,
  onOpenHowTo,
}) => {
  const [videos, setVideos] = useState<TiltedGridVideo[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let active = true;
    fetch("/assets/game-videos.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : Promise.reject()))
      .then((data) => {
        if (active && Array.isArray(data.videos)) {
          setVideos(data.videos);
          setIsLoading(false);
        }
      })
      .catch(() => {
        if (active) {
          setVideos([]);
          setIsLoading(false);
        }
      });
    return () => {
      active = false;
    };
  }, []);

  return (
    <section className="kk-hero" id="hero">
      {/* 3D Tilted Grid Background (Curved 3D Video Carousel) */}
      <div id="tilted-grid-hero-root">
        <TiltedGridHero
          images={fallbackImages}
          videos={videos}
          speed={4}
          tileHeight={27}
          aspectRatio={16 / 9}
          gap={6}
          axis={55}
          curve={78}
          fade={14}
          className="tgh-fill"
        />
      </div>

      {/* Hero Foreground Content */}
      <div className="kk-hero__content">
        {/* HUD Eyebrow */}
        <p className="kk-eyebrow">
          <span className="kk-eyebrow__dot" />
          KODDYKUB · สินค้าดิจิทัล &amp; ซอร์สโค้ด
        </p>

        {/* Big Bold Headline */}
        <h1 className="select-none">
          เลือกซื้อ<span>ไอดีเกม</span>
          <br className="desktop-break" />
          และ <em>ซอร์สโค้ด</em> คุณภาพ
        </h1>

        {/* Lead Subtitle */}
        <p className="kk-hero__lead">
          ศูนย์รวมไอดีเกมแท้ 100% ซอร์สโค้ด Full-stack และสคริปต์อัตโนมัติ
          <br className="desktop-break" />
          ตรวจสอบความถูกต้องก่อนส่งมอบ พร้อมระบบจัดส่งรหัสทันที 24 ชม.
        </p>

        {/* Dual Actions */}
        <div className="kk-hero__actions">
          <button
            type="button"
            onClick={onOpenCatalog}
            className="kk-button cursor-pointer"
          >
            <span>ดูหมวดสินค้าทั้งหมด</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onOpenHowTo}
            className="kk-button kk-button--ghost cursor-pointer"
          >
            <span>วิธีสั่งซื้อ &amp; รับประกัน</span>
          </button>
        </div>

        {/* Popular Tags */}
        <div className="kk-hero__tags select-none">
          <span>VALORANT</span>
          <span>ROBLOX</span>
          <span>STEAM</span>
          <span>WUTHERING WAVES</span>
          <span>GENSHIN</span>
          <span>REACT &amp; NEXT.JS</span>
          <span>DISCORD BOTS</span>
        </div>
      </div>

      {/* Bottom Scroll Cue */}
      <div className="kk-hero__scroll select-none pointer-events-none">
        <span />
        <span>SCROLL TO EXPLORE</span>
      </div>
    </section>
  );
};

export default KoddykubHero;
