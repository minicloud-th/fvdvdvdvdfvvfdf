import React from "react";
import { ArrowRight, Gamepad2, Code2, ShieldCheck, Zap } from "lucide-react";

interface KoddykubCategoriesProps {
  onSelectCategory: (category: string) => void;
}

export const KoddykubCategories: React.FC<KoddykubCategoriesProps> = ({
  onSelectCategory,
}) => {
  return (
    <section className="kk-section" id="categories">
      <div className="kk-section__head">
        <p className="kk-eyebrow">
          <span className="kk-eyebrow__dot" />
          CATEGORIES &amp; SERVICES
        </p>
        <h2>
          หมวดหมู่<span>สินค้า</span>ที่เปิดให้บริการ
        </h2>
        <p className="kk-section__intro">
          เลือกหมวดหมู่ที่ต้องการเพื่อเข้าถึงสินค้าคุณภาพสูง จัดส่งอัตโนมัติผ่านระบบ API ทันทีหลังยืนยันยอดเงิน
        </p>
      </div>

      <div className="kk-category-grid">
        {/* Card 1: Gaming Accounts */}
        <div
          role="button"
          tabIndex={0}
          onClick={() => onSelectCategory("game_accounts")}
          className="kk-category-card cursor-pointer group text-left"
        >
          <div className="kk-category-card__visual kk-category-card__visual--game">
            <span className="kk-card-code">CATEGORY 01</span>
            <div className="kk-card-symbol">
              GAME<span>ID</span>
            </div>
            <span className="kk-card-tag">AUTHENTIC &amp; CLEAN</span>
          </div>

          <div className="kk-category-card__body">
            <div>
              <p className="kk-card-kicker">หมวดหมู่ไอดีเกมแท้</p>
              <h3 className="group-hover:text-[#a477ff] transition-colors">
                Gaming Accounts &amp; Game Passes
              </h3>
            </div>
            <span className="kk-category-card__arrow group-hover:translate-x-1 transition-transform">
              →
            </span>
            <p>
              ไอดีเกมยอดนิยม Valorant, Roblox ไก่ตัน บล็อกฟรุต, Genshin Impact, Steam และ FiveM สะอาด ปลอดภัย 100% พร้อมเปลี่ยนข้อมูลทันที
            </p>
          </div>
        </div>

        {/* Card 2: Source Code & Templates */}
        <div
          role="button"
          tabIndex={0}
          onClick={() => onSelectCategory("source_code")}
          className="kk-category-card cursor-pointer group text-left"
        >
          <div className="kk-category-card__visual kk-category-card__visual--code">
            <span className="kk-card-code">CATEGORY 02</span>
            <div className="kk-code-art">
              <b>&lt;/&gt;</b>
              <i />
              <i />
              <i />
            </div>
            <span className="kk-card-tag">PRODUCTION READY</span>
          </div>

          <div className="kk-category-card__body">
            <div>
              <p className="kk-card-kicker">ซอร์สโค้ดและระบบสำเร็จรูป</p>
              <h3 className="group-hover:text-[#65e7d0] transition-colors">
                Full-Stack Systems &amp; Bots
              </h3>
            </div>
            <span className="kk-category-card__arrow group-hover:translate-x-1 transition-transform">
              →
            </span>
            <p>
              ระบบเว็บขายของออนไลน์ Next.js, บอท Discord ตรวจสอบสลิปและเปิดทิคเก็ต, REST API Boilerplate และสคริปต์อัตโนมัติพร้อมติดตั้ง
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default KoddykubCategories;
