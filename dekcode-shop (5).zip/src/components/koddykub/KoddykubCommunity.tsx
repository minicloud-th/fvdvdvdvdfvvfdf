import React, { useState } from "react";
import { Play, X, ExternalLink, Sparkles } from "lucide-react";

interface FilmItem {
  id: string;
  title: string;
  creator: string;
  tag: string;
  image: string;
  description: string;
}

const FILMS: FilmItem[] = [
  {
    id: "film-1",
    title: "Cyberpunk 2077 HUD & Lua Script Showcase",
    creator: "KODDYKUB Studio",
    tag: "GAMING SCRIPT",
    image: "/assets/film-1.jpg",
    description: "ระบบสคริปต์หน้าจอ HUD และระบบแจ้งเตือนเรียลไทม์ที่พัฒนาบน Lua Framework พร้อมใช้งานบนเซิร์ฟเวอร์",
  },
  {
    id: "film-2",
    title: "Next.js Full-Stack Storefront Architecture",
    creator: "DevCommunity TH",
    tag: "SOURCE CODE",
    image: "/assets/film-2.jpg",
    description: "ตัวอย่างระบบร้านค้าอัตโนมัติ Full-Stack พร้อมระบบชำระเงิน PromptPay QR และแดชบอร์ดจัดการสต็อก",
  },
  {
    id: "film-3",
    title: "Valorant & Blox Fruits Automated Delivery Engine",
    creator: "GameVault",
    tag: "AUTOMATION",
    image: "/assets/film-3.jpg",
    description: "การสาธิตระบบส่งมอบรหัสผ่านและสคริปต์ทันทีหลังชำระเงิน รวดเร็ว ปลอดภัย และบันทึกประวัติแบบอัตโนมัติ",
  },
];

export const KoddykubCommunity: React.FC = () => {
  const [activeFilm, setActiveFilm] = useState<FilmItem | null>(null);

  return (
    <section className="kk-section" id="community">
      <div className="kk-section__head">
        <p className="kk-eyebrow">
          <span className="kk-eyebrow__dot" />
          COMMUNITY &amp; SHOWCASE
        </p>
        <h2>
          ผลงานและระบบ<span>ที่สร้างด้วย KODDYKUB</span>
        </h2>
        <p className="kk-section__intro">
          ดูตัวอย่างการนำซอร์สโค้ดและไอดีเกมไปใช้งานจริง พร้อมการทดสอบระบบก่อนส่งมอบให้ลูกค้า
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
        {FILMS.map((film) => (
          <div
            key={film.id}
            className="rounded-2xl border border-[#282838] bg-[#10101a] overflow-hidden group hover:border-[#a477ff]/60 transition-all duration-300 text-left flex flex-col justify-between"
          >
            <div className="relative aspect-video w-full overflow-hidden bg-[#151522]">
              <img
                src={film.image}
                alt={film.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                <button
                  type="button"
                  onClick={() => setActiveFilm(film)}
                  className="w-12 h-12 rounded-full bg-[#a477ff] text-[#120c1d] flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform cursor-pointer"
                  aria-label={`ดูตัวอย่าง ${film.title}`}
                >
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                </button>
              </div>
              <span className="absolute top-3 left-3 px-2 py-0.5 rounded-full bg-black/70 border border-white/20 text-[10px] font-mono text-[#65e7d0]">
                {film.tag}
              </span>
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-white group-hover:text-[#a477ff] transition-colors leading-snug">
                  {film.title}
                </h3>
                <p className="text-xs text-[#aaa8b8] mt-2 line-clamp-2 leading-relaxed">
                  {film.description}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-[#282838]/60 flex items-center justify-between text-xs text-[#777486]">
                <span>{film.creator}</span>
                <button
                  type="button"
                  onClick={() => setActiveFilm(film)}
                  className="text-[#a477ff] hover:underline cursor-pointer"
                >
                  ดูรายละเอียด
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Film Detail Modal */}
      {activeFilm && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setActiveFilm(null)}
        >
          <div
            className="w-full max-w-xl rounded-2xl bg-[#10101a] border border-[#282838] p-6 text-left space-y-4 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono text-[#65e7d0]">
                {activeFilm.tag} · {activeFilm.creator}
              </span>
              <button
                type="button"
                onClick={() => setActiveFilm(null)}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="aspect-video w-full rounded-xl overflow-hidden bg-black">
              <img
                src={activeFilm.image}
                alt={activeFilm.title}
                className="w-full h-full object-cover"
              />
            </div>

            <h3 className="text-lg font-bold text-white">
              {activeFilm.title}
            </h3>

            <p className="text-sm text-[#aaa8b8] leading-relaxed">
              {activeFilm.description}
            </p>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveFilm(null)}
                className="kk-button kk-button--small cursor-pointer"
              >
                ปิดหน้าต่าง
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default KoddykubCommunity;
