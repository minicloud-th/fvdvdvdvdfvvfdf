import React from "react";

export const KoddykubGuide: React.FC = () => {
  return (
    <>
      {/* ──────────────────────────────────────────────────────────
          1. 3-STEP ORDERING GUIDE (kk-how)
          ────────────────────────────────────────────────────────── */}
      <section className="kk-section kk-how" id="how-to">
        <div className="kk-section__head kk-section__head--row">
          <div>
            <p className="kk-eyebrow">
              <span className="kk-eyebrow__dot" />
              HOW IT WORKS
            </p>
            <h2>
              ขั้นตอนการสั่งซื้อ<span>ง่าย ๆ</span> ใน 3 ขั้นตอน
            </h2>
          </div>
          <p className="kk-section__intro">
            ระบบทำงานอัตโนมัติตลอด 24 ชั่วโมง โดยไม่มีค่าธรรมเนียมแอบแฝง
          </p>
        </div>

        <ol className="kk-steps">
          <li>
            <span className="kk-step-number">STEP 01</span>
            <h3>เลือกสินค้าที่ต้องการ</h3>
            <p>
              เลือกไอดีเกมที่ต้องการตรวจสอบสกินหรือแรงค์ หรือเลือกซอร์สโค้ดและสคริปต์ที่พร้อมใช้งาน ตรวจสอบรายละเอียดและสต็อกแบบเรียลไทม์
            </p>
          </li>
          <li>
            <span className="kk-step-number">STEP 02</span>
            <h3>ชำระเงินผ่าน PromptPay QR</h3>
            <p>
              สแกน QR Code พร้อมเพย์ หรือใช้วอลเล็ทในระบบ ยอดเงินจะได้รับการตรวจสอบและอนุมัติโดยอัตโนมัติภายในไม่กี่วินาที
            </p>
          </li>
          <li>
            <span className="kk-step-number">STEP 03</span>
            <h3>รับข้อมูลรหัสหรือไฟล์ทันที</h3>
            <p>
              ระบบจะแสดงข้อมูล Username, Password และลิ้งก์ดาวน์โหลดพร้อมใบเสร็จทันที สามารถย้อนดูในประวัติการสั่งซื้อได้ตลอดเวลา
            </p>
          </li>
        </ol>
      </section>

      {/* ──────────────────────────────────────────────────────────
          2. FAQ & VALUE GUARANTEE (kk-note)
          ────────────────────────────────────────────────────────── */}
      <section className="kk-note" id="faq">
        <div>
          <p className="kk-eyebrow">
            <span className="kk-eyebrow__dot" />
            FREQUENTLY ASKED QUESTIONS
          </p>
          <h2>
            คำถาม<span>ที่พบบ่อย</span>
          </h2>
          <p className="kk-section__intro">
            มีข้อสงสัยเกี่ยวกับการสั่งซื้อ การรับประกัน หรือการจัดส่งข้อมูล? ตรวจสอบคำตอบด้านล่าง หรือติดต่อแอดมินผ่านเมนูช่วยเหลือได้ตลอดเวลา
          </p>
        </div>

        <div className="kk-faq-list">
          <details open>
            <summary>ไอดีเกมมีประกันและเปลี่ยนรหัสผ่านได้จริงหรือไม่?</summary>
            <p>
              ไอดีทุกไอดีในร้าน KODDYKUB ผ่านการตรวจสอบความสะอาด (Clean Account) ไม่ติดแบน ไม่ผูกเบอร์ สามารถเปลี่ยนอีเมลและรหัสผ่านเป็นของคุณได้ 100% พร้อมประกันไอดีตามเงื่อนไขของแต่ละรายการ
            </p>
          </details>

          <details>
            <summary>หลังชำระเงินจะได้รับสินค้าอย่างไรและนานไหม?</summary>
            <p>
              ระบบจัดส่งสินค้าแบบอัตโนมัติทันทีหลังชำระเงิน (Instant Delivery) โดยข้อมูลบัญชีผู้ใช้ รหัสผ่าน และลิ้งก์ดาวน์โหลดไฟล์โค้ดจะปรากฏบนหน้าจอทันที และบันทึกลงในประวัติการซื้อของคุณ
            </p>
          </details>

          <details>
            <summary>ซอร์สโค้ดและระบบสำเร็จรูปมีคู่มือติดตั้งให้หรือไม่?</summary>
            <p>
              ทุกแพ็กเกจซอร์สโค้ดมีคู่มือการติดตั้ง (README / Documentation) อธิบายการตั้งค่า Environment Variables, การเชื่อมต่อ Database และคำสั่งรันโปรเจกต์อย่างละเอียด พร้อมทีมงานคอยให้คำแนะนำ
            </p>
          </details>

          <details>
            <summary>ช่องทางการชำระเงินรองรับอะไรบ้าง?</summary>
            <p>
              รองรับการโอนผ่านระบบ PromptPay QR Code อัตโนมัติทุกธนาคารในไทย รวมถึงการเติมเงินเข้า Wallet ของบัญชีสมาชิกเพื่อใช้สั่งซื้อสินค้าได้อย่างสะดวกและรวดเร็ว
            </p>
          </details>
        </div>
      </section>
    </>
  );
};

export default KoddykubGuide;
