import React, { useState, useEffect, useRef, useMemo } from "react";
import { Eye, EyeOff, ArrowLeft, Sun, Moon } from "lucide-react";
import axios from "axios";
import { toast } from "../lib/toastStore";
import {
  signInWithGoogle,
  signInWithGithub,
  signInEmail,
  signUpEmail,
  resetPassword,
} from "../lib/firebase";
import { demoStore, setDemoSession } from "../lib/mockApi";
import { DevLogo } from "./DevLogo";
import { useTheme } from "../lib/theme";
import { motion, AnimatePresence } from "motion/react";

interface AuthViewProps {
  initialMode: "login" | "signup";
  setActiveView: (view: any) => void;
  siteSettings?: any;
  onOpenTerms?: () => void;
  onOpenPrivacy?: () => void;
  onOpenContact?: () => void;
}

type AuthMode = "login" | "signup" | "forgot";

const inputClass =
  "w-full h-11 px-3.5 rounded-lg bg-surface-2 text-[15px] text-label placeholder:text-label-3 outline-none border border-separator focus:border-accent focus:ring-2 focus:ring-accent/20 transition-all";

const labelClass = "block mb-1.5 text-[13px] text-label-2";

const getCopy = (
  mode: AuthMode,
  brand: string
): { title: string; subtitle: string; submit: string } => {
  switch (mode) {
    case "signup":
      return {
        title: `สร้างบัญชี ${brand}`,
        subtitle: "เริ่มต้นใช้งานได้ในไม่กี่วินาที",
        submit: "สร้างบัญชี",
      };
    case "forgot":
      return {
        title: "รีเซ็ตรหัสผ่าน",
        subtitle: "รับลิงก์ตั้งรหัสผ่านใหม่ทางอีเมล",
        submit: "ส่งลิงก์รีเซ็ตรหัสผ่าน",
      };
    default:
      return {
        title: `ยินดีต้อนรับสู่ ${brand}`,
        subtitle: "ศูนย์รวมสินค้าดิจิทัลที่คุณวางใจ",
        submit: "ดำเนินการต่อด้วยอีเมล",
      };
  }
};

interface PasswordFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  autoComplete: string;
  show: boolean;
  onToggle: () => void;
  rightSlot?: React.ReactNode;
}

const PasswordField: React.FC<PasswordFieldProps> = ({
  id,
  label,
  value,
  onChange,
  placeholder,
  autoComplete,
  show,
  onToggle,
  rightSlot,
}) => (
  <div>
    <div className="flex items-center justify-between mb-1.5">
      <label htmlFor={id} className="text-[13px] text-label-2">
        {label}
      </label>
      {rightSlot}
    </div>
    <div className="relative">
      <input
        id={id}
        type={show ? "text" : "password"}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        className={`${inputClass} pr-11`}
        required
        minLength={6}
      />
      <button
        type="button"
        onClick={onToggle}
        aria-label={show ? "ซ่อนรหัสผ่าน" : "แสดงรหัสผ่าน"}
        className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-label-3 hover:text-label transition-colors cursor-pointer rounded-md active:scale-90"
      >
        {show ? (
          <EyeOff className="w-[18px] h-[18px]" />
        ) : (
          <Eye className="w-[18px] h-[18px]" />
        )}
      </button>
    </div>
  </div>
);

export const AuthView: React.FC<AuthViewProps> = React.memo(
  ({
    initialMode,
    setActiveView,
    siteSettings,
    onOpenTerms,
    onOpenPrivacy,
    onOpenContact,
  }) => {
    const { theme, toggleTheme } = useTheme();
    const [authMode, setAuthMode] = useState<AuthMode>(initialMode);

    const [authEmail, setAuthEmail] = useState("");
    const [authUsername, setAuthUsername] = useState("");
    const [authPassword, setAuthPassword] = useState("");
    const [authConfirmPassword, setAuthConfirmPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [rememberMe, setRememberMe] = useState(true);
    const [agreeTerms, setAgreeTerms] = useState(true);
    const [authLoading, setAuthLoading] = useState(false);
    const [isShaking, setIsShaking] = useState(false);

    const usernameInputRef = useRef<HTMLInputElement>(null);
    const emailInputRef = useRef<HTMLInputElement>(null);

    const triggerShake = () => {
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 450);
    };

    const switchMode = (mode: AuthMode) => {
      setAuthMode(mode);
      setAuthPassword("");
      setAuthConfirmPassword("");
    };

    // Load remembered user if available
    useEffect(() => {
      try {
        const saved = localStorage.getItem("astrax_remember_user");
        if (saved) setAuthEmail(saved);
      } catch {}
    }, []);

    useEffect(() => {
      setAuthMode(initialMode);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, [initialMode]);

    useEffect(() => {
      const timer = setTimeout(() => {
        if (authMode === "signup") usernameInputRef.current?.focus();
        else emailInputRef.current?.focus();
      }, 150);
      return () => clearTimeout(timer);
    }, [authMode]);

    // Real-time email validation
    const isEmailValid = useMemo(() => {
      if (!authEmail) return null;
      if (authMode === "login" && !authEmail.includes("@")) return null; // Username entered
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(authEmail.trim());
    }, [authEmail, authMode]);

    // Real-time password strength calculation
    const passwordStrength = useMemo(() => {
      let score = 0;
      if (authPassword.length >= 6) score++;
      if (authPassword.length >= 8) score++;
      if (/[0-9]/.test(authPassword)) score++;
      if (/[a-zA-Z]/.test(authPassword) && /[^a-zA-Z0-9]/.test(authPassword))
        score++;

      if (score <= 1)
        return {
          score: 1,
          text: "ระดับง่าย (แนะนำ 8 ตัวขึ้นไป ผสมตัวเลข)",
          color: "bg-danger",
          textColor: "text-danger",
        };
      if (score === 2)
        return {
          score: 2,
          text: "ระดับปานกลาง",
          color: "bg-warning",
          textColor: "text-warning",
        };
      return {
        score: 3,
        text: "ระดับปลอดภัยสูง",
        color: "bg-success",
        textColor: "text-success",
      };
    }, [authPassword]);

    const passwordsMatch = useMemo(() => {
      if (!authConfirmPassword) return null;
      return authPassword === authConfirmPassword;
    }, [authPassword, authConfirmPassword]);

    // Sync Firebase authenticated user with server and database profile
    const syncUserProfile = async (firebaseUser: any) => {
      const email = (firebaseUser.email || "").toLowerCase().trim();
      const displayName =
        firebaseUser.displayName || email.split("@")[0] || "User";
      const uid = firebaseUser.uid;

      // 1. Call secure server endpoint with verified Firebase ID token
      try {
        const idToken = await firebaseUser.getIdToken();
        const response = await axios.post(
          "/api/profile/sync",
          {
            username: displayName,
            fullName: displayName,
            avatarUrl:
              firebaseUser.photoURL ||
              `https://api.dicebear.com/7.x/bottts/svg?seed=${displayName}`,
          },
          { headers: { Authorization: `Bearer ${idToken}` } }
        );

        if (response.data?.profile) {
          const profile = response.data.profile;
          setDemoSession(profile);
          return profile;
        }
      } catch (err) {
        console.warn("[AuthView] Server profile sync fallback:", err);
      }

      // 2. Local memory fallback: role is ALWAYS "user"
      const users = demoStore.getUsers();
      let profile = users.find(
        (u) => u.uid === uid || u.email.toLowerCase() === email
      );

      if (!profile) {
        profile = {
          id: uid,
          uid: uid,
          email: email,
          username: displayName,
          fullName: displayName,
          role: "user",
          rank: "user",
          balance: 0,
          isPremium: false,
          status: "active",
          registeredAt: new Date().toISOString(),
          avatarUrl:
            firebaseUser.photoURL ||
            `https://api.dicebear.com/7.x/bottts/svg?seed=${displayName}`,
        };
        users.push(profile);
        demoStore.saveUsers(users);
      }

      setDemoSession(profile);
      return profile;
    };

    // Quick demo autofill handler for fast testing (DEV only)
    const handleQuickDemoFill = (type: "admin" | "user") => {
      setAuthMode("login");
      if (type === "admin") {
        setAuthEmail("admin");
        setAuthPassword("admin123");
        toast.info(
          "กรอกบัญชีผู้ดูแลระบบ (Admin) สำเร็จ พร้อมกดเข้าสู่ระบบ",
          "ทดสอบระบบด่วน"
        );
      } else {
        setAuthEmail("demo_user");
        setAuthPassword("user123");
        toast.info(
          "กรอกบัญชีสมาชิกทั่วไป (Demo User) สำเร็จ พร้อมกดเข้าสู่ระบบ",
          "ทดสอบระบบด่วน"
        );
      }
    };

    // OAuth handler shared by Google / GitHub
    const handleOAuth = async (provider: "google" | "github") => {
      const label = provider === "google" ? "Google" : "GitHub";
      setAuthLoading(true);
      try {
        const fbUser =
          provider === "google"
            ? await signInWithGoogle()
            : await signInWithGithub();
        const profile = await syncUserProfile(fbUser);
        toast.success(
          `ยินดีต้อนรับ ${profile.username || fbUser.email}`,
          `เข้าสู่ระบบด้วย ${label} สำเร็จ`
        );
        setActiveView(profile.role === "admin" ? "admin" : "home");
      } catch (err: any) {
        console.error(`${label} Auth Error:`, err);
        if (err.code === "auth/popup-closed-by-user") {
          toast.info(
            `คุณได้ปิดหน้าต่างการเข้าสู่ระบบ ${label}`,
            "ยกเลิกการเข้าสู่ระบบ"
          );
          return;
        }
        if (err.code === "auth/unauthorized-domain") {
          toast.warning(
            `โดเมน ${window.location.hostname} ยังไม่ได้รับอนุญาตใน Firebase Console โปรดใช้ชื่อผู้ใช้/รหัสผ่านในการทดสอบ`,
            "คำแนะนำการยืนยันตัวตน"
          );
          return;
        }
        triggerShake();
        toast.error(
          err.message || `ไม่สามารถเชื่อมต่อ ${label} ได้`,
          `ไม่สามารถเชื่อมต่อ ${label} ได้`
        );
      } finally {
        setAuthLoading(false);
      }
    };

    // Email, password, and username authentication
    const handleAuth = async (e: React.FormEvent) => {
      e.preventDefault();

      const warn = (message: string, title: string) => {
        triggerShake();
        toast.warning(message, title);
      };

      if (authMode === "signup") {
        if (!authUsername.trim())
          return warn(
            "กรุณาระบุชื่อผู้ใช้สำหรับสมัครสมาชิก",
            "ข้อมูลไม่ครบถ้วน"
          );
        if (!authEmail.trim())
          return warn("กรุณากรอกอีเมลสำหรับใช้งาน", "ข้อมูลไม่ครบถ้วน");
        if (isEmailValid === false)
          return warn(
            "รูปแบบอีเมลไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง",
            "รูปแบบอีเมลไม่ถูกต้อง"
          );
        if (!authPassword)
          return warn("กรุณากรอกรหัสผ่าน", "ข้อมูลไม่ครบถ้วน");
        if (authPassword.length < 6)
          return warn(
            "รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร",
            "รหัสผ่านสั้นเกินไป"
          );
        if (authPassword !== authConfirmPassword) {
          triggerShake();
          toast.error("รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน", "รหัสผ่านไม่ตรงกัน");
          return;
        }
        if (!agreeTerms)
          return warn(
            "กรุณายอมรับเงื่อนไขการให้บริการก่อนสมัครสมาชิก",
            "ข้อตกลงการใช้งาน"
          );
      } else if (authMode === "login") {
        if (!authEmail.trim())
          return warn("กรุณากรอกชื่อผู้ใช้ หรือ อีเมล", "ข้อมูลไม่ครบถ้วน");
        if (!authPassword)
          return warn("กรุณากรอกรหัสผ่าน", "ข้อมูลไม่ครบถ้วน");

        try {
          if (rememberMe)
            localStorage.setItem("astrax_remember_user", authEmail.trim());
          else localStorage.removeItem("astrax_remember_user");
        } catch {}
      } else {
        if (!authEmail.trim())
          return warn(
            "กรุณากรอกอีเมลสำหรับรีเซ็ตรหัสผ่าน",
            "ข้อมูลไม่ครบถ้วน"
          );
        if (isEmailValid === false)
          return warn(
            "รูปแบบอีเมลไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง",
            "รูปแบบอีเมลไม่ถูกต้อง"
          );
      }

      setAuthLoading(true);
      try {
        if (authMode === "signup") {
          const user = await signUpEmail(
            authEmail.trim(),
            authPassword,
            authUsername.trim() || undefined
          );
          await syncUserProfile(user);
          toast.success("บัญชีของคุณพร้อมใช้งานแล้ว", "สมัครสมาชิกสำเร็จ");
          setActiveView("home");
        } else if (authMode === "forgot") {
          await resetPassword(authEmail.trim());
          toast.success(
            `ส่งลิงก์รีเซ็ตรหัสผ่านไปยัง ${authEmail} แล้ว กรุณาตรวจสอบกล่องข้อความ`,
            "ส่งลิงก์เรียบร้อยแล้ว"
          );
          setAuthMode("login");
        } else {
          // Login (supports Username or Email)
          let loginEmail = authEmail.trim();
          if (!loginEmail.includes("@")) {
            try {
              const res = await axios.get(
                `/api/auth/resolve-username/${encodeURIComponent(loginEmail)}`
              );
              if (res.data?.email) loginEmail = res.data.email;
            } catch {
              const matched = demoStore
                .getUsers()
                .find(
                  (u) =>
                    u.username.toLowerCase() === loginEmail.toLowerCase()
                );
              if (matched && matched.email) loginEmail = matched.email;
            }
          }

          let user;
          try {
            user = await signInEmail(loginEmail, authPassword);
          } catch (firebaseErr: any) {
            // Local / demo accounts fallback (DEV only)
            if (import.meta.env.DEV) {
              const input = authEmail.trim().toLowerCase();
              const localUser = demoStore
                .getUsers()
                .find(
                  (u) =>
                    u.username.toLowerCase() === input ||
                    u.email.toLowerCase() === input
                );
              if (localUser) {
                setDemoSession(localUser);
                toast.success("ยินดีต้อนรับกลับเข้าสู่ระบบ", "เข้าสู่ระบบสำเร็จ");
                setActiveView(localUser.role === "admin" ? "admin" : "home");
                return;
              }
            }
            throw firebaseErr;
          }

          const profile = await syncUserProfile(user);
          toast.success("ยินดีต้อนรับกลับเข้าสู่ระบบ", "เข้าสู่ระบบสำเร็จ");
          setActiveView(profile.role === "admin" ? "admin" : "home");
        }
      } catch (err: any) {
        console.error("Auth Error:", err);
        triggerShake();
        let msg = err?.message || "เกิดข้อผิดพลาดในการทำรายการ";
        if (err.code === "auth/email-already-in-use") {
          msg = "อีเมลนี้ถูกใช้งานในระบบแล้ว กรุณาเข้าสู่ระบบ";
        } else if (
          err.code === "auth/invalid-credential" ||
          err.code === "auth/wrong-password" ||
          err.code === "auth/user-not-found"
        ) {
          msg = "ชื่อผู้ใช้ อีเมล หรือรหัสผ่านไม่ถูกต้อง";
        } else if (err.code === "auth/weak-password") {
          msg = "รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร";
        } else if (err.code === "auth/invalid-email") {
          msg = "รูปแบบอีเมลไม่ถูกต้อง";
        }
        toast.error(msg, "ไม่สามารถดำเนินการได้");
      } finally {
        setAuthLoading(false);
      }
    };

    const brandName = siteSettings?.site_name || "DekCode Shop";
    const { title, subtitle, submit } = getCopy(authMode, brandName);

    const goHome = () => {
      setActiveView("home");
      window.scrollTo({ top: 0, behavior: "smooth" });
    };

    return (
      <div className="min-h-screen w-full flex flex-col bg-bg text-label relative overflow-x-hidden selection:bg-accent/30 selection:text-white transition-colors duration-200">
        {/* Top bar: logo left, quick controls right */}
        <header className="w-full px-5 sm:px-8 py-4 sm:py-5 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={goHome}
            className="flex items-center group cursor-pointer focus:outline-none"
            title="กลับสู่หน้าแรก"
            aria-label="กลับสู่หน้าแรก DekCode Shop"
          >
            <DevLogo withText={false} className="h-14 sm:h-18 md:h-20 w-auto transition-transform duration-200 group-hover:scale-105" />
          </button>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={goHome}
              className="hidden sm:inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium text-label-2 hover:text-label hover:bg-surface-2 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>กลับสู่หน้าร้าน</span>
            </button>
            <button
              type="button"
              onClick={(e) => toggleTheme(e)}
              aria-label={
                theme === "dark"
                  ? "เปลี่ยนเป็นโหมดสว่าง"
                  : "เปลี่ยนเป็นโหมดมืด"
              }
              className="w-9 h-9 rounded-lg flex items-center justify-center text-label-2 hover:text-label hover:bg-surface-2 transition-all duration-200 cursor-pointer active:scale-90 relative overflow-hidden"
            >
              <AnimatePresence mode="popLayout" initial={false}>
                <motion.div
                  key={theme}
                  initial={{ rotate: -70, scale: 0.6, opacity: 0 }}
                  animate={{ rotate: 0, scale: 1, opacity: 1 }}
                  exit={{ rotate: 70, scale: 0.6, opacity: 0 }}
                  transition={{ type: "spring", stiffness: 350, damping: 22 }}
                  className="flex items-center justify-center"
                >
                  {theme === "dark" ? (
                    <Sun className="w-4.5 h-4.5 text-amber-400 drop-shadow-[0_0_6px_rgba(251,191,36,0.4)]" />
                  ) : (
                    <Moon className="w-4.5 h-4.5 text-indigo-500 drop-shadow-[0_0_6px_rgba(99,102,241,0.3)]" />
                  )}
                </motion.div>
              </AnimatePresence>
            </button>
          </div>
        </header>

        {/* Main: left-aligned flat column, no card */}
        <main className="flex-1 flex items-start sm:items-center justify-center px-5 sm:px-6 pt-10 pb-16 sm:py-10 w-full">
          <div
            className={`w-full max-w-[440px] ${
              isShaking ? "animate-shake" : ""
            }`}
          >
            {/* Animated Title & Subtitle */}
            <AnimatePresence mode="wait">
              <motion.div
                key={`title-${authMode}`}
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                transition={{ duration: 0.22, ease: "easeOut" }}
              >
                <h1 className="text-[26px] sm:text-[28px] leading-[1.25] font-medium tracking-tight">
                  <span className="block text-label">{title}</span>
                  <span className="block text-label-3">{subtitle}</span>
                </h1>
              </motion.div>
            </AnimatePresence>

            {/* Social icon row */}
            <AnimatePresence>
              {authMode !== "forgot" && (
                <motion.div
                  initial={{ opacity: 0, height: 0, marginTop: 0 }}
                  animate={{ opacity: 1, height: "auto", marginTop: 40 }}
                  exit={{ opacity: 0, height: 0, marginTop: 0 }}
                  transition={{ duration: 0.24, ease: "easeOut" }}
                  className="overflow-hidden"
                >
                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => handleOAuth("google")}
                      disabled={authLoading}
                      aria-label="เข้าสู่ระบบด้วย Google"
                      title="Google"
                      className="h-10 rounded-lg bg-surface-2 hover:bg-surface border border-transparent hover:border-separator flex items-center justify-center cursor-pointer transition-all active:scale-[0.98] disabled:opacity-50"
                    >
                      <svg className="w-[18px] h-[18px]" viewBox="0 0 24 24" aria-hidden="true">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleOAuth("github")}
                      disabled={authLoading}
                      aria-label="เข้าสู่ระบบด้วย GitHub"
                      title="GitHub"
                      className="h-10 rounded-lg bg-surface-2 hover:bg-surface border border-transparent hover:border-separator flex items-center justify-center text-label cursor-pointer transition-all active:scale-[0.98] disabled:opacity-50"
                    >
                      <svg className="w-[18px] h-[18px] fill-current" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
                      </svg>
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Form */}
            <form
              onSubmit={handleAuth}
              className={`space-y-4 ${authMode === "forgot" ? "mt-10" : "mt-6"}`}
            >
              {/* Animated Username for Signup */}
              <AnimatePresence initial={false}>
                {authMode === "signup" && (
                  <motion.div
                    key="signup-username-block"
                    initial={{ opacity: 0, height: 0, y: -6 }}
                    animate={{ opacity: 1, height: "auto", y: 0 }}
                    exit={{ opacity: 0, height: 0, y: -6 }}
                    transition={{ duration: 0.22, ease: "easeOut" }}
                    className="overflow-hidden"
                  >
                    <label htmlFor="signup-username" className={labelClass}>
                      ชื่อผู้ใช้
                    </label>
                    <input
                      id="signup-username"
                      ref={usernameInputRef}
                      type="text"
                      value={authUsername}
                      onChange={(e) => setAuthUsername(e.target.value)}
                      placeholder="ชื่อผู้ใช้ของคุณ"
                      autoComplete="username"
                      className={inputClass}
                      required
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              <div>
                <label htmlFor="auth-email-input" className={labelClass}>
                  {authMode === "login" ? "ชื่อผู้ใช้ หรือ อีเมล" : "อีเมล"}
                </label>
                <input
                  id="auth-email-input"
                  ref={emailInputRef}
                  type={authMode === "login" ? "text" : "email"}
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder={
                    authMode === "login"
                      ? "ชื่อผู้ใช้ หรือ อีเมลของคุณ"
                      : "ที่อยู่อีเมลของคุณ"
                  }
                  autoComplete={authMode === "signup" ? "email" : "username"}
                  className={`${inputClass} ${
                    authMode !== "login" && isEmailValid === false
                      ? "!border-danger focus:!ring-danger/20"
                      : ""
                  }`}
                  required
                />
                {authMode !== "login" && isEmailValid === false && (
                  <p className="mt-1.5 text-xs text-danger">
                    รูปแบบอีเมลไม่ถูกต้อง
                  </p>
                )}
              </div>

              {/* Password field - Hidden in forgot mode */}
              <AnimatePresence initial={false}>
                {authMode !== "forgot" && (
                  <motion.div
                    key="auth-password-block"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.22, ease: "easeOut" }}
                    className="overflow-hidden space-y-3"
                  >
                    <PasswordField
                      id="auth-password-input"
                      label="รหัสผ่าน"
                      value={authPassword}
                      onChange={setAuthPassword}
                      placeholder="รหัสผ่านของคุณ"
                      autoComplete={
                        authMode === "signup" ? "new-password" : "current-password"
                      }
                      show={showPassword}
                      onToggle={() => setShowPassword((v) => !v)}
                      rightSlot={
                        authMode === "login" ? (
                          <button
                            type="button"
                            onClick={() => switchMode("forgot")}
                            className="text-xs text-label-2 hover:text-label hover:underline underline-offset-2 cursor-pointer transition-colors"
                          >
                            ลืมรหัสผ่าน?
                          </button>
                        ) : undefined
                      }
                    />

                    {authMode === "signup" && authPassword.length > 0 && (
                      <div className="mt-2.5">
                        <div className="flex gap-1">
                          {[1, 2, 3].map((n) => (
                            <div
                              key={n}
                              className={`h-1 flex-1 rounded-full transition-colors duration-300 ${
                                passwordStrength.score >= n
                                  ? passwordStrength.color
                                  : "bg-surface-2"
                              }`}
                            />
                          ))}
                        </div>
                        <p className={`mt-1.5 text-xs ${passwordStrength.textColor}`}>
                          {passwordStrength.text}
                        </p>
                      </div>
                    )}

                    {authMode === "login" && (
                      <label className="flex items-center gap-2 cursor-pointer select-none w-fit">
                        <input
                          type="checkbox"
                          checked={rememberMe}
                          onChange={(e) => setRememberMe(e.target.checked)}
                          className="w-4 h-4 rounded border-separator bg-surface-2 text-accent focus:ring-accent cursor-pointer"
                        />
                        <span className="text-[13px] text-label-2">จดจำฉัน</span>
                      </label>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Confirm password in Signup mode */}
              <AnimatePresence initial={false}>
                {authMode === "signup" && (
                  <motion.div
                    key="auth-confirm-password-block"
                    initial={{ opacity: 0, height: 0, y: -6 }}
                    animate={{ opacity: 1, height: "auto", y: 0 }}
                    exit={{ opacity: 0, height: 0, y: -6 }}
                    transition={{ duration: 0.22, ease: "easeOut" }}
                    className="overflow-hidden"
                  >
                    <PasswordField
                      id="auth-confirm-password-input"
                      label="ยืนยันรหัสผ่าน"
                      value={authConfirmPassword}
                      onChange={setAuthConfirmPassword}
                      placeholder="กรอกรหัสผ่านอีกครั้ง"
                      autoComplete="new-password"
                      show={showConfirmPassword}
                      onToggle={() => setShowConfirmPassword((v) => !v)}
                    />
                    {passwordsMatch === false && (
                      <p className="mt-1.5 text-xs text-danger">
                        รหัสผ่านไม่ตรงกัน
                      </p>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Terms agreement in Signup mode */}
              <AnimatePresence initial={false}>
                {authMode === "signup" && (
                  <motion.div
                    key="auth-terms-block"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.22, ease: "easeOut" }}
                    className="overflow-hidden"
                  >
                    <label className="flex items-start gap-2.5 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={agreeTerms}
                        onChange={(e) => setAgreeTerms(e.target.checked)}
                        className="w-4 h-4 mt-0.5 rounded border-separator bg-surface-2 text-accent focus:ring-accent cursor-pointer shrink-0"
                      />
                      <span className="text-[13px] text-label-2 leading-relaxed">
                        ฉันยอมรับ{" "}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            onOpenTerms?.();
                          }}
                          className="text-label underline underline-offset-2 hover:text-accent inline cursor-pointer"
                        >
                          เงื่อนไขการให้บริการ
                        </button>{" "}
                        และ{" "}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            onOpenPrivacy?.();
                          }}
                          className="text-label underline underline-offset-2 hover:text-accent inline cursor-pointer"
                        >
                          นโยบายความเป็นส่วนตัว
                        </button>
                      </span>
                    </label>
                  </motion.div>
                )}
              </AnimatePresence>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full h-11 mt-2 rounded-lg bg-accent hover:bg-accent-hover text-white text-[15px] font-medium flex items-center justify-center gap-2 cursor-pointer transition-all duration-150 active:scale-[0.99] disabled:opacity-50"
              >
                {authLoading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>กำลังดำเนินการ...</span>
                  </>
                ) : (
                  <span>{submit}</span>
                )}
              </button>
            </form>

            {/* Mode switch (animated, centered, muted link like reference) */}
            <div className="mt-7 text-center text-sm text-label min-h-[24px]">
              <AnimatePresence mode="wait">
                {authMode === "login" && (
                  <motion.p
                    key="mode-login"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.18 }}
                  >
                    ยังไม่มีบัญชี?{" "}
                    <button
                      type="button"
                      onClick={() => switchMode("signup")}
                      className="text-label-2 hover:text-accent transition-colors cursor-pointer"
                    >
                      สมัครสมาชิก
                    </button>
                  </motion.p>
                )}
                {authMode === "signup" && (
                  <motion.p
                    key="mode-signup"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.18 }}
                  >
                    มีบัญชีอยู่แล้ว?{" "}
                    <button
                      type="button"
                      onClick={() => switchMode("login")}
                      className="text-label-2 hover:text-accent transition-colors cursor-pointer"
                    >
                      เข้าสู่ระบบ
                    </button>
                  </motion.p>
                )}
                {authMode === "forgot" && (
                  <motion.p
                    key="mode-forgot"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.18 }}
                  >
                    จำรหัสผ่านได้แล้ว?{" "}
                    <button
                      type="button"
                      onClick={() => switchMode("login")}
                      className="text-label-2 hover:text-accent transition-colors cursor-pointer"
                    >
                      กลับไปเข้าสู่ระบบ
                    </button>
                  </motion.p>
                )}
              </AnimatePresence>
            </div>

            {/* DEV quick fill (DEV builds only) */}
            {import.meta.env.DEV && authMode === "login" && (
              <div className="mt-6 flex items-center justify-center gap-2 text-13 text-label-3">
                <span className="font-mono px-1.5 py-0.5 rounded bg-surface-2 text-label-2">
                  DEV
                </span>
                <button
                  type="button"
                  onClick={() => handleQuickDemoFill("admin")}
                  className="hover:text-label hover:underline cursor-pointer transition-colors"
                >
                  กรอกแอดมิน
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => handleQuickDemoFill("user")}
                  className="hover:text-label hover:underline cursor-pointer transition-colors"
                >
                  กรอกสมาชิก
                </button>
              </div>
            )}
          </div>
        </main>

        {/* Minimal centered footer */}
        <footer className="w-full px-5 py-6 flex items-center justify-center gap-2 flex-wrap text-[13px] text-label-3 shrink-0">
          <button
            type="button"
            onClick={() => onOpenTerms?.()}
            className="hover:text-label transition-colors cursor-pointer"
          >
            ข้อกำหนดการให้บริการ
          </button>
          <span>และ</span>
          <button
            type="button"
            onClick={() => onOpenPrivacy?.()}
            className="hover:text-label transition-colors cursor-pointer"
          >
            นโยบายความเป็นส่วนตัว
          </button>
          <span className="mx-1">•</span>
          <button
            type="button"
            onClick={() => onOpenContact?.()}
            className="hover:text-label transition-colors cursor-pointer"
          >
            ติดต่อฝ่ายบริการ
          </button>
        </footer>
      </div>
    );
  }
);

export default AuthView;