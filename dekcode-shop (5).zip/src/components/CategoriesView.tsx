import React, { useState, useMemo } from "react";
import {
  LayoutGrid,
  Globe,
  Tag,
  Bot,
  Gamepad2,
  Tv,
  Wrench,
  Sparkles,
  ChevronRight,
  Package,
} from "lucide-react";
import { Category, Product } from "../types";
import { ProductCard } from "./ProductCard";

interface CategoriesViewProps {
  categories: Category[];
  products: Product[];
  siteSettings?: any;
  initialCategory?: string;
  onBack: () => void;
  onSelectCategory?: (categoryId: string) => void;
  onProductClick?: (id: string) => void;
}

const getCategoryIcon = (name: string, id: string) => {
  const query = `${name} ${id}`.toLowerCase();
  if (
    query.includes("social account") ||
    query.includes("account") ||
    query.includes("tag")
  ) {
    return Tag;
  }
  if (
    query.includes("social") ||
    query.includes("global") ||
    query.includes("web")
  ) {
    return Globe;
  }
  if (
    query.includes("ai") ||
    query.includes("gpt") ||
    query.includes("bot") ||
    query.includes("claude")
  ) {
    return Bot;
  }
  if (
    query.includes("game") ||
    query.includes("rov") ||
    query.includes("valorant")
  ) {
    return Gamepad2;
  }
  if (
    query.includes("stream") ||
    query.includes("netflix") ||
    query.includes("app") ||
    query.includes("tv")
  ) {
    return Tv;
  }
  if (
    query.includes("tool") ||
    query.includes("soft") ||
    query.includes("key") ||
    query.includes("win")
  ) {
    return Wrench;
  }
  return Sparkles;
};

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  categories = [],
  products = [],
  initialCategory = "ทั้งหมด",
  onBack,
  onProductClick,
}) => {
  const [selectedCategory, setSelectedCategory] =
    useState<string>(initialCategory === "all" ? "ทั้งหมด" : initialCategory);

  // Normalize category list
  const categoryList = useMemo(() => {
    const list: Array<{ id: string; name: string; Icon: any; count: number }> = [
      {
        id: "ทั้งหมด",
        name: "ทั้งหมด",
        Icon: LayoutGrid,
        count: products.length,
      },
    ];

    if (categories && categories.length > 0) {
      categories.forEach((cat) => {
        const catName = cat.name || cat.title || cat.id;
        const count = products.filter(
          (p) =>
            p.category === cat.id ||
            p.category === cat.name ||
            p.category === cat.title
        ).length;
        list.push({
          id: cat.id || catName,
          name: catName,
          Icon: getCategoryIcon(catName, cat.id || ""),
          count,
        });
      });
    } else {
      // Derive unique categories from products if categories list is empty
      const set = new Set<string>();
      products.forEach((p) => {
        if (p.category) set.add(p.category);
      });
      set.forEach((cat) => {
        const count = products.filter((p) => p.category === cat).length;
        list.push({
          id: cat,
          name: cat,
          Icon: getCategoryIcon(cat, cat),
          count,
        });
      });
    }

    return list;
  }, [categories, products]);

  // Filter products by selected category
  const filteredProducts = useMemo(() => {
    if (selectedCategory === "ทั้งหมด" || selectedCategory === "all") {
      return products;
    }
    return products.filter((p) => {
      return (
        p.category === selectedCategory ||
        p.category?.toLowerCase() === selectedCategory.toLowerCase()
      );
    });
  }, [products, selectedCategory]);

  return (
    <main className="site-width store-main">
      {/* ── Breadcrumbs ── */}
      <div className="breadcrumbs">
        <button
          type="button"
          onClick={onBack}
          className="hover:underline cursor-pointer"
        >
          หน้าหลัก
        </button>
        <ChevronRight size={12} />
        <span className="text-foreground font-medium">ร้านค้า</span>
      </div>

      {/* ── 2-Column Store Layout (Category Sidebar + Store Grid) ── */}
      <div className="store-layout">
        {/* Left Category Sidebar */}
        <aside className="category-panel">
          <h1 className="category-title">
            <LayoutGrid size={17} />
            <span>หมวดหมู่สินค้า</span>
          </h1>
          <div className="category-options">
            {categoryList.map(({ id, name, Icon, count }) => {
              const isSelected =
                selectedCategory === id || selectedCategory === name;
              return (
                <button
                  key={id}
                  type="button"
                  className={`category-option ${isSelected ? "selected" : ""}`}
                  onClick={() => setSelectedCategory(name)}
                >
                  <Icon size={17} />
                  <span>{name}</span>
                  <span className="category-count">{count}</span>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Right Product Grid */}
        <section className="store-grid" aria-label="สินค้า">
          {filteredProducts.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onClick={(id) => onProductClick && onProductClick(id)}
            />
          ))}
          {!filteredProducts.length && (
            <div className="empty-state">
              <Package className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p>ไม่พบสินค้าในหมวดหมู่นี้</p>
            </div>
          )}
        </section>
      </div>
    </main>
  );
};

export default CategoriesView;
