declare global {
  namespace JSX {
    interface IntrinsicElements {
      marquee: React.DetailedHTMLProps<React.HTMLAttributes<HTMLMarqueeElement> & { scrollamount?: string }, HTMLMarqueeElement>;
    }
  }
}

export interface UserPlan {
  username: string;
  fullName?: string;
  balance?: number;
  role?: string;
  rank?: 'user' | 'basic' | 'premium';
  isPremium: boolean;
  premiumExpireDate: string | null;
  registeredAt?: string;
  avatarUrl?: string;
}

export interface Category {
  id: string;
  name: string;
  title: string;
  subtitle: string;
  bannerUrl: string;
  imageUrl?: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  soldCount?: number;
  imageUrl: string;
  stock: number;
  category?: string;
  isPopular?: boolean;
  tag?: string;
  stockData?: string[];
  _version?: number;
  productType?: 'game_account' | 'source_code' | 'digital_tool' | 'script';
  techStack?: string[];
  gamePlatform?: string;
  rating?: number;
  downloadsCount?: number;
  delivery?: boolean;
}

export interface SiteStats {
  users: number;
  stock: number;
  sales: number;
  topups: number;
  totalOrders?: number;
}

export interface ContentItem {
  id: string;
  title: string;
  image?: string;
  text?: string;
  fileUrl?: string;
  type: 'free' | 'premium';
}

export interface SiteSettings {
  site_name?: string;
  truewallet_phone?: string;
  promptpay_number?: string;
  promptpay_name?: string;
  contact_line?: string;
  discord_link?: string;
  facebook_link?: string;
  instagram_link?: string;
  contact_email?: string;
  stats_users_offset?: number;
  stats_sales_offset?: number;
  popup_img_url?: string;
  popup_enabled?: boolean;
  popup_link?: string;
  banners?: string[];
  proxies?: string[];
  auto_proxy?: boolean;
  spotify_url?: string;
  spotify_autoplay?: boolean;
  announcement_text?: string;
}

export interface PurchaseRecord {
  id: string;
  orderId?: string;
  uid: string;
  userId?: string;
  username: string;
  productId: string;
  productName: string;
  price: number;
  amount: number;
  quantity?: number;
  secretData: string;
  itemData: string;
  deliveredItem: string;
  status: string;
  createdAt: string;
  date?: string;
  timestamp?: string;
}

export interface PurchaseResponse {
  success: boolean;
  message?: string;
  purchase: PurchaseRecord;
  updatedUser: UserPlan;
  updatedProduct: Product;
}


